create view FRANCHISEVIEW as
select FRANCHISEID,BEZEICHNUNG,SPIELID,spiel.TITEL as Spieltitel ,FILMID,Film.TITEL as Filmtitel
from Franchise
join spiel using (FRANCHISEID)
left join Film using (FRANCHISEID)
/

