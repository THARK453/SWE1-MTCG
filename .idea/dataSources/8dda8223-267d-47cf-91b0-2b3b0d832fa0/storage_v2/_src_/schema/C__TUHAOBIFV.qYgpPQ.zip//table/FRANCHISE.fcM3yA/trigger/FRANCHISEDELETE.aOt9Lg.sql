create trigger FRANCHISEDELETE
    before delete
    on FRANCHISE
    for each row
DECLARE

cursor C_val is
select FILMID from Film 
where FRANCHISEID=:old.FRANCHISEID;

cursor C_val2 is
select SERIEID from Serie 
where FRANCHISEID=:old.FRANCHISEID;
PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN
	 
     for c in C_val
     loop
     Delete from Person_Film where FILMID=c.FILMID;
     end loop;
     
     Delete from Film where FRANCHISEID=:old.FRANCHISEID;      
    Delete from buch where FRANCHISEID=:old.FRANCHISEID; 
    Delete from Comic where FRANCHISEID=:old.FRANCHISEID;     
    Delete from Spiel where FRANCHISEID=:old.FRANCHISEID;
    
     for c2 in C_val2
     loop
     Delete from Person_Serie where SERIEID=c2.SERIEID;
     end loop;    
      Delete from Serie where FRANCHISEID=:old.FRANCHISEID;
  COMMIT ;

   

END;
/

