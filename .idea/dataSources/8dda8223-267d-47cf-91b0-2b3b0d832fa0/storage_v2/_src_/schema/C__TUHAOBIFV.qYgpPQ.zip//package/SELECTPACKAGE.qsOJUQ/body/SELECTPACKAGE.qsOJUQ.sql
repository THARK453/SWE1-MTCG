create package body 
Selectpackage as
            
            PROCEDURE land
            as            
            cursor C_val is
            select * from land;
            begin                
                DBMS_OUTPUT.PUT_LINE('LANDID'||' , '||'BEZEICHNUNG');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.LANDID||' , '||c.BEZEICHNUNG);
                 end loop;
            end;
             
            PROCEDURE buch
            as            
            cursor C_val is
            select * from buch;
            begin                
                DBMS_OUTPUT.PUT_LINE('ISBN'||' , '||'TITEL'||' , '||'ERSCHEINUNGSDATUM'||' , '||'PERSONID'||' , '||'GENREID'||' , '||'FRANCHISEID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.ISBN||' , '||c.TITEL||' , '||c.ERSCHEINUNGSDATUM||' , '||c.PERSONID||' , '||c.GENREID||' , '||c.FRANCHISEID);
                 end loop;
            end;
        
            PROCEDURE Comic
            as            
            cursor C_val is
            select * from Comic;
            begin                
                DBMS_OUTPUT.PUT_LINE('ISBN'||' , '||'TITEL'||' , '||'ERSCHEINUNGSDATUM'||' , '||'PERSONID'||' , '||'GENREID'||' , '||'FRANCHISEID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.ISBN||' , '||c.TITEL||' , '||c.ERSCHEINUNGSDATUM||' , '||c.PERSONID||' , '||c.GENREID||' , '||c.FRANCHISEID);
                 end loop;
            end;

            PROCEDURE Serie
            as            
            cursor C_val is
            select * from Serie;
            begin                
                DBMS_OUTPUT.PUT_LINE('SERIEID'||' , '||'TITEL'||' , '||'ERSCHEINUNGSDATUM'||' , '||'LANDID'||' , '||'PERSONID'||' , '||'GENREID'||' , '||'FRANCHISEID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.SERIEID||' , '||c.TITEL||' , '||c.ERSCHEINUNGSDATUM||' , '||c.LANDID||' , '||c.PERSONID||' , '||c.GENREID||' , '||c.FRANCHISEID);
                 end loop;
            end;

           PROCEDURE Film
            as            
            cursor C_val is
            select * from Film;
            begin                
                DBMS_OUTPUT.PUT_LINE('FILMID'||' , '||'TITEL'||' , '||'ERSCHEINUNGSDATUM'||' , '||'LAENGE'||' , '||'EINNAHMEN_MIO'||' , '||'LANDID'||' , '||'PERSONID'||' , '||'GENREID'||' , '||'FRANCHISEID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.FILMID||' , '||c.TITEL||' , '||c.ERSCHEINUNGSDATUM||' , '||c.LAENGE||' , '||c.EINNAHMEN_MIO||' , '||c.LANDID||' , '||c.PERSONID||' , '||c.GENREID||' , '||c.FRANCHISEID);
                 end loop;
            end;
    
             PROCEDURE Genre
            as            
            cursor C_val is
            select * from Genre;
            begin                
                DBMS_OUTPUT.PUT_LINE('GENREID'||' , '||'BEZEICHNUNG');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.GENREID||' , '||c.BEZEICHNUNG);
                 end loop;
            end;

            PROCEDURE Franchise
            as            
            cursor C_val is
            select * from Franchise;
            begin                
                DBMS_OUTPUT.PUT_LINE('FRANCHISEID'||' , '||'BEZEICHNUNG'||' , '||'PERSONID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.FRANCHISEID||' , '||c.BEZEICHNUNG||' , '||c.PERSONID);
                 end loop;
            end;

             PROCEDURE Entwicklerstudio
            as            
            cursor C_val is
            select * from Entwicklerstudio;
            begin                
                DBMS_OUTPUT.PUT_LINE('ENTWICKLERSTUDIOID'||' , '||'BEZEICHNUNG'||' , '||'LANDID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.ENTWICKLERSTUDIOID||' , '||c.BEZEICHNUNG||' , '||c.LANDID);
                 end loop;
            end;

            PROCEDURE Spiel
            as            
            cursor C_val is
            select * from Spiel;
            begin                
                DBMS_OUTPUT.PUT_LINE('SPIELID'||' , '||'TITEL'||' , '||'GENREID'||' , '||'ERSCHEINUNGSDATUM'||' , '||'ENTWICKLERSTUDIOID'||' , '||'FRANCHISEID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.SPIELID||' , '||c.TITEL||' , '||c.GENREID||' , '||c.ERSCHEINUNGSDATUM||' , '||c.ENTWICKLERSTUDIOID||' , '||c.FRANCHISEID);
                 end loop;
            end;
            
             PROCEDURE person
            as            
            cursor C_val is
            select * from person;
            begin                
                DBMS_OUTPUT.PUT_LINE('PERSONID'||' , '||'VORNAME'||' , '||'NACHNAME'||' , '||'LANDID'||' , '||'GEBURTSDATUM');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.PERSONID||' , '||c.VORNAME||' , '||c.NACHNAME||' , '||c.LANDID||' , '||c.GEBURTSDATUM);
                 end loop;
            end;

              PROCEDURE Person_Serie
            as            
            cursor C_val is
            select * from Person_Serie;
            begin                
                DBMS_OUTPUT.PUT_LINE('PERSONID'||' , '||'SERIEID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.PERSONID||' , '||c.SERIEID);
                 end loop;
            end;    
            
               PROCEDURE Person_Film
            as            
            cursor C_val is
            select * from Person_Film;
            begin                
                DBMS_OUTPUT.PUT_LINE('PERSONID'||' , '||'FILMID');                       
                for c in C_val
                loop
                DBMS_OUTPUT.PUT_LINE(c.PERSONID||' , '||c.FILMID);
                 end loop;
            end;  


end;
/

