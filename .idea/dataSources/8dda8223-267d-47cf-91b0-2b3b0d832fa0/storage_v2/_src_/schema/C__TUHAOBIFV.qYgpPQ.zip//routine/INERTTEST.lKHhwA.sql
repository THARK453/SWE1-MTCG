create PROCEDURE inerttest (PID in  NUMBER, vname in varchar, nname in varchar, LID in NUMBER, GDT in DATE)
is
   

BEGIN
         INSERT INTO person (personid, vorname, nachname, landid, geburtsdatum) VALUES (PID, vname, nname, LID, GDT);
       
END;
/

