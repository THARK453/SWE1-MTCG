create PROCEDURE inerttest1 (LID in  NUMBER, BZG in varchar)
is
   

BEGIN
        INSERT INTO land (landid, bezeichnung) VALUES (LID, BZG);
       
END;
/

