create PROCEDURE updateland (LID in NUMBER,neuname in varchar)
is
 
    
     V_BZG land.BEZEICHNUNG%type;    

BEGIN
             update land
             set BEZEICHNUNG=neuname
             where LANDID=LID;
           
             select BEZEICHNUNG into V_BZG from land where LANDID=LID;
             DBMS_OUTPUT.PUT_LINE('LANDID: '||LID||' , BEZEICHNUNG: '||V_BZG);
              
     
END;
/

