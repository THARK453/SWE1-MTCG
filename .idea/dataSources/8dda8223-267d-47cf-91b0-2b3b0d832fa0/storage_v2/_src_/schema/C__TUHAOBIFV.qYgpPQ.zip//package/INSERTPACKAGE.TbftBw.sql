create package 
insertpackage as

                      
             PROCEDURE land (LID in  NUMBER, BZG in varchar);  
             PROCEDURE buch (ISBN in varchar, TTL in varchar,EDT in DATE,PID in NUMBER, GID in NUMBER, FID in NUMBER);
             PROCEDURE Comic(ISBN in varchar, TTL in varchar,EDT in DATE,PID in NUMBER, GID in NUMBER, FID in NUMBER);
             PROCEDURE Serie(SID in NUMBER,TTL in varchar,EDT in DATE,LID in NUMBER,PID in NUMBER,GID in NUMBER,FID in NUMBER);
             PROCEDURE Film (FILID in NUMBER,TTL in varchar,EDT in DATE,LGE in varchar,EMO in NUMBER,LID in NUMBER,PID in NUMBER,GID in NUMBER,FID in NUMBER);
             PROCEDURE Genre(GID in NUMBER,BZG in varchar);
             PROCEDURE Franchise(FID in NUMBER,BZG in varchar,PID in NUMBER);
             PROCEDURE Entwicklerstudio(EID in NUMBER,BZG in varchar,LID in NUMBER);
             PROCEDURE Spiel(SPID in NUMBER,TTL in varchar,GID in NUMBER,EDT in DATE,ESID in NUMBER,FID in NUMBER);
             PROCEDURE person (PID in  NUMBER, vname in varchar, nname in varchar, LID in NUMBER, GDT in DATE);
             PROCEDURE Person_Serie(PID in NUMBER,SID in NUMBER);
             PROCEDURE Person_Film(PID in NUMBER,FILID in NUMBER);

end;
/

