create PROCEDURE cursortest
is
 

BEGIN
  
         
             DBMS_OUTPUT.PUT_LINE('test');
              
     
END;
/

