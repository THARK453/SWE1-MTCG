create FUNCTION hello6
RETURN varchar
IS
fname VARCHAR2(20);
BEGIN
fname :='Tom';
return 'Hello ' || fname || '!!!';
END;
/

