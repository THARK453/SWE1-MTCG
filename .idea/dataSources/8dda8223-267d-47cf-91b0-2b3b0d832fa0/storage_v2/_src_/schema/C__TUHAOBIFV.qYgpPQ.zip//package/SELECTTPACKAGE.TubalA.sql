create package 
Selecttpackage as

                      
             PROCEDURE Sland (V in varchar);  
      

end;
/

