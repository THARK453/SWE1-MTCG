create package body 
insertpackage as
            
            PROCEDURE land (LID in  NUMBER, BZG in varchar)
            as
            begin
               INSERT INTO land (landid, bezeichnung) VALUES (LID, BZG);
            end;
          
            PROCEDURE buch(ISBN in varchar, TTL in varchar,EDT in DATE,PID in NUMBER, GID in NUMBER, FID in NUMBER)
            as
            begin
               INSERT INTO Buch VALUES (ISBN,TTL,EDT,PID,GID,FID);
            end;   
                   
            PROCEDURE Comic(ISBN in varchar, TTL in varchar,EDT in DATE,PID in NUMBER, GID in NUMBER, FID in NUMBER)
            as
            begin
               INSERT INTO Comic VALUES (ISBN,TTL,EDT,PID, GID, FID );
            end;   
      
            PROCEDURE Serie(SID in NUMBER,TTL in varchar,EDT in DATE,LID in NUMBER,PID in NUMBER,GID in NUMBER,FID in NUMBER)
            as
            begin
               INSERT INTO Serie VALUES (SID,TTL,EDT,LID,PID,GID,FID);
            end;
               
            PROCEDURE Film (FILID in NUMBER,TTL in varchar,EDT in DATE,LGE in varchar,EMO in NUMBER,LID in NUMBER,PID in NUMBER,GID in NUMBER,FID in NUMBER)
            as
            begin
               INSERT INTO Film VALUES (FILID,TTL,EDT,LGE,EMO,LID,PID,GID,FID );
            end;
            
            PROCEDURE Genre(GID in NUMBER,BZG in varchar)
            as 
            begin
               INSERT INTO Genre VALUES (GID,BZG );
            end;   
              
            PROCEDURE Franchise(FID in NUMBER,BZG in varchar,PID in NUMBER)
            as
            begin
               INSERT INTO Franchise VALUES(FID,BZG,PID );
            end;   

            PROCEDURE Entwicklerstudio(EID in NUMBER,BZG in varchar,LID in NUMBER)
            as
            begin
               INSERT INTO Entwicklerstudio VALUES (EID,BZG,LID);
            end;
            
             PROCEDURE Spiel(SPID in NUMBER,TTL in varchar,GID in NUMBER,EDT in DATE,ESID in NUMBER,FID in NUMBER )
             as
             begin
                 INSERT INTO Spiel VALUES (SPID,TTL,GID,EDT,ESID,FID);
             end;    
      
            PROCEDURE Person_Serie(PID in NUMBER,SID in NUMBER)
            as
            begin
                INSERT INTO Person_Serie VALUES (PID,SID);
            end;
            
            PROCEDURE Person_Film(PID in NUMBER,FILID in NUMBER)
            as
            begin
                INSERT INTO  Person_Film VALUES (PID,FILID);
            end;    
         

            PROCEDURE person (PID in  NUMBER, vname in varchar, nname in varchar, LID in NUMBER, GDT in DATE)
            as
            begin
               INSERT INTO person (personid, vorname, nachname, landid, geburtsdatum) VALUES (PID, vname, nname, LID, GDT);
            end;
        

end;
/

