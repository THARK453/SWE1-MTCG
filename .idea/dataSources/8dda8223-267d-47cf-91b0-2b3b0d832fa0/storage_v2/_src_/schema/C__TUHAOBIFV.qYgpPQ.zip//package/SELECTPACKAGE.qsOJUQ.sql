create package 
Selectpackage as

                      
            PROCEDURE land;
            PROCEDURE buch;
            PROCEDURE Comic;
            PROCEDURE Serie;
            PROCEDURE Film;
            PROCEDURE Genre;
            PROCEDURE Franchise;
            PROCEDURE Entwicklerstudio;
            PROCEDURE Spiel;
            PROCEDURE person;
            PROCEDURE Person_Serie;
            PROCEDURE Person_Film;
      

end;
/

