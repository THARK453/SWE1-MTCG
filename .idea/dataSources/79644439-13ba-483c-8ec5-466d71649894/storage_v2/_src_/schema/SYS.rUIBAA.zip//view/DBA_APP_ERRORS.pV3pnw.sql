create view DBA_APP_ERRORS (APP_NAME, APP_STATEMENT, ERRORNUM, ERRORMSG, SYNC_TIME) as
select s.APP_NAME, s.APP_STATEMENT, e.ERRORNUM, e.ERRORMSG, e.stime
from DBA_APP_STATEMENTS s, fed$statement$errors e, fed$apps a
where s.STATEMENT_ID=e.SEQ#
and a.appid#=e.appid#
and a.app_name=s.app_name
and a.spare1=0
order by s.STATEMENT_ID
/

comment on table DBA_APP_ERRORS is 'Describes all application error messages in the Application Container'
/

comment on column DBA_APP_ERRORS.APP_NAME is 'Name of the application whose statement was captured'
/

comment on column DBA_APP_ERRORS.APP_STATEMENT is 'Application statement'
/

comment on column DBA_APP_ERRORS.ERRORNUM is 'Error number for statement'
/

comment on column DBA_APP_ERRORS.ERRORMSG is 'Error message for statement'
/

comment on column DBA_APP_ERRORS.SYNC_TIME is 'Time of sync of statement'
/

