create view INT$DBA_APP_STATEMENTS
            (STATEMENT_ID, CAPTURE_TIME, LONGSQLTXT, SQLSTMT, APP_NAME, APP_STATUS, PATCH_NUMBER, VERSION_NUMBER,
             SESSION_ID, OPCODE, OPTIMIZED, APP_ID, SHARING, ORIGIN_CON_ID)
as
select s.replay#, s.ctime, s.longsqltxt, s.sqlstmt, a.app_name,
          decode(s.app_status, 1, 'INSTALLING', 2, 'UPGRADING', 3, 'PATCHING',
                               4, 'UNINSTALLING', 5, 'UNINSTALLED',
                               6, 'SET VERSION', 7, 'SET PATCH',
                               0, 'NORMAL'),
          s.patch#, s.ver#, s.sessserial#, s.opcode,
          decode(bitand(s.flags,48), 16, 'NO OP', 32, 'NO REPLAY', null)
            optimized, s.appid#,
          1,
          to_number(sys_context('USERENV', 'CON_ID'))
from fed$apps a, pdb_sync$ s
where a.appid#=s.appid# and bitand(s.flags,8)=8 and a.spare1=0
/

