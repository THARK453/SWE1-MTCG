create view CDB_INDEXTYPE_ARRAYTYPES
            (OWNER, INDEXTYPE_NAME, BASE_TYPE_SCHEMA, BASE_TYPE_NAME, BASE_TYPE, ARRAY_TYPE_SCHEMA, ARRAY_TYPE_NAME,
             CON_ID) as
SELECT k."OWNER",k."INDEXTYPE_NAME",k."BASE_TYPE_SCHEMA",k."BASE_TYPE_NAME",k."BASE_TYPE",k."ARRAY_TYPE_SCHEMA",k."ARRAY_TYPE_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_INDEXTYPE_ARRAYTYPES") k
/

comment on table CDB_INDEXTYPE_ARRAYTYPES is 'All array types specified by the indextype in all containers'
/

comment on column CDB_INDEXTYPE_ARRAYTYPES.OWNER is 'Owner of the indextype'
/

comment on column CDB_INDEXTYPE_ARRAYTYPES.INDEXTYPE_NAME is 'Name of the indextype'
/

comment on column CDB_INDEXTYPE_ARRAYTYPES.BASE_TYPE_SCHEMA is 'Name of the base type schema'
/

comment on column CDB_INDEXTYPE_ARRAYTYPES.BASE_TYPE_NAME is 'Name of the base type name'
/

comment on column CDB_INDEXTYPE_ARRAYTYPES.BASE_TYPE is 'Datatype of the base type'
/

comment on column CDB_INDEXTYPE_ARRAYTYPES.ARRAY_TYPE_SCHEMA is 'Name of the array type schema'
/

comment on column CDB_INDEXTYPE_ARRAYTYPES.ARRAY_TYPE_NAME is 'Name of the array type name'
/

comment on column CDB_INDEXTYPE_ARRAYTYPES.CON_ID is 'container id'
/

