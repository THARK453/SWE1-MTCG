create view "_GV$SXGG_TRANSACTION"
            (INST_ID, STREAMS_NAME, STREAMS_TYPE, XIDUSN, XIDSLT, XIDSQN, CUMULATIVE_MESSAGE_COUNT, TOTAL_MESSAGE_COUNT,
             FIRST_MESSAGE_TIME, FIRST_MESSAGE_NUMBER, LAST_MESSAGE_TIME, LAST_MESSAGE_NUMBER, FIRST_MESSAGE_POSITION,
             LAST_MESSAGE_POSITION, TRANSACTION_ID, PURPOSE, CON_ID)
as
select "INST_ID","STREAMS_NAME","STREAMS_TYPE","XIDUSN","XIDSLT","XIDSQN","CUMULATIVE_MESSAGE_COUNT","TOTAL_MESSAGE_COUNT","FIRST_MESSAGE_TIME","FIRST_MESSAGE_NUMBER","LAST_MESSAGE_TIME","LAST_MESSAGE_NUMBER","FIRST_MESSAGE_POSITION","LAST_MESSAGE_POSITION","TRANSACTION_ID","PURPOSE","CON_ID" from gv$streams_transaction
union all
select inst_id, component_name, component_type, xidusn, xidslt, xidsqn,
cumulative_message_count, total_message_count, first_message_time,
first_message_number, last_message_time, last_message_number,
first_message_position, last_message_position, transaction_id,
NULL purpose, con_id
from gv$xstream_transaction
union all
select inst_id, component_name, component_type, xidusn, xidslt, xidsqn,
cumulative_message_count, total_message_count, first_message_time,
first_message_number, last_message_time, last_message_number,
utl_raw.cast_to_raw(first_message_position),
utl_raw.cast_to_raw(last_message_position), transaction_id,
NULL purpose, con_id
from gv$goldengate_transaction
/

