create TYPE wri$_adv_hdm_t UNDER wri$_adv_abstract_t
(
  OVERRIDING MEMBER procedure sub_execute (task_id IN NUMBER,
                                           err_num OUT NUMBER),
  overriding member procedure sub_get_report (task_id IN NUMBER,
                                              type IN VARCHAR2,
                                              level IN VARCHAR2,
                                              section IN VARCHAR2,
                                              buffer IN OUT NOCOPY CLOB),
  overriding member procedure sub_reset(task_id in number),
  overriding member procedure sub_delete(task_id in number),
  overriding MEMBER PROCEDURE sub_param_validate(
              task_id in number,
              name in varchar2,
              value in out varchar2)
);
/

