create view DBA_SCHEDULER_WINGROUP_MEMBERS (WINDOW_GROUP_NAME, WINDOW_NAME) as
SELECT o.name, wmo.name
  FROM obj$ o, obj$ wmo, scheduler$_wingrp_member wg,
    scheduler$_window_group w
  WHERE o.type# = 72 AND o.obj# = wg.oid AND wg.member_oid = wmo.obj#
    AND w.obj# = wg.oid AND bitand(w.flags, 8+16) = 0
/

comment on table DBA_SCHEDULER_WINGROUP_MEMBERS is 'Members of all scheduler window groups in the database'
/

comment on column DBA_SCHEDULER_WINGROUP_MEMBERS.WINDOW_GROUP_NAME is 'Name of the window group'
/

comment on column DBA_SCHEDULER_WINGROUP_MEMBERS.WINDOW_NAME is 'Name of the window member of this window group'
/

