create view EXU112DLOB
            (TOBJID, OWNERID, CNAME, SNAME, SSGFLAG, STSNAME, STSNO, SFILE, SBLOCK, SDOBJID, SCHUNKING, SVPOOL, SFLAGS,
             INAME, ISGFLAG, ITSNAME, ITSNO, IFILE, IBLOCK, IDOBJID, IINITRANS, IMAXTRANS, SPROPERTY, COLTYPE,
             COLTYPFLG, BLOCKSIZE, INTCOLID, OPAQUETYPE, IFREEPOOL)
as
SELECT  l$.obj#, so$.owner#,
                DECODE(BITAND(c$.property, 1), 0, '"'||c$.name||'"', 1,
                       ac$.name),
                so$.name, so$.flags, sts$.name, sts$.ts#, l$.file#, l$.block#,
                so$.dataobj#, l$.chunk, l$.pctversion$, l$.flags, io$.name,
                io$.flags, its$.name, its$.ts#, i$.file#, i$.block#,
                io$.dataobj#, i$.initrans, i$.maxtrans, l$.property,
                NVL(c$.type#, 0), NVL(ct$.flags, 0), sts$.blocksize,
                c$.intcol#,
                NVL((SELECT opq.type
                     FROM   sys.opqtype$ opq
                     WHERE  c$.type# = 58 AND
                            c$.obj# = opq.obj# AND
                            c$.intcol# = opq.intcol#), -1),
                l$.freepools
        FROM    sys.lob$ l$, sys.obj$ so$, sys.col$ c$, sys.attrcol$ ac$,
                sys.ts$ sts$, sys.ind$ i$, sys.obj$ io$,
                sys.ts$ its$, sys.coltype$ ct$
        WHERE   l$.lobj# = so$.obj# AND
                l$.obj# = c$.obj# AND
                l$.intcol# =
                     NVL((SELECT opq.lobcol
                          FROM   sys.opqtype$ opq
                          WHERE  c$.type# = 58 AND                 /* opaque */
                                 c$.obj# = opq.obj# AND
                                 c$.intcol# = opq.intcol# AND
                                 opq.type = 1 AND                /* XMLType */
                                 BITAND(opq.flags, 4) = 4  /* stored as lob */
                         ), c$.intcol#) AND
                c$.obj# = ac$.obj#(+) AND
                c$.intcol# = ac$.intcol#(+) AND
                l$.ind# = i$.obj# AND
                l$.ind# = io$.obj# AND
                i$.ts# = its$.ts# AND
                sts$.ts# = its$.ts# AND
                c$.obj# = ct$.obj# (+) AND
                c$.intcol# = ct$.intcol# (+) AND
                BITAND(c$.property, 32768) != 32768 AND /* not unused column */
                BITAND(c$.property, 256) != 256         /* not sys generated */
/

