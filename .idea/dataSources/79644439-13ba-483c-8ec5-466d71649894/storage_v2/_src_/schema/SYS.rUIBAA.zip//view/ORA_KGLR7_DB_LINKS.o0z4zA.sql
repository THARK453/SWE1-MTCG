create view ORA_KGLR7_DB_LINKS (OWNER, NAME, USERNAME) as
select u.name, l.name, l.userid
from sys.link$ l, sys.user$ u
where l.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
  and l.owner# = u.user#
/

