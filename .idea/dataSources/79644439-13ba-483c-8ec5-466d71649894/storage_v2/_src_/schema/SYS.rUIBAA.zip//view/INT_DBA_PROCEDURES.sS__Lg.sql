create view INT$DBA_PROCEDURES
            (OWNER, OBJECT_NAME, PROCEDURE_NAME, OBJECT_ID, SUBPROGRAM_ID, OVERLOAD, OBJECT_TYPE, OBJECT_TYPE#,
             AGGREGATE, PIPELINED, IMPLTYPEOWNER, IMPLTYPENAME, PARALLEL, INTERFACE, DETERMINISTIC, AUTHID,
             RESULT_CACHE, SHARING, ORIGIN_CON_ID, POLYMORPHIC, APPLICATION)
as
(select u.name, o.name, pi.procedurename, o.obj#, pi.procedure#,
decode(pi.overload#, 0, NULL, pi.overload#),
decode(o.type#, 7, 'PROCEDURE',
       8, 'FUNCTION', 9, 'PACKAGE', 11, 'PACKAGE BODY',
       12, 'TRIGGER', 13, 'TYPE', 14, 'TYPE BODY',
       22, 'LIBRARY', 28, 'JAVA SOURCE', 29, 'JAVA CLASS',
       30, 'JAVA RESOURCE', 87, 'ASSEMBLY', 'UNDEFINED'),
o.type#,
decode(bitand(pi.properties,8),8,'YES','NO'),
decode(bitand(pi.properties,16),16,'YES','NO'),
u2.name, o2.name,
  decode(bitand(pi.properties,32),32,'YES','NO'),
  decode(bitand(pi.properties,512),512,'YES','NO'),
decode(bitand(pi.properties,256),256,'YES','NO'),
decode(bitand(pi.properties,1024),1024,'CURRENT_USER','DEFINER'),
decode(bitand(pi.properties2,8),8,'YES','NO'),
case when bitand(o.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
to_number(sys_context('USERENV', 'CON_ID')),
 CASE
     WHEN bitand(pi.properties,1073741824) > 0 THEN
        CASE
           when bitand(properties2, 1) > 0 THEN 'TABLE'
           when bitand(properties2, 2) > 0 THEN 'ROW'
           when bitand(properties2, 4) > 0 THEN 'LEAF'
        ELSE 'NULL'
        END
  ELSE 'NULL'
   end,
/* Bug 19552209: Add APPLICATION column for application object */
case when bitand(o.flags, 134217728)>0 then 1 else 0 end
from sys."_CURRENT_EDITION_OBJ" o, user$ u, procedureinfo$ pi,
     sys."_CURRENT_EDITION_OBJ" o2, user$ u2
where u.user# = o.owner# and o.obj# = pi.obj#
and (o.type# in (7, 8, 9, 11, 12, 14, 22, 28, 29, 30, 87) or
     (o.type# = 13 and o.subname is null))
and pi.itypeobj# = o2.obj# (+) and o2.owner#  = u2.user# (+)
/* Bug 19552209: to avoid duplication when query from app pdb,
 * oracle-maintained procedure shouldn't be returned in app root.
 */
and (SYS_CONTEXT('USERENV', 'CON_ID') = 0 or
     (SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'YES' and
      bitand(o.flags, 4194304)<>4194304) or
     SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'NO' )
)
union all
(select u.name, o.name, NULL,
  o.obj#,
  CASE
    WHEN o.type# = 12 THEN 1
    ELSE 0
  END,
  NULL, decode(o.type#,12,'TRIGGER',9,'PACKAGE'), o.type#,
  'NO', 'NO', NULL, NULL, 'NO', 'NO', 'NO',
  CASE
    WHEN o.type#=12 THEN 'DEFINER'
    ELSE decode(bitand(pi.properties,1024),NULL,NULL,
                1024,'CURRENT_USER','DEFINER')
  END CASE, 'NO', case when bitand(o.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
  to_number(sys_context('USERENV', 'CON_ID')), NULL,
  /* Bug 19552209: Add APPLICATION column for application object */
  case when bitand(o.flags, 134217728)>0 then 1 else 0 end
  from sys."_CURRENT_EDITION_OBJ" o, user$ u, procedureinfo$ pi
  where ((o.owner# = u.user# and o.obj# = pi.obj# (+)) AND
         (o.type# in (12,9)) AND
         ((pi.procedure# is null) OR (pi.procedure# = 1)) AND
         /* Bug 19552209: to avoid duplication when query from app pdb,
          * oracle-maintained procedure shouldn't be returned in app root.
          */
         (SYS_CONTEXT('USERENV', 'CON_ID') = 0 or
          (SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'YES' and
           bitand(o.flags, 4194304)<>4194304) or
          SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'NO'))
)
/

