create view CDB_MVIEW_DETAIL_SUBPARTITION
            (OWNER, MVIEW_NAME, DETAILOBJ_OWNER, DETAILOBJ_NAME, DETAIL_PARTITION_NAME, DETAIL_SUBPARTITION_NAME,
             DETAIL_SUBPARTITION_POSITION, FRESHNESS, CON_ID)
as
SELECT k."OWNER",k."MVIEW_NAME",k."DETAILOBJ_OWNER",k."DETAILOBJ_NAME",k."DETAIL_PARTITION_NAME",k."DETAIL_SUBPARTITION_NAME",k."DETAIL_SUBPARTITION_POSITION",k."FRESHNESS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_MVIEW_DETAIL_SUBPARTITION") k
/

comment on table CDB_MVIEW_DETAIL_SUBPARTITION is 'Freshness information of all PCT materialized views in the database in all containers'
/

comment on column CDB_MVIEW_DETAIL_SUBPARTITION.OWNER is 'Owner of the materialized view'
/

comment on column CDB_MVIEW_DETAIL_SUBPARTITION.MVIEW_NAME is 'Name of the materialized view'
/

comment on column CDB_MVIEW_DETAIL_SUBPARTITION.DETAILOBJ_NAME is 'Name of the detail object'
/

comment on column CDB_MVIEW_DETAIL_SUBPARTITION.DETAIL_PARTITION_NAME is 'Name of the detail object partition'
/

comment on column CDB_MVIEW_DETAIL_SUBPARTITION.DETAIL_SUBPARTITION_NAME is 'Name of the detail object subpartition'
/

comment on column CDB_MVIEW_DETAIL_SUBPARTITION.DETAIL_SUBPARTITION_POSITION is 'Position of the detail object subpartition'
/

comment on column CDB_MVIEW_DETAIL_SUBPARTITION.FRESHNESS is 'Freshness of the detail object partition'
/

comment on column CDB_MVIEW_DETAIL_SUBPARTITION.CON_ID is 'container id'
/

