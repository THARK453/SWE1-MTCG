create view DBA_ENABLED_AGGREGATIONS (AGGREGATION_TYPE, PRIMARY_ID, QUALIFIER_ID1, QUALIFIER_ID2) as
select decode(trace_type, 1, 'CLIENT_ID', 3, 'SERVICE',
                 4, 'SERVICE_MODULE', 5, 'SERVICE_MODULE_ACTION', 'UNDEFINED'),
                 primary_id, qualifier_id1, qualifier_id2
  from WRI$_AGGREGATION_ENABLED
/

comment on table DBA_ENABLED_AGGREGATIONS is 'Information about enabled on-demand statistic aggregation'
/

comment on column DBA_ENABLED_AGGREGATIONS.AGGREGATION_TYPE is 'Type of the aggregation (CLIENT_ID, SERVICE, etc.)'
/

comment on column DBA_ENABLED_AGGREGATIONS.PRIMARY_ID is 'Primary qualifier (specific Client Identifier or Service name)'
/

comment on column DBA_ENABLED_AGGREGATIONS.QUALIFIER_ID1 is 'Secondary qualifier (specific MODULE name)'
/

comment on column DBA_ENABLED_AGGREGATIONS.QUALIFIER_ID2 is 'Additional qualifier (specific ACTION name)'
/

