create view ALL_CREDENTIALS (OWNER, CREDENTIAL_NAME, USERNAME, WINDOWS_DOMAIN, COMMENTS, ENABLED) as
SELECT u.name, o.name, c.username,
  c.domain, c.comments,
  DECODE(bitand(c.flags,4), 0, 'FALSE', 4, 'TRUE')
  FROM obj$ o, user$ u, sys.scheduler$_credential c
  WHERE c.obj# = o.obj# AND u.user# = o.owner# AND
    (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         (exists (select null from v$enabledprivs
                 where priv_number in (-388 /* CREATE ANY CREDENTIAL*/)
                 )
          and o.owner#!=0)
      )
/

comment on table ALL_CREDENTIALS is 'All credentials visible to the user'
/

comment on column ALL_CREDENTIALS.OWNER is 'Owner of the credential'
/

comment on column ALL_CREDENTIALS.CREDENTIAL_NAME is 'Name of the credential'
/

comment on column ALL_CREDENTIALS.USERNAME is 'User to run as'
/

comment on column ALL_CREDENTIALS.WINDOWS_DOMAIN is 'Windows domain to use when logging in'
/

comment on column ALL_CREDENTIALS.COMMENTS is 'Comments on the credential'
/

comment on column ALL_CREDENTIALS.ENABLED is 'Is this credential enabled'
/

