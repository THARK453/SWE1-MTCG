create view GV_$THRESHOLD_TYPES
            (INST_ID, METRICS_ID, METRICS_GROUP_ID, OPERATOR_MASK, OBJECT_TYPE, ALERT_REASON_ID, METRIC_VALUE_TYPE,
             CON_ID) as
SELECT "INST_ID","METRICS_ID","METRICS_GROUP_ID","OPERATOR_MASK","OBJECT_TYPE","ALERT_REASON_ID","METRIC_VALUE_TYPE","CON_ID" FROM gv$threshold_types
/

comment on table GV_$THRESHOLD_TYPES is 'Description on threshold types'
/

comment on column GV_$THRESHOLD_TYPES.INST_ID is 'Instance id'
/

comment on column GV_$THRESHOLD_TYPES.METRICS_ID is 'Metrics id'
/

comment on column GV_$THRESHOLD_TYPES.METRICS_GROUP_ID is 'Metrics group id'
/

comment on column GV_$THRESHOLD_TYPES.OPERATOR_MASK is 'Operator mask'
/

comment on column GV_$THRESHOLD_TYPES.OBJECT_TYPE is 'Object type'
/

comment on column GV_$THRESHOLD_TYPES.ALERT_REASON_ID is 'Alert reason id'
/

comment on column GV_$THRESHOLD_TYPES.METRIC_VALUE_TYPE is 'Metric value type'
/

