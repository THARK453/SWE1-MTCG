create type WRR$_ASH_TIME_PERIOD AUTHID CURRENT_USER AS OBJECT
(
  m_db_id           INTEGER,
  m_begin_time TIMESTAMP(3),
  m_end_time   TIMESTAMP(3),
  m_begin_snap_id   INTEGER,
  m_end_snap_id     INTEGER,
  m_ash_disk_filter INTEGER,
  m_ash_sample_rate INTEGER,
  m_id         VARCHAR2(30),
  m_time_period_type VARCHAR2(30),
  m_filter_condition VARCHAR2(512),
  m_desc       VARCHAR2(256),
  FINAL INSTANTIABLE CONSTRUCTOR FUNCTION
           wrr$_ash_time_period( p_db_id IN INTEGER,
                        p_begin_time IN TIMESTAMP,
                        p_end_time  IN  TIMESTAMP,
                        p_begin_snap_id IN INTEGER,
                        p_end_snap_id IN INTEGER,
                        p_id IN VARCHAR2 )
  RETURN SELF AS RESULT
) FINAL INSTANTIABLE ;
/

