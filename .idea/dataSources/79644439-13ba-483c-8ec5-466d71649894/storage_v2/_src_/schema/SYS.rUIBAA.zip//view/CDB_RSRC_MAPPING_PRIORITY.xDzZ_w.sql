create view CDB_RSRC_MAPPING_PRIORITY (ATTRIBUTE, PRIORITY, STATUS, CON_ID) as
SELECT k."ATTRIBUTE",k."PRIORITY",k."STATUS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_RSRC_MAPPING_PRIORITY") k
/

comment on table CDB_RSRC_MAPPING_PRIORITY is 'the consumer group mapping attribute priorities in all containers'
/

comment on column CDB_RSRC_MAPPING_PRIORITY.ATTRIBUTE is 'session attribute'
/

comment on column CDB_RSRC_MAPPING_PRIORITY.PRIORITY is 'priority (1 = highest)'
/

comment on column CDB_RSRC_MAPPING_PRIORITY.STATUS is 'PENDING if it is part of the pending area, NULL otherwise'
/

comment on column CDB_RSRC_MAPPING_PRIORITY.CON_ID is 'container id'
/

