create view AWR_CDB_CON_SYSTEM_EVENT
            (SNAP_ID, DBID, INSTANCE_NUMBER, EVENT_ID, EVENT_NAME, WAIT_CLASS_ID, WAIT_CLASS, TOTAL_WAITS,
             TOTAL_TIMEOUTS, TIME_WAITED_MICRO, TOTAL_WAITS_FG, TOTAL_TIMEOUTS_FG, TIME_WAITED_MICRO_FG, CON_DBID,
             CON_ID)
as
select e.snap_id, e.dbid, e.instance_number,
       e.event_id, en.event_name, en.wait_class_id, en.wait_class,
       total_waits, total_timeouts, time_waited_micro,
       total_waits_fg, total_timeouts_fg, time_waited_micro_fg,
       e.con_dbid,
       con_dbid_to_id(decode(e.con_dbid, 0, e.dbid, e.con_dbid)) con_id
from AWR_CDB_SNAPSHOT sn, WRH$_CON_SYSTEM_EVENT e, WRH$_EVENT_NAME en
where     e.event_id         = en.event_id
      and e.dbid             = en.dbid
      and e.snap_id          = sn.snap_id
      and e.dbid             = sn.dbid
      and e.instance_number  = sn.instance_number
/

comment on table AWR_CDB_CON_SYSTEM_EVENT is 'System Event Historical Statistics Information'
/

