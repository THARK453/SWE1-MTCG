create procedure     validate_owm wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
7b ba
zL/azQbvltDKyKJF2bLjx2BzMO4wgy5HO8sVZ3SmcNIA6WyC54rDk5n2JYFauxc1TKd0NeGv
LzAQrGo/BtoSdnUYgjSc+HlMh7Ez5HphzCZcMxSzDlEo75Ic49BUIdaUPctLXcx9B+CKyj52
zhRvpos+TCXiUZ44i2/BKbUeDih+dyC8xphmhw==
/

