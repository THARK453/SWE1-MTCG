create view DBA_HIGH_WATER_MARK_STATISTICS (DBID, NAME, VERSION, HIGHWATER, LAST_VALUE, DESCRIPTION) as
select dbid, hwm.name, version, highwater, last_value, description
 from wri$_dbu_high_water_mark hwm, wri$_dbu_hwm_metadata mt
 where hwm.name = mt.name and
       hwm.name not like '_HWM_TEST%' and             /* filter out test hwm */
       bitand(mt.method, 4) != 4                  /* filter out disabled hwm */
/

comment on table DBA_HIGH_WATER_MARK_STATISTICS is 'Database High Water Mark Statistics'
/

comment on column DBA_HIGH_WATER_MARK_STATISTICS.DBID is 'database ID'
/

comment on column DBA_HIGH_WATER_MARK_STATISTICS.NAME is 'name of high water mark statistics'
/

comment on column DBA_HIGH_WATER_MARK_STATISTICS.VERSION is 'the database version the highwater marks are tracked in'
/

comment on column DBA_HIGH_WATER_MARK_STATISTICS.HIGHWATER is 'highest value for statistic seen at sampling time'
/

comment on column DBA_HIGH_WATER_MARK_STATISTICS.LAST_VALUE is 'value of statistic at last sample time'
/

comment on column DBA_HIGH_WATER_MARK_STATISTICS.DESCRIPTION is 'description of high water mark'
/

