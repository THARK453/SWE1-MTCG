create PACKAGE XS_DATA_SECURITY AUTHID CURRENT_USER AS

-- Apply policy options
  APPLY_DYNAMIC_IS          CONSTANT   PLS_INTEGER := 1;
  APPLY_ACLOID_COLUMN       CONSTANT   PLS_INTEGER := 2;
  APPLY_STATIC_IS           CONSTANT   PLS_INTEGER := 3;

-- Enable log based replication for this package
PRAGMA SUPPLEMENTAL_LOG_DATA(default, AUTO);

-- Create data security policy
PROCEDURE CREATE_POLICY (
          name                     IN VARCHAR2,
          realm_constraint_list    IN  XS$REALM_CONSTRAINT_LIST,
          column_constraint_list   IN  XS$COLUMN_CONSTRAINT_LIST := NULL,
          description              IN VARCHAR2 := NULL
          );

-- Add a realm constraint to data security
PROCEDURE APPEND_REALM_CONSTRAINTS (
          policy                IN VARCHAR2,
          realm_constraint      IN XS$REALM_CONSTRAINT_TYPE
          );

-- Add a list of realm constraints to data security
PROCEDURE APPEND_REALM_CONSTRAINTS (
          policy                IN VARCHAR2,
          realm_constraint_list IN XS$REALM_CONSTRAINT_LIST
          );

-- Remove all realm constraints
PROCEDURE REMOVE_REALM_CONSTRAINTS (
          policy                IN VARCHAR2
          );

-- Add a column constraint to data security
PROCEDURE ADD_COLUMN_CONSTRAINTS (
          policy             IN VARCHAR2,
          column_constraint  IN XS$COLUMN_CONSTRAINT_TYPE
          );

-- Add column constraints to data security
PROCEDURE ADD_COLUMN_CONSTRAINTS (
          policy                   IN VARCHAR2,
          column_constraint_list   IN XS$COLUMN_CONSTRAINT_LIST
          );

-- Remove all column constraints of data security
PROCEDURE REMOVE_COLUMN_CONSTRAINTS (
          policy                IN VARCHAR2
          );

-- Create an ACL paramter
PROCEDURE CREATE_ACL_PARAMETER (
          policy               IN VARCHAR2,
          parameter            IN VARCHAR2,
          param_type           IN NUMBER
          );

-- Delete an ACL parameter
PROCEDURE DELETE_ACL_PARAMETER (
          policy                IN VARCHAR2,
          parameter             IN VARCHAR2,
          delete_option         IN PLS_INTEGER := XS_ADMIN_UTIL.DEFAULT_OPTION
          );

-- Set the description of data security
PROCEDURE SET_DESCRIPTION (
          policy                 IN VARCHAR2,
          description            IN VARCHAR2
          );


-- Delete data security policy
PROCEDURE DELETE_POLICY(
          policy                IN VARCHAR2,
          delete_option         IN PLS_INTEGER := XS_ADMIN_UTIL.DEFAULT_OPTION
          );

-- apply_object_policy -  Apply XDS policy on a table
PROCEDURE APPLY_OBJECT_POLICY(
          policy          IN VARCHAR2,
          schema          IN VARCHAR2,
          object          IN VARCHAR2,
          row_acl         IN BOOLEAN  := FALSE,
          owner_bypass    IN BOOLEAN  := FALSE,
          statement_types IN VARCHAR2 := NULL,
          aclmv           IN VARCHAR2 := NULL
          );

-- enable_object_policy - disable an XDS policy for a table
PROCEDURE ENABLE_OBJECT_POLICY(
          policy IN VARCHAR2,
          schema IN VARCHAR2,
          object IN VARCHAR2
          );

-- disable_object_policy - disable an XDS policy for a table
PROCEDURE DISABLE_OBJECT_POLICY(
          policy IN VARCHAR2,
          schema IN VARCHAR2,
          object IN VARCHAR2
          );

-- remove_object_policy - remove an XDS policy from a table
PROCEDURE REMOVE_OBJECT_POLICY(
          policy IN VARCHAR2,
          schema IN VARCHAR2,
          object IN VARCHAR2
          );

END XS_DATA_SECURITY;
/

