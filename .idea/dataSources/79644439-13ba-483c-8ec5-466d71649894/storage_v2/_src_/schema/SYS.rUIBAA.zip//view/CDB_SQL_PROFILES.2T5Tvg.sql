create view CDB_SQL_PROFILES
            (NAME, CATEGORY, SIGNATURE, SQL_TEXT, CREATED, LAST_MODIFIED, DESCRIPTION, TYPE, STATUS, FORCE_MATCHING,
             TASK_ID, TASK_EXEC_NAME, TASK_OBJ_ID, TASK_FND_ID, TASK_REC_ID, TASK_CON_DBID, CON_ID)
as
SELECT k."NAME",k."CATEGORY",k."SIGNATURE",k."SQL_TEXT",k."CREATED",k."LAST_MODIFIED",k."DESCRIPTION",k."TYPE",k."STATUS",k."FORCE_MATCHING",k."TASK_ID",k."TASK_EXEC_NAME",k."TASK_OBJ_ID",k."TASK_FND_ID",k."TASK_REC_ID",k."TASK_CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SQL_PROFILES") k
/

comment on table CDB_SQL_PROFILES is 'set of sql profiles in all containers'
/

comment on column CDB_SQL_PROFILES.NAME is 'name of sql profile'
/

comment on column CDB_SQL_PROFILES.CATEGORY is 'category of sql profile'
/

comment on column CDB_SQL_PROFILES.SIGNATURE is 'unique identifier generated from normalized SQL text'
/

comment on column CDB_SQL_PROFILES.SQL_TEXT is 'un-normalized SQL text'
/

comment on column CDB_SQL_PROFILES.CREATED is 'date stamp when sql profile created'
/

comment on column CDB_SQL_PROFILES.LAST_MODIFIED is 'date stamp when sql profile was last modified'
/

comment on column CDB_SQL_PROFILES.DESCRIPTION is 'text description provided for sql profile'
/

comment on column CDB_SQL_PROFILES.TYPE is 'type of sql profile (how created)'
/

comment on column CDB_SQL_PROFILES.STATUS is 'enabled/disabled status of sql profile'
/

comment on column CDB_SQL_PROFILES.FORCE_MATCHING is 'signature is force matching or exact matching'
/

comment on column CDB_SQL_PROFILES.TASK_ID is 'advisor task id that generated the sql profile'
/

comment on column CDB_SQL_PROFILES.TASK_EXEC_NAME is 'advisor execution name for the sql profile'
/

comment on column CDB_SQL_PROFILES.TASK_OBJ_ID is 'advisor object id for the sql profile'
/

comment on column CDB_SQL_PROFILES.TASK_FND_ID is 'advisor finding id for the sql profile'
/

comment on column CDB_SQL_PROFILES.TASK_REC_ID is 'advisor recommendation id for the sql profile'
/

comment on column CDB_SQL_PROFILES.TASK_CON_DBID is 'container dbid for the tuning task generating the profile'
/

comment on column CDB_SQL_PROFILES.CON_ID is 'container id'
/

