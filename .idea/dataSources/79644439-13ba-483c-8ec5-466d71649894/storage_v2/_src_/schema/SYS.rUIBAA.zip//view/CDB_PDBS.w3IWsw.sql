create view CDB_PDBS
            (PDB_ID, PDB_NAME, DBID, CON_UID, GUID, STATUS, CREATION_SCN, VSN, LOGGING, FORCE_LOGGING, FORCE_NOLOGGING,
             APPLICATION_ROOT, APPLICATION_PDB, APPLICATION_SEED, APPLICATION_ROOT_CON_ID, IS_PROXY_PDB, CON_ID,
             UPGRADE_PRIORITY, APPLICATION_CLONE, FOREIGN_CDB_DBID, UNPLUG_SCN, FOREIGN_PDB_ID, CREATION_TIME,
             REFRESH_MODE, REFRESH_INTERVAL, TEMPLATE, LAST_REFRESH_SCN, TENANT_ID, SNAPSHOT_MODE, SNAPSHOT_INTERVAL)
as
SELECT k."PDB_ID",k."PDB_NAME",k."DBID",k."CON_UID",k."GUID",k."STATUS",k."CREATION_SCN",k."VSN",k."LOGGING",k."FORCE_LOGGING",k."FORCE_NOLOGGING",k."APPLICATION_ROOT",k."APPLICATION_PDB",k."APPLICATION_SEED",k."APPLICATION_ROOT_CON_ID",k."IS_PROXY_PDB",k."CON_ID",k."UPGRADE_PRIORITY",k."APPLICATION_CLONE",k."FOREIGN_CDB_DBID",k."UNPLUG_SCN",k."FOREIGN_PDB_ID",k."CREATION_TIME",k."REFRESH_MODE",k."REFRESH_INTERVAL",k."TEMPLATE",k."LAST_REFRESH_SCN",k."TENANT_ID",k."SNAPSHOT_MODE",k."SNAPSHOT_INTERVAL", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_PDBS") k
/

comment on table CDB_PDBS is 'Describes all pluggable databases in the consolidated database in all containers'
/

comment on column CDB_PDBS.PDB_ID is 'Id of the pluggable database'
/

comment on column CDB_PDBS.PDB_NAME is 'Name of the pluggable database'
/

comment on column CDB_PDBS.DBID is 'Database id of the pluggable database'
/

comment on column CDB_PDBS.CON_UID is 'Unique ID assigned to the PDB at creation time'
/

comment on column CDB_PDBS.GUID is 'Globally unique immutable ID assigned to the PDB at creation time'
/

comment on column CDB_PDBS.STATUS is 'Status of the pluggable database'
/

comment on column CDB_PDBS.CREATION_SCN is 'SCN for when the pluggable database was created/plugged'
/

comment on column CDB_PDBS.VSN is 'Database version of the PDB'
/

comment on column CDB_PDBS.LOGGING is 'Default logging attribute for the PDB'
/

comment on column CDB_PDBS.FORCE_LOGGING is 'Force logging mode for the PDB'
/

comment on column CDB_PDBS.FORCE_NOLOGGING is 'Force nologging mode for the PDB'
/

comment on column CDB_PDBS.APPLICATION_ROOT is 'Is this PDB an Application Root'
/

comment on column CDB_PDBS.APPLICATION_PDB is 'Is this PDB an Application PDB'
/

comment on column CDB_PDBS.APPLICATION_SEED is 'Is this PDB an Application Seed'
/

comment on column CDB_PDBS.APPLICATION_ROOT_CON_ID is 'Container ID of an Application Root to which this Application PDB belongs, if applicable'
/

comment on column CDB_PDBS.IS_PROXY_PDB is 'Is this PDB a proxy PDB'
/

comment on column CDB_PDBS.CON_ID is 'Id of the pluggable database'
/

comment on column CDB_PDBS.UPGRADE_PRIORITY is 'Upgrade priority of the pluggable database'
/

comment on column CDB_PDBS.APPLICATION_CLONE is 'Is this PDB an Application clone'
/

comment on column CDB_PDBS.FOREIGN_CDB_DBID is 'Foreign Container Database DBID'
/

comment on column CDB_PDBS.UNPLUG_SCN is 'SCN at which the pluggable database was unplugged'
/

comment on column CDB_PDBS.FOREIGN_PDB_ID is 'Foreign pluggable database id'
/

comment on column CDB_PDBS.CREATION_TIME is 'Pluggable database creation timestamp'
/

comment on column CDB_PDBS.REFRESH_MODE is 'Pluggable database refresh mode'
/

comment on column CDB_PDBS.REFRESH_INTERVAL is 'Pluggable database refresh interval in minutes'
/

comment on column CDB_PDBS.TEMPLATE is 'Is this PDB a template PDB'
/

comment on column CDB_PDBS.LAST_REFRESH_SCN is 'Until SCN for the last successful refresh'
/

comment on column CDB_PDBS.TENANT_ID is 'Pluggable database tenant key'
/

comment on column CDB_PDBS.SNAPSHOT_MODE is 'Pluggable database snapshot mode'
/

comment on column CDB_PDBS.SNAPSHOT_INTERVAL is 'Pluggable database snapshot interval in minutes'
/

