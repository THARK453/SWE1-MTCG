create view ALL_XML_NESTED_TABLES (OWNER, TABLE_NAME, NESTED_TABLE_NAME, PARENT_COLUMN_NAME) as
select x.OWNER,
       x.TABLE_NAME,
       NESTED_TABLE_NAME,
       'OBJECT_VALUE' PARENT_COLUMN_NAME
  from ALL_XML_TABLES x,
       (
         select TABLE_NAME NESTED_TABLE_NAME,
                connect_by_root PARENT_TABLE_NAME PARENT_TABLE_NAME, OWNER
           from ALL_NESTED_TABLES nt
                connect by prior TABLE_NAME = PARENT_TABLE_NAME
                       and OWNER = OWNER
       ) nt
 where x.TABLE_NAME = nt.PARENT_TABLE_NAME
   and x.OWNER = nt.OWNER
UNION ALL
select x.OWNER,
       x.TABLE_NAME,
       NESTED_TABLE_NAME,
       x.COLUMN_NAME PARENT_COLUMN_NAME
 from ALL_XML_TAB_COLS x,
(
select TABLE_NAME NESTED_TABLE_NAME,
                connect_by_root PARENT_TABLE_NAME PARENT_TABLE_NAME, OWNER
           from ALL_NESTED_TABLES nt
                connect by prior TABLE_NAME = PARENT_TABLE_NAME
                       and OWNER = OWNER
       ) nt
where x.TABLE_NAME = nt.PARENT_TABLE_NAME and
x.owner = nt.OWNER
/

