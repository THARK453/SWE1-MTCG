create TYPE XS$PRIVILEGE FORCE AS OBJECT (

-- Name of the privilege
name             VARCHAR2(261),

-- Implied privileges
implied_priv_list XS$NAME_LIST,

-- Description for the privilege
description      VARCHAR2(4000),

-- Constructor Function
CONSTRUCTOR FUNCTION XS$PRIVILEGE
                    (name              IN VARCHAR2,
                     implied_priv_list IN XS$NAME_LIST := NULL,
                     description       IN VARCHAR2 := NULL)
                     RETURN SELF AS RESULT,

-- Get name of the privilege
MEMBER FUNCTION GET_NAME RETURN VARCHAR2,
-- Get description of the privilege
MEMBER FUNCTION GET_DESCRIPTION RETURN VARCHAR2,
-- get implied privilege
MEMBER FUNCTION GET_IMPLIED_PRIVILEGES RETURN XS$NAME_LIST,

-- Set description for the privilege
MEMBER PROCEDURE SET_DESCRIPTION (description IN VARCHAR2),

-- Set a list of implied privileges for the aggregate privilege
MEMBER PROCEDURE SET_IMPLIED_PRIVILEGES (implied_priv_list IN XS$NAME_LIST)
);
/

