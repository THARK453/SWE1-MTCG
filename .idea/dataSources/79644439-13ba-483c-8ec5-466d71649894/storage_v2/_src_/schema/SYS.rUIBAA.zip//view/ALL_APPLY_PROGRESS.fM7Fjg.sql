create view ALL_APPLY_PROGRESS
            (APPLY_NAME, SOURCE_DATABASE, APPLIED_MESSAGE_NUMBER, OLDEST_MESSAGE_NUMBER, APPLY_TIME,
             APPLIED_MESSAGE_CREATE_TIME, OLDEST_TRANSACTION_ID, SPILL_MESSAGE_NUMBER, SOURCE_ROOT_NAME)
as
select ap.apply_name, ap.source_database, ap.applied_message_number,
       ap.oldest_message_number, ap.apply_time, ap.applied_message_create_time,
       ap.oldest_transaction_id, ap.spill_message_number, ap.source_root_name
  from dba_apply_progress ap, all_apply a
 where ap.apply_name = a.apply_name
/

comment on table ALL_APPLY_PROGRESS is 'Information about the progress made by the apply process that dequeues from the queue visible to the current user'
/

comment on column ALL_APPLY_PROGRESS.APPLY_NAME is 'Name of the apply process'
/

comment on column ALL_APPLY_PROGRESS.SOURCE_DATABASE is 'Applying messages originating from this database'
/

comment on column ALL_APPLY_PROGRESS.APPLIED_MESSAGE_NUMBER is 'All messages before this number have been successfully applied'
/

comment on column ALL_APPLY_PROGRESS.OLDEST_MESSAGE_NUMBER is 'Earliest commit number of the transactions currently being applied'
/

comment on column ALL_APPLY_PROGRESS.APPLY_TIME is 'Time at which the message was applied'
/

comment on column ALL_APPLY_PROGRESS.APPLIED_MESSAGE_CREATE_TIME is 'Time at which the message to be applied was created'
/

comment on column ALL_APPLY_PROGRESS.OLDEST_TRANSACTION_ID is 'Earliest transaction id currently being applied'
/

comment on column ALL_APPLY_PROGRESS.SPILL_MESSAGE_NUMBER is 'Spill low water mark SCN'
/

comment on column ALL_APPLY_PROGRESS.SOURCE_ROOT_NAME is 'Global name of the source root database'
/

