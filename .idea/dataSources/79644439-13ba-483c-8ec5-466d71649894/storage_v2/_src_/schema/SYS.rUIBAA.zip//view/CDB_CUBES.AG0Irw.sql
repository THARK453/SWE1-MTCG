create view CDB_CUBES
            (OWNER, CUBE_NAME, CUBE_ID, AW_NAME, CONSISTENT_SOLVE_SPEC, DESCRIPTION, SPARSE_TYPE, PRECOMPUTE_CONDITION,
             PRECOMPUTE_PERCENT, PRECOMPUTE_PERCENT_TOP, PARTITION_DIMENSION_NAME, PARTITION_HIERARCHY_NAME,
             PARTITION_LEVEL_NAME, REFRESH_MVIEW_NAME, REWRITE_MVIEW_NAME, DEFAULT_BUILD_SPEC, MEASURE_STORAGE,
             SQL_CUBE_STORAGE_TYPE, CUBE_STORAGE_TYPE, CON_ID)
as
SELECT k."OWNER",k."CUBE_NAME",k."CUBE_ID",k."AW_NAME",k."CONSISTENT_SOLVE_SPEC",k."DESCRIPTION",k."SPARSE_TYPE",k."PRECOMPUTE_CONDITION",k."PRECOMPUTE_PERCENT",k."PRECOMPUTE_PERCENT_TOP",k."PARTITION_DIMENSION_NAME",k."PARTITION_HIERARCHY_NAME",k."PARTITION_LEVEL_NAME",k."REFRESH_MVIEW_NAME",k."REWRITE_MVIEW_NAME",k."DEFAULT_BUILD_SPEC",k."MEASURE_STORAGE",k."SQL_CUBE_STORAGE_TYPE",k."CUBE_STORAGE_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CUBES") k
/

comment on table CDB_CUBES is 'OLAP Cubes in the database in all containers'
/

comment on column CDB_CUBES.OWNER is 'Owner of the OLAP Cube'
/

comment on column CDB_CUBES.CUBE_NAME is 'Name of the OLAP Cube'
/

comment on column CDB_CUBES.CUBE_ID is 'Dictionary Id of the OLAP Cube'
/

comment on column CDB_CUBES.AW_NAME is 'Name of the Analytic Workspace which owns the OLAP Cube'
/

comment on column CDB_CUBES.CONSISTENT_SOLVE_SPEC is 'The Consistent Solve Specification for the OLAP Cube'
/

comment on column CDB_CUBES.DESCRIPTION is 'Long Description of the OLAP Cube'
/

comment on column CDB_CUBES.SPARSE_TYPE is 'Text value indicating type of sparsity for the OLAP Cube'
/

comment on column CDB_CUBES.PRECOMPUTE_CONDITION is 'Condition syntax representing precompute condition of the OLAP Cube'
/

comment on column CDB_CUBES.PRECOMPUTE_PERCENT is 'Precompute percent of the OLAP Cube'
/

comment on column CDB_CUBES.PRECOMPUTE_PERCENT_TOP is 'Top precompute percent of the OLAP Cube'
/

comment on column CDB_CUBES.PARTITION_DIMENSION_NAME is 'Name of the Cube Dimension for which there is a partition on the OLAP Cube'
/

comment on column CDB_CUBES.PARTITION_HIERARCHY_NAME is 'Name of the Hierarchy for which there is a partition on the OLAP Cube'
/

comment on column CDB_CUBES.PARTITION_LEVEL_NAME is 'Name of the HierarchyLevel for which there is a partition on the OLAP Cube'
/

comment on column CDB_CUBES.REFRESH_MVIEW_NAME is 'Name of the refresh materialized view for the OLAP Cube'
/

comment on column CDB_CUBES.REWRITE_MVIEW_NAME is 'Name of the rewrite materialized view for the OLAP Cube'
/

comment on column CDB_CUBES.DEFAULT_BUILD_SPEC is 'The Default Build Specification for the OLAP Cube'
/

comment on column CDB_CUBES.MEASURE_STORAGE is 'The Measure Storage for the OLAP Cube'
/

comment on column CDB_CUBES.SQL_CUBE_STORAGE_TYPE is 'The SQL Cube Storage Type for the OLAP Cube'
/

comment on column CDB_CUBES.CUBE_STORAGE_TYPE is 'The Cube Storage Type for the OLAP Cube'
/

comment on column CDB_CUBES.CON_ID is 'container id'
/

