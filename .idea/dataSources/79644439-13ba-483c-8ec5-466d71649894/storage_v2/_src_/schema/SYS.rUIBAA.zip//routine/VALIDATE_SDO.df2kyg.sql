create PROCEDURE      validate_sdo IS
cnt number;
v_value varchar(64);
BEGIN

    SELECT value INTO  v_value from  v$option WHERE parameter = 'Spatial';
     if v_value = 'FALSE' then
       -- set status OPTION OFF
       sys.dbms_registry.set_rdbms_status('SDO',9);
       return;
     end if;

    select count(*) into cnt from sys.dba_invalid_objects where status = 'INVALID'
           and OWNER='MDSYS';

     if cnt > 0 then
       dbms_registry.invalid('SDO');
       return;
     end if;

    dbms_registry.valid('SDO');
END;
/

