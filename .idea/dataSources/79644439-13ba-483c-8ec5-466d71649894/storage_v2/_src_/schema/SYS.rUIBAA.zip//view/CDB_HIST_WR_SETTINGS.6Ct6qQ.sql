create view CDB_HIST_WR_SETTINGS (LOCAL_AWRDBID, VIEW_LOCATION, CON_ID) as
SELECT k."LOCAL_AWRDBID",k."VIEW_LOCATION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_WR_SETTINGS") k
/

comment on table CDB_HIST_WR_SETTINGS is 'Workload Repository Settings in all containers'
/

comment on column CDB_HIST_WR_SETTINGS.CON_ID is 'container id'
/

