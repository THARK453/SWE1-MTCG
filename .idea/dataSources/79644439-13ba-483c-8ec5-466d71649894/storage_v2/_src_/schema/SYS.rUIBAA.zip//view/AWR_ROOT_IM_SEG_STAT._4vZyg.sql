create view AWR_ROOT_IM_SEG_STAT
            (SNAP_ID, DBID, INSTANCE_NUMBER, TS#, OBJ#, DATAOBJ#, MEMBYTES, SCANS, SCANS_DELTA, DB_BLOCK_CHANGES,
             DB_BLOCK_CHANGES_DELTA, POPULATE_CUS, POPULATE_CUS_DELTA, REPOPULATE_CUS, REPOPULATE_CUS_DELTA, CON_DBID,
             CON_ID)
as
select seg.snap_id, seg.dbid, seg.instance_number, ts#,
obj#, dataobj#, 0,
im_scans_total as scans, im_scans_delta as scans_delta,
im_db_block_changes_total as db_block_changes,
im_db_block_changes_delta as db_block_changes_delta,
populate_cus_total as populate_cus, populate_cus_delta,
repopulate_cus_total as repopulate_cus, repopulate_cus_delta,
decode(seg.con_dbid, 0, seg.dbid, seg.con_dbid),
decode(seg.per_pdb, 0, 0,
       con_dbid_to_id(decode(seg.con_dbid, 0, seg.dbid, seg.con_dbid))) con_id
from AWR_ROOT_SNAPSHOT sn, WRH$_SEG_STAT seg
where
        seg.snap_id         = sn.snap_id
    and seg.dbid            = sn.dbid
    and seg.instance_number = sn.instance_number
    and ((seg.im_scans_total > 0) or (seg.populate_cus_total > 0) or
         (seg.repopulate_cus_total > 0) or (seg.im_db_block_changes_total > 0))
union
select seg.snap_id, seg.dbid, seg.instance_number, ts#,
obj#, dataobj#, membytes,
scans, scans_delta,
db_block_changes,  db_block_changes_delta,
populate_cus, populate_cus_delta,
repopulate_cus, repopulate_cus_delta,
decode(seg.con_dbid, 0, seg.dbid, seg.con_dbid),
decode(seg.per_pdb, 0, 0,
       con_dbid_to_id(decode(seg.con_dbid, 0, seg.dbid, seg.con_dbid))) con_id
from AWR_ROOT_SNAPSHOT sn, WRH$_IM_SEG_STAT seg
where
        seg.snap_id         = sn.snap_id
    and seg.dbid            = sn.dbid
    and seg.instance_number = sn.instance_number
/

comment on table AWR_ROOT_IM_SEG_STAT is ' Historical IM Segment Statistics Information'
/

