create TYPE BODY wri$_rept_statsadv wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
ac db
GVI1zRB52/QQ/qzYxpJp8qtdsa4wgy7wf5kVfC8CkPjVSLhQPSpet3H2yr6Jgj6fngJ7U6H9
0rsSFuPrhhIovJzo+zWA2q/27bvZIxJ3wj2+SE6bNr/epgbjR/97/KhwUIVQAWX66awcXjh2
ZrBqeEZ7kRTWj+fUp9e+Q+vMVl8+gq8qzhTQCc9oqxKA8Z2Qwv7ynhT4F+rwS4Pt+/qF0fE=

/

