create view MV_REFRESH_USAGE_STATS (MV_TYPE#, REFRESH_METHOD#, REFRESH_MODE#, OUT_OF_PLACE#, ATOMIC#, COUNT#) as
select mv_type#, refresh_method#, refresh_mode#, out_of_place#, atomic#,
          sum(count#)
from sys.mv_refresh_usage_stats$
group by mv_type#, refresh_method#, refresh_mode#, out_of_place#, atomic#
/

comment on table MV_REFRESH_USAGE_STATS is 'MV refresh usage statistics'
/

comment on column MV_REFRESH_USAGE_STATS.MV_TYPE# is 'MV type, can be MAV, MJV, MAV1 or OTHER'
/

comment on column MV_REFRESH_USAGE_STATS.REFRESH_METHOD# is 'MV refresh method, can be fast, PCT, complete or sync refresh'
/

comment on column MV_REFRESH_USAGE_STATS.REFRESH_MODE# is 'MV refresh mode, can be on commit or on demand'
/

comment on column MV_REFRESH_USAGE_STATS.OUT_OF_PLACE# is 'whether it is out-of-place refresh'
/

comment on column MV_REFRESH_USAGE_STATS.ATOMIC# is 'whether it is atomic refresh'
/

comment on column MV_REFRESH_USAGE_STATS.COUNT# is 'count of a certain refresh case'
/

