create PROCEDURE xoq_validate IS
  compat          VARCHAR2(30);
  dummy_num       NUMBER;
  dummy_out_1_str VARCHAR2(100);
  dummy_out_2_str VARCHAR2(100);
  ok              BOOLEAN := TRUE;
  v_Value         varchar2(64);
  e_level         BINARY_INTEGER;
  new_e_level     BINARY_INTEGER;
BEGIN

  -- get current event level
  sys.dbms_system.read_ev(37396, e_level);
  -- check compatible
  SELECT value INTO compat FROM v$parameter WHERE name='compatible';
  IF NOT (substr(compat,1,3) >= '9.2' OR substr(compat,1,2) >= '10') THEN
    ok := FALSE;
  END IF;

  IF ok THEN
    -- check that dependent component XDB is loaded
    IF sys.dbms_registry.is_loaded('XDB')
        != 1 THEN
      ok := FALSE;
    END IF;
  END IF;

  IF ok THEN
   -- check that expected XDB resources are there
    IF NOT (dbms_xdb.existsresource('/olap_data_security/public/acls') AND
            dbms_xdb.existsresource('/xds/dsd')) THEN
      ok := FALSE;
    END IF;
  END IF;

  IF ok THEN
    -- check that installed library is valid
    BEGIN
      SELECT 0 INTO dummy_num FROM DBA_LIBRARIES
        WHERE STATUS = 'INVALID' AND rownum <=1 AND
          OWNER='SYS' AND LIBRARY_NAME = 'DBMS_OLAPI_LIB';
      -- at least one object is invalid so component is invalid
      ok := FALSE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      -- no invalid objects were found so component remains valid
        NULL;
    END;
  END IF;

  IF ok THEN
    -- check very basic OLAP API function (including load of shared library)
    BEGIN
    select e_level + 2048 - bitand(e_level, 2048) into new_e_level from dual;
    EXECUTE IMMEDIATE 'alter session set events=''37396 trace name context forever,  level '||to_char(new_e_level)||'''';

      dummy_num := OlapiBootstrap2(compat, dummy_out_1_str, dummy_out_2_str);
    EXECUTE IMMEDIATE 'alter session set events=''37396 trace name context forever,  level '||to_char(e_level)||'''';
    EXCEPTION
      WHEN OTHERS THEN
        EXECUTE IMMEDIATE 'alter session set events=''37396 trace name context forever,  level '||to_char(e_level)||'''';
        ok := FALSE;
    END;
  END IF;

  IF ok THEN
    -- check that Java classes are loaded successfully
    BEGIN
      SELECT 0 INTO dummy_num FROM dba_objects
        WHERE owner = 'SYS' AND
             status = 'INVALID' AND
             object_type = 'JAVA CLASS' AND
             object_name LIKE 'oracle/AWXML/%';
      -- at least one class is invalid so component is invalid
      ok := FALSE;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- no invalid components were found so component remains valid
      NULL;
    END;
  END IF;

  IF ok THEN
    -- check that installed types, packages, and procedures are valid
    BEGIN
      SELECT 0 INTO dummy_num FROM DBA_OBJECTS
        WHERE STATUS = 'INVALID' AND rownum <=1 AND
          OWNER='SYS' AND OBJECT_NAME IN
             ('DBMS_CUBE_ADVISE','DBMS_CUBE_ADVISE_SEC','DBMS_CUBE',
              'DBMS_CUBE_EXP','GENDATABASEINTERFACE','GENCONNECTIONINTERFACE',
              'GENSERVERINTERACE','GENMDMPROPERTYIDCONSTANTS',
              'GENMDMCLASSCONSTANTS','GENMDMOBJECTIDCONSTANTS',
              'GENMETADATAPROVIDERINTERFACE','GENCURSORMANAGERINTERFACE',
              'GENDATATYPEIDCONSTANTS','GENDEFINITIONMANAGERINTERFACE',
              'GENDATAPROVIDERINTERFACE','DBMS_AW_XML','DBMS_CUBE_UTIL',
              'COAD_ADVICE_T','COAD_ADVICE_REC','GENOLAPIEXCEPTION',
              'GENINTERFACESTUB', 'GENINTERFACESTUBSEQUENCE',
              'GENRAWSEQUENCE','GENWSTRINGSEQUENCE',
              'DBMS_CUBE_UTIL_EXT_MD_T','DBMS_CUBE_UTIL_EXT_MD_R',
              'OLAPIHANDSHAKE2','OLAPIBOOTSTRAP2');
      -- at least one object is invalid so component is invalid
      ok := FALSE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      -- no invalid objects were found so component remains valid
        NULL;
    END;
  END IF;

  IF ok THEN
    -- check for expected role
    BEGIN
      SELECT 0 INTO dummy_num FROM DBA_ROLES
        WHERE ROLE = 'OLAP_XS_ADMIN';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ok := FALSE;
    END;
  END IF;

  IF ok THEN
    -- Address bug 17997122 by carefully checking OLAP_XS_ADMIN role
    -- privileges against the DBA_TAB_PRIVS view.
    -- check for privileges granted as local granted privileges, COMMON='NO'

    -- Bug 21856522 As of 12.2 Privs on sys owned pl/sql packages can be common = no or
    -- common = yes
    SELECT COUNT(*) INTO dummy_num
    FROM DBA_TAB_PRIVS
    WHERE GRANTEE='OLAP_XS_ADMIN' AND
          PRIVILEGE='EXECUTE' AND
          OWNER='SYS' AND
          TABLE_NAME='DBMS_XDS';

    IF dummy_num = 0 THEN
       -- Missing grant to pl/sql package, so invalid
       ok := FALSE;
    END IF;
  END IF;

  IF ok THEN
    SELECT COUNT(*) INTO dummy_num
    FROM DBA_TAB_PRIVS
    WHERE GRANTEE='OLAP_XS_ADMIN' AND
          ((PRIVILEGE='SELECT' AND OWNER='SYS' AND
             TABLE_NAME='XS$OLAP_POLICY' AND COMMON='NO') OR
           (PRIVILEGE='SELECT' AND OWNER='SYS' AND
             TABLE_NAME='DBA_ROLES' AND COMMON='NO'));

    IF dummy_num = 0 THEN
      -- No local granted privileges
      -- check to see if grants are common granted privileges, COMMON = 'YES'
      SELECT COUNT(*) INTO dummy_num
      FROM DBA_TAB_PRIVS
      WHERE GRANTEE='OLAP_XS_ADMIN' AND
            ((PRIVILEGE='SELECT' AND OWNER='SYS' AND
               TABLE_NAME='XS$OLAP_POLICY' AND COMMON='YES') OR
             (PRIVILEGE='SELECT' AND OWNER='SYS' AND
               TABLE_NAME='DBA_ROLES' AND COMMON='YES'));
      IF dummy_num != 2 THEN
        -- Incomplete set of common granted privileges granted, so invalid
        ok := FALSE;
      END IF;

    ELSIF dummy_num = 2 THEN
      --  Grants are valid for local granted privileges.
      --  Now grants may also be a common granted privilege, COMMON = 'YES'
      SELECT COUNT(*) INTO dummy_num
      FROM DBA_TAB_PRIVS
      WHERE GRANTEE='OLAP_XS_ADMIN' AND
            ((PRIVILEGE='SELECT' AND OWNER='SYS' AND
               TABLE_NAME='XS$OLAP_POLICY' AND COMMON='YES') OR
             (PRIVILEGE='SELECT' AND OWNER='SYS' AND
               TABLE_NAME='DBA_ROLES' AND COMMON='YES'));
      IF dummy_num = 0 THEN
        -- No Common granted privileges granted,
        -- but still valid because of valid local granted privileges
        ok := TRUE;
      ELSIF dummy_num != 2 THEN
        -- Incomplete set of common granted privileges granted, so invalid
        ok := FALSE;
      END IF;
    ELSE
      -- Incomplete set of local granted privileges granted, so invalid
      ok := FALSE;
    END IF;
  END IF;

  IF ok THEN
    SELECT value INTO v_Value FROM v$option WHERE parameter = 'OLAP';
    if v_Value = 'FALSE' then
      -- set status OPTION OFF
      sys.dbms_registry.Option_Off('XOQ');
    else
      sys.dbms_registry.valid('XOQ');
    end if;
  ELSE
    sys.dbms_registry.invalid('XOQ');
  END IF;
END;
/

