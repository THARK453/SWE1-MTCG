create type wri$_adv_objspace_trend_t under wri$_adv_abstract_t
(
  overriding member procedure sub_execute (task_id IN  NUMBER,
                                           err_num OUT NUMBER)
);
/

