create view DBA_MVIEW_LOGS
            (LOG_OWNER, MASTER, LOG_TABLE, LOG_TRIGGER, ROWIDS, PRIMARY_KEY, OBJECT_ID, FILTER_COLUMNS, SEQUENCE,
             INCLUDE_NEW_VALUES, PURGE_ASYNCHRONOUS, PURGE_DEFERRED, PURGE_START, PURGE_INTERVAL, LAST_PURGE_DATE,
             LAST_PURGE_STATUS, NUM_ROWS_PURGED, COMMIT_SCN_BASED, STAGING_LOG)
as
select m.mowner, m.master, m.log, m.trig,
       decode(bitand(m.flag,1), 0, 'NO', 'YES'),
       decode(bitand(m.flag,2), 0, 'NO', 'YES'),
       decode(bitand(m.flag,512), 0, 'NO', 'YES'),
       decode(bitand(m.flag,4), 0, 'NO', 'YES'),
       decode(bitand(m.flag,1024), 0, 'NO', 'YES'),
       decode(bitand(m.flag,16), 0, 'NO', 'YES'),
       decode(bitand(m.flag,16384), 0, 'NO', 'YES'),
       decode(bitand(m.flag,32768), 0, 'NO', 'YES'),
       purge_start, purge_next, last_purge_date,
       last_purge_status, rows_purged,
       decode(bitand(m.flag, 65536), 0, 'NO', 'YES'),
       'NO'
from sys.mlog$ m
union
select u1.name, o2.name, o1.name, null, null, null,
       null, null, null, null, null, null, null, null, null, null, null,
       null, 'YES'
from sys.syncref$_table_info srt, sys.obj$ o1, sys.user$ u1,
     sys.obj$ o2
where o1.owner# = u1.user# and o1.obj# = srt.staging_log_obj#
      and o2.obj# = srt.table_obj#
/

comment on table DBA_MVIEW_LOGS is 'All materialized view logs in the database'
/

comment on column DBA_MVIEW_LOGS.LOG_OWNER is 'Owner of the materialized view log'
/

comment on column DBA_MVIEW_LOGS.MASTER is 'Name of the master table which changes are logged'
/

comment on column DBA_MVIEW_LOGS.LOG_TABLE is 'Log table; with rowids and timestamps of rows which changed in the master'
/

comment on column DBA_MVIEW_LOGS.LOG_TRIGGER is 'An after-row trigger on the master which inserts rows into the log'
/

comment on column DBA_MVIEW_LOGS.ROWIDS is 'If YES, the materialized view log records rowid information'
/

comment on column DBA_MVIEW_LOGS.PRIMARY_KEY is 'If YES, the materialized view log records primary key information'
/

comment on column DBA_MVIEW_LOGS.OBJECT_ID is 'If YES, the materialized view log records object id information'
/

comment on column DBA_MVIEW_LOGS.FILTER_COLUMNS is 'If YES, the materialized view log records filter column information'
/

comment on column DBA_MVIEW_LOGS.SEQUENCE is 'If YES, the materialized view log records sequence information'
/

comment on column DBA_MVIEW_LOGS.INCLUDE_NEW_VALUES is 'If YES, the materialized view log records old and new values (else only old values)'
/

comment on column DBA_MVIEW_LOGS.PURGE_ASYNCHRONOUS is 'If YES, the materialized view log is purged asynchronously'
/

comment on column DBA_MVIEW_LOGS.PURGE_DEFERRED is 'If YES, the materialized view log is purged in a deferred manner'
/

comment on column DBA_MVIEW_LOGS.PURGE_START is 'For deferred purge, the purge start date'
/

comment on column DBA_MVIEW_LOGS.PURGE_INTERVAL is 'For deferred purge, the purge interval'
/

comment on column DBA_MVIEW_LOGS.LAST_PURGE_DATE is 'Date of the last purge'
/

comment on column DBA_MVIEW_LOGS.LAST_PURGE_STATUS is 'Status of the last purge: error code or 0 for success'
/

comment on column DBA_MVIEW_LOGS.NUM_ROWS_PURGED is 'Number of rows purged in the last purge'
/

comment on column DBA_MVIEW_LOGS.COMMIT_SCN_BASED is 'If YES, the materialized view log is commit SCN-based'
/

comment on column DBA_MVIEW_LOGS.STAGING_LOG is 'If YES, the log is a staging log for synchronous refresh'
/

