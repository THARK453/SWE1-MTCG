create view ALL_XSTREAM_RULES
            (STREAMS_NAME, STREAMS_TYPE, STREAMS_RULE_TYPE, RULE_SET_OWNER, RULE_SET_NAME, RULE_SET_TYPE, RULE_OWNER,
             RULE_NAME, RULE_TYPE, RULE_CONDITION, SCHEMA_NAME, OBJECT_NAME, INCLUDE_TAGGED_LCR, SUBSETTING_OPERATION,
             DML_CONDITION, SOURCE_DATABASE, ORIGINAL_RULE_CONDITION, SAME_RULE_CONDITION, SOURCE_ROOT_NAME,
             SOURCE_CONTAINER_NAME)
as
select r."STREAMS_NAME",r."STREAMS_TYPE",r."STREAMS_RULE_TYPE",r."RULE_SET_OWNER",r."RULE_SET_NAME",r."RULE_SET_TYPE",r."RULE_OWNER",r."RULE_NAME",r."RULE_TYPE",r."RULE_CONDITION",r."SCHEMA_NAME",r."OBJECT_NAME",r."INCLUDE_TAGGED_LCR",r."SUBSETTING_OPERATION",r."DML_CONDITION",r."SOURCE_DATABASE",r."ORIGINAL_RULE_CONDITION",r."SAME_RULE_CONDITION",r."SOURCE_ROOT_NAME",r."SOURCE_CONTAINER_NAME"
  from dba_xstream_rules r, "_ALL_STREAMS_PROCESSES" p
where r.streams_type = p.streams_type
  and r.streams_name = p.streams_name
/

comment on table ALL_XSTREAM_RULES is 'Details about the XStream server rules visible to user'
/

comment on column ALL_XSTREAM_RULES.STREAMS_NAME is 'Name of the Streams process'
/

comment on column ALL_XSTREAM_RULES.STREAMS_TYPE is 'Type of the Streams process: CAPTURE or APPLY'
/

comment on column ALL_XSTREAM_RULES.STREAMS_RULE_TYPE is 'For global, schema or table rules, type of rule: TABLE, SCHEMA or GLOBAL'
/

comment on column ALL_XSTREAM_RULES.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column ALL_XSTREAM_RULES.RULE_SET_NAME is 'Name of the rule set'
/

comment on column ALL_XSTREAM_RULES.RULE_SET_TYPE is 'Type of the rule set: POSITIVE or NEGATIVE'
/

comment on column ALL_XSTREAM_RULES.RULE_OWNER is 'Owner of the rule'
/

comment on column ALL_XSTREAM_RULES.RULE_NAME is 'Name of the rule'
/

comment on column ALL_XSTREAM_RULES.RULE_TYPE is 'For global, schema or table rules, type of rule: DML, DDL or PROCEDURE'
/

comment on column ALL_XSTREAM_RULES.RULE_CONDITION is 'Current rule condition'
/

comment on column ALL_XSTREAM_RULES.SCHEMA_NAME is 'For table and schema rules, the schema name'
/

comment on column ALL_XSTREAM_RULES.OBJECT_NAME is 'For table rules, the table name'
/

comment on column ALL_XSTREAM_RULES.INCLUDE_TAGGED_LCR is 'For global, schema or table rules, whether or not to include tagged LCRs'
/

comment on column ALL_XSTREAM_RULES.SUBSETTING_OPERATION is 'For subset rules, the type of operation: INSERT, UPDATE, or DELETE'
/

comment on column ALL_XSTREAM_RULES.DML_CONDITION is 'For subset rules, the row subsetting condition'
/

comment on column ALL_XSTREAM_RULES.SOURCE_DATABASE is 'For global, schema or table rules, the name of the database where the LCRs originated'
/

comment on column ALL_XSTREAM_RULES.ORIGINAL_RULE_CONDITION is 'For rules created by Streams administrative APIs, the original rule condition when the rule was created'
/

comment on column ALL_XSTREAM_RULES.SAME_RULE_CONDITION is 'For rules created by Streams administrative APIs, whether or not the current rule condition is the same as the original rule condition'
/

comment on column ALL_XSTREAM_RULES.SOURCE_ROOT_NAME is 'Root Database where the transactions originated'
/

