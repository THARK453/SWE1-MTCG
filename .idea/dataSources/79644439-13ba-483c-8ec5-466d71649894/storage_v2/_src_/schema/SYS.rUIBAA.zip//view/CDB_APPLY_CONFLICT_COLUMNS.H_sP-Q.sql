create view CDB_APPLY_CONFLICT_COLUMNS
            (OBJECT_OWNER, OBJECT_NAME, METHOD_NAME, RESOLUTION_COLUMN, COLUMN_NAME, APPLY_DATABASE_LINK, CON_ID) as
SELECT k."OBJECT_OWNER",k."OBJECT_NAME",k."METHOD_NAME",k."RESOLUTION_COLUMN",k."COLUMN_NAME",k."APPLY_DATABASE_LINK",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_APPLY_CONFLICT_COLUMNS") k
/

comment on table CDB_APPLY_CONFLICT_COLUMNS is 'Details about conflict resolution in all containers'
/

comment on column CDB_APPLY_CONFLICT_COLUMNS.OBJECT_OWNER is 'Owner of the object'
/

comment on column CDB_APPLY_CONFLICT_COLUMNS.OBJECT_NAME is 'Name of the object'
/

comment on column CDB_APPLY_CONFLICT_COLUMNS.METHOD_NAME is 'Name of the method used to resolve conflict'
/

comment on column CDB_APPLY_CONFLICT_COLUMNS.RESOLUTION_COLUMN is 'Name of the column used to resolve conflict'
/

comment on column CDB_APPLY_CONFLICT_COLUMNS.COLUMN_NAME is 'Name of the column that is to be considered as part of a group to resolve conflict'
/

comment on column CDB_APPLY_CONFLICT_COLUMNS.APPLY_DATABASE_LINK is 'For remote objects, name of database link pointing to remote database'
/

comment on column CDB_APPLY_CONFLICT_COLUMNS.CON_ID is 'container id'
/

