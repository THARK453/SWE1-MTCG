create package body     wpiutl as

  --------------------------------
  -- List of private subprograms
  --------------------------------
  -- Driving the whole process
  PROCEDURE driver(objnum NUMBER, ownerName VARCHAR2, objname VARCHAR2,
                   subname VARCHAR2, pnames IN OUT tvarchar,
                   ptnames IN OUT tvarchar, ptypes IN OUT tvchar3,
                   status OUT PLS_INTEGER, misdef OUT VARCHAR2,
                   nename OUT VARCHAR2);

  -- Find subprograms and describe the parameters
  PROCEDURE describe(objn NUMBER, name VARCHAR2, subname VARCHAR2,
                     usr VARCHAR2, prefix VARCHAR2, pnames tvarchar,
                     ptnames IN OUT tvarchar, ptypes IN OUT tvchar3,
                     status OUT PLS_INTEGER, misdef OUT VARCHAR2,
                     nename OUT VARCHAR2);
  pragma interface(C, describe);  /* first entry of this package ICD */

  -- Normalize names
  FUNCTION normalname(name VARCHAR2) RETURN VARCHAR2;

  ------------------------------------------------------------------------
  --            Public suprogram implementation                         --
  ------------------------------------------------------------------------
  PROCEDURE subpparam(objnum NUMBER, name VARCHAR2, subname VARCHAR2,
                      prename VARCHAR2, status OUT NUMBER, misdef OUT VARCHAR2,
                      nename OUT VARCHAR2) IS
    pnames tvarchar;
    ptnames tvarchar;
    ptypes tvchar3;
  BEGIN
    driver(objnum, prename, name, subname, pnames, ptnames, ptypes,
           status, misdef, nename);
  END;

  PROCEDURE subpparam(objnum NUMBER, name VARCHAR2, subname VARCHAR2,
                      prename VARCHAR2, pnames IN OUT tvarchar,
                      ptnames IN OUT tvarchar, ptypes IN OUT tvchar3,
                      status OUT NUMBER, misdef OUT VARCHAR2,
                      nename OUT VARCHAR2) IS
  BEGIN
    driver(objnum, prename, name, subname, pnames, ptnames, ptypes,
           status, misdef, nename);
  END;

  PROCEDURE subpfparam(objnum NUMBER, name VARCHAR2, subname VARCHAR2,
                       prename VARCHAR2, pnames IN tvarchar,
                       ptnames IN OUT tvarchar, ptypes IN tvchar3,
                       status OUT NUMBER, misdef OUT VARCHAR2,
                       nename OUT VARCHAR2) IS
    vpnames tvarchar;
    vptypes tvchar3;
    tmisdef VARCHAR2(4096);
    tnename VARCHAR2(4096);
    tstatus PLS_INTEGER;
  BEGIN
    vpnames(1) := pnames(2);
    vpnames(2) := pnames(3);
    vptypes(1) := ptypes(2);
    vptypes(2) := ptypes(3);

    driver(objnum, prename, name, subname, vpnames, ptnames, vptypes,
           status, tmisdef, tnename);

    IF (status != s_ok) THEN
      vpnames := pnames;
      vptypes := ptypes;
      driver(objnum, prename, name, subname, vpnames, ptnames, vptypes,
             tstatus, tmisdef, tnename);
      IF (tstatus = s_ok) THEN
        status := tstatus;
        misdef := NULL;
        nename := NULL;
      END IF;
    END IF;
  END;


  ------------------------------------------------------------------------
  --                                                                    --
  --      Private subprogram implementation                             --
  --                                                                    --
  ------------------------------------------------------------------------
  PROCEDURE driver(objnum NUMBER, ownerName VARCHAR2, objname VARCHAR2,
                   subname VARCHAR2, pnames IN OUT tvarchar,
                   ptnames IN OUT tvarchar, ptypes IN OUT tvchar3,
                   status OUT PLS_INTEGER, misdef OUT VARCHAR2,
                   nename OUT VARCHAR2) IS

    -- prefix string. This prefix string is computed here and later used
    -- to compute the fully elaborated name. It is not used for name
    -- resolution.
    prefix dbms_quoted_id := null;

  BEGIN

    -- bug 26148849:
    -- In this bug fix, the dependency on the user builtin has been removed
    -- and prefix is now always ownerName followed by a '.' if ownerName is
    -- not a NULL string.
    if(ownerName is not null) then
      prefix := ownerName || '.';
    end if;

    -- Normalize name before comparison
    FOR i IN 1..pnames.count LOOP
      pnames(i) := normalname(pnames(i));
    END LOOP;

    describe(objnum, objname, subname, ownerName, prefix,
             pnames, ptnames, ptypes, status, misdef, nename);
  END driver;

  -----------------------
  -- normalname: RETURN a normalized name.
  -----------------------
  FUNCTION normalname(name VARCHAR2) RETURN VARCHAR2 IS
    firstchar VARCHAR2(4);
    len NUMBER;
  BEGIN
    IF (name IS NULL OR name = '') THEN RETURN name; END IF;
    firstchar := substr(name, 1, 1);
    IF (firstchar = '"') THEN
      len := length(name);
      IF (len > 1 AND substr(name, len, 1) = '"') THEN
        IF (len > ORA_MAX_NAME_LEN+3) THEN --input name length>max quoted id+1
          len := ORA_MAX_NAME_LEN+1; -- truncate name length to max id length+1
        ELSE
          len := len-2;
        END IF;
        RETURN substr(name, 2, len);  -- return name without quotes
      END IF;
    END IF;
    RETURN upper(name);
  END normalname;

end;
/

