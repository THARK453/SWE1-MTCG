create view CDB_SCHEDULER_JOB_DESTS
            (OWNER, JOB_NAME, JOB_SUBNAME, CREDENTIAL_OWNER, CREDENTIAL_NAME, DESTINATION_OWNER, DESTINATION,
             JOB_DEST_ID, ENABLED, REFS_ENABLED, STATE, NEXT_START_DATE, RUN_COUNT, RETRY_COUNT, FAILURE_COUNT,
             LAST_START_DATE, LAST_END_DATE, CON_ID)
as
SELECT k."OWNER",k."JOB_NAME",k."JOB_SUBNAME",k."CREDENTIAL_OWNER",k."CREDENTIAL_NAME",k."DESTINATION_OWNER",k."DESTINATION",k."JOB_DEST_ID",k."ENABLED",k."REFS_ENABLED",k."STATE",k."NEXT_START_DATE",k."RUN_COUNT",k."RETRY_COUNT",k."FAILURE_COUNT",k."LAST_START_DATE",k."LAST_END_DATE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SCHEDULER_JOB_DESTS") k
/

comment on table CDB_SCHEDULER_JOB_DESTS is 'State of all jobs at each of their destinations in all containers'
/

comment on column CDB_SCHEDULER_JOB_DESTS.OWNER is 'Owner of the scheduler job'
/

comment on column CDB_SCHEDULER_JOB_DESTS.JOB_NAME is 'Name of scheduler job'
/

comment on column CDB_SCHEDULER_JOB_DESTS.JOB_SUBNAME is 'Subname of scheduler job'
/

comment on column CDB_SCHEDULER_JOB_DESTS.CREDENTIAL_OWNER is 'Owner of credential used for remote destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.CREDENTIAL_NAME is 'Name of credential used for remote destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.DESTINATION_OWNER is 'Owner of destination object that points to destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.DESTINATION is 'Name of destination object or name of destination itself'
/

comment on column CDB_SCHEDULER_JOB_DESTS.JOB_DEST_ID is 'Numerical ID assigned to job at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.ENABLED is 'Is this job enabled at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.STATE is 'State of this job at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.NEXT_START_DATE is 'Next start time of this job at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.RUN_COUNT is 'Number of times this job has run at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.RETRY_COUNT is 'Number of times this job has been retried at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.FAILURE_COUNT is 'Number of times this job has failed at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.LAST_START_DATE is 'Last time this job started at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.LAST_END_DATE is 'Last time this job ended at this destination'
/

comment on column CDB_SCHEDULER_JOB_DESTS.CON_ID is 'container id'
/

