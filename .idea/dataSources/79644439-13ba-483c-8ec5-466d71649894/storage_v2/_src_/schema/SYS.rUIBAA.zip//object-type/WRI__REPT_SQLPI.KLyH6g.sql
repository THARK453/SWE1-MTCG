create TYPE wri$_rept_sqlpi AUTHID CURRENT_USER UNDER wri$_rept_abstract_t
(
  overriding member function get_report(report_reference IN VARCHAR2)
    return xmltype,
  overriding member function custom_format(report_name IN VARCHAR2,
                                           format_name IN VARCHAR2,
                                           report      IN XMLTYPE)
    return clob
)
/

