create view CDB_APPLICATION_ROLES (ROLE, SCHEMA, PACKAGE, CON_ID) as
SELECT k."ROLE",k."SCHEMA",k."PACKAGE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_APPLICATION_ROLES") k
/

comment on table CDB_APPLICATION_ROLES is ' in all containers'
/

comment on column CDB_APPLICATION_ROLES.ROLE is 'Name of Application Role'
/

comment on column CDB_APPLICATION_ROLES.SCHEMA is 'Schema name of authorizing package'
/

comment on column CDB_APPLICATION_ROLES.PACKAGE is 'Name of authorizing package'
/

comment on column CDB_APPLICATION_ROLES.CON_ID is 'container id'
/

