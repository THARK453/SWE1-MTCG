create view USER_CUBE_HIERARCHIES
            (DIMENSION_NAME, HIERARCHY_NAME, HIERARCHY_ID, HIERARCHY_TYPE, DESCRIPTION, IS_RAGGED, IS_SKIP_LEVEL,
             REFRESH_MVIEW_NAME, CUSTOM_ORDER)
as
SELECT
   o.name DIMENSION_NAME,
   h.hierarchy_name HIERARCHY_NAME,
   h.hierarchy_id HIERARCHY_ID,
   DECODE(h.hierarchy_type, 1, 'LEVEL', 2, 'VALUE') HIERARCHY_TYPE,
   d.description_value DESCRIPTION,
   (case
     when io.option_num_value is null then 0
     else io.option_num_value
    end) IS_RAGGED,
   (case
     when io2.option_num_value is null then 0
     else io2.option_num_value
    end) IS_SKIP_LEVEL,
   io3.option_value REFRESH_MVIEW_NAME,
   syn.syntax_clob CUSTOM_ORDER
FROM
  olap_hierarchies$ h,
  obj$ o,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
        n.parameter = 'NLS_LANGUAGE'
        and d.description_type = 'Description'
        and d.owning_object_type = 13 --HIERARCHY
        and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d,
  olap_impl_options$ io,
  olap_impl_options$ io2,
  olap_impl_options$ io3,
  olap_syntax$ syn
WHERE
  h.dim_obj#=o.obj# AND o.owner#=USERENV('SCHEMAID')
  AND d.owning_object_id(+)=h.hierarchy_id
  AND io.object_type(+) = 13 -- HIERARCHY
  AND io.owning_objectid(+) = h.hierarchy_id
  AND io.option_type(+) = 6 -- IS_RAGGED
  AND io2.object_type(+) = 13 -- HIERARCHY
  AND io2.owning_objectid(+) = h.hierarchy_id
  AND io2.option_type(+) = 1 -- IS_SKIP_LEVEL
  AND io3.object_type(+) = 13 -- HIERARCHY
  AND io3.owning_objectid(+) = h.hierarchy_id
  AND io3.option_type(+) = 30 -- refresh MV name
  AND syn.owner_id(+) = h.hierarchy_id
  AND syn.owner_type(+) = 13
  AND syn.ref_role(+) = 23 -- CustomOrder
/

comment on table USER_CUBE_HIERARCHIES is 'OLAP Hierarchies owned by the user in the database'
/

comment on column USER_CUBE_HIERARCHIES.DIMENSION_NAME is 'Name of owning dimension of the OLAP Hierarchy'
/

comment on column USER_CUBE_HIERARCHIES.HIERARCHY_NAME is 'Name of the OLAP Hierarchy'
/

comment on column USER_CUBE_HIERARCHIES.HIERARCHY_ID is 'Dictionary Id of the OLAP Hierarchy'
/

comment on column USER_CUBE_HIERARCHIES.HIERARCHY_TYPE is 'Type of the OLAP Hierarchy'
/

comment on column USER_CUBE_HIERARCHIES.DESCRIPTION is 'Long Description of the OLAP Hierarchy'
/

comment on column USER_CUBE_HIERARCHIES.IS_RAGGED is 'Indication of whether the OLAP Hierarchy is Ragged'
/

comment on column USER_CUBE_HIERARCHIES.IS_SKIP_LEVEL is 'Indication of whether the OLAP Hierarchy is SkipLevel'
/

comment on column USER_CUBE_HIERARCHIES.REFRESH_MVIEW_NAME is 'Name of the refresh materialized view for the OLAP Hierarchy'
/

comment on column USER_CUBE_HIERARCHIES.CUSTOM_ORDER is 'Custom Order of the OLAP Hierarchy'
/

