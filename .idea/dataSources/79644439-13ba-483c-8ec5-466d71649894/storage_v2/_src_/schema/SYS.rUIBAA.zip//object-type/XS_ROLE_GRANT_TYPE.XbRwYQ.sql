create TYPE XS$ROLE_GRANT_TYPE FORCE AS OBJECT (

-- Member Variables
-- Constants defined in other packages cannot be recognized in a type.
-- e.g.  XS_ADMIN_UTIL.XSNAME_MAXLEN
-- name   VARCHAR2(XS_ADMIN_UTIL.XSNAME_MAXLEN),
  name          VARCHAR2(130),
-- Start date of the effective date
  start_date    TIMESTAMP WITH TIME ZONE,
-- End date of the effective date
  end_date      TIMESTAMP WITH TIME ZONE,

  CONSTRUCTOR FUNCTION XS$ROLE_GRANT_TYPE (
    name       IN VARCHAR2,
    start_date IN TIMESTAMP WITH TIME ZONE:= NULL,
    end_date   IN TIMESTAMP WITH TIME ZONE:= NULL)
  RETURN SELF AS RESULT,

-- Return the name of the role
  MEMBER FUNCTION get_role_name RETURN VARCHAR2,

-- Set the start date
  MEMBER PROCEDURE set_start_date(start_date IN TIMESTAMP WITH TIME ZONE),

-- Return the start date
  MEMBER FUNCTION get_start_date RETURN TIMESTAMP WITH TIME ZONE,

-- Set the end date
  MEMBER PROCEDURE set_end_date(end_date IN TIMESTAMP WITH TIME ZONE),

-- Return the end date
  MEMBER FUNCTION get_end_date RETURN TIMESTAMP WITH TIME ZONE
);
/

