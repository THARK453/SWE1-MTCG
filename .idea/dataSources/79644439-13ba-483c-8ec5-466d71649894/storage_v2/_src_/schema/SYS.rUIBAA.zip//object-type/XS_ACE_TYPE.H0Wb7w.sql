create TYPE XS$ACE_TYPE FORCE AS OBJECT (

-- Member Variables
  privilege_list      XS$NAME_LIST,
  is_grant_ace        NUMBER,
  is_invert_principal NUMBER,
  principal_name      VARCHAR2(130),
  principal_type      NUMBER,
  start_date          TIMESTAMP WITH TIME ZONE,
  end_date            TIMESTAMP WITH TIME ZONE,

  CONSTRUCTOR FUNCTION XS$ACE_TYPE (
    privilege_list   IN XS$NAME_LIST,
    granted          IN BOOLEAN := TRUE,
    inverted         IN BOOLEAN := FALSE,
    principal_name   IN VARCHAR2,
    principal_type   IN PLS_INTEGER := 1,
    start_date       IN TIMESTAMP WITH TIME ZONE := NULL,
    end_date         IN TIMESTAMP WITH TIME ZONE := NULL)
  RETURN SELF AS RESULT,

-- Set the privileges
  MEMBER PROCEDURE set_privileges(privilege_list IN XS$NAME_LIST),

-- Return the privileges
  MEMBER FUNCTION get_privileges RETURN XS$NAME_LIST,

-- Grant or deny
  MEMBER PROCEDURE set_grant(granted IN BOOLEAN),

-- Return true if it is granted.
  MEMBER FUNCTION is_granted RETURN BOOLEAN,

-- Invert or not
  MEMBER PROCEDURE set_inverted_principal(inverted IN BOOLEAN),

-- Return true if the principal is inverted.
  MEMBER FUNCTION is_inverted_principal RETURN BOOLEAN,

-- Set the principal
  MEMBER PROCEDURE set_principal(principal_name IN VARCHAR2),

-- Return the principal
  MEMBER FUNCTION get_principal RETURN VARCHAR2,

-- Set the principal format
  MEMBER PROCEDURE set_principal_type (principal_type IN PLS_INTEGER),

-- Return the principal format
  MEMBER FUNCTION get_principal_type RETURN PLS_INTEGER,

-- Set the start date
  MEMBER PROCEDURE set_start_date(start_date IN TIMESTAMP WITH TIME ZONE),

-- Return the start date
  MEMBER FUNCTION get_start_date RETURN TIMESTAMP WITH TIME ZONE,

-- Set the end date
  MEMBER PROCEDURE set_end_date(end_date IN TIMESTAMP WITH TIME ZONE),

-- Return the end date
  MEMBER FUNCTION get_end_date RETURN TIMESTAMP WITH TIME ZONE

);
/

