create type XMLTypeExtra                                        as object
(
  namespaces  XMLTypePI,
  extraData   XMLTypePI
);
/

