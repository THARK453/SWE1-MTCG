create view DBA_ERROR_TRANSLATIONS
            (OWNER, PROFILE_NAME, ERROR_CODE, TRANSLATED_CODE, TRANSLATED_SQLSTATE, ENABLED, REGISTRATION_TIME,
             COMMENTS) as
select u.name, o.name, s.errcode#, s.txlcode#, s.txlsqlstate,
       decode(bitand(s.flags, 1), 1, 'TRUE', 0, 'FALSE'), s.rtime, s.comment$
  from sys.sqltxl_err$ s, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u
 where s.obj# = o.obj# and
       o.owner# = u.user#
/

comment on table DBA_ERROR_TRANSLATIONS is 'Describes all error translations in the database'
/

comment on column DBA_ERROR_TRANSLATIONS.OWNER is 'Owner of the SQL translation profile'
/

comment on column DBA_ERROR_TRANSLATIONS.PROFILE_NAME is 'Name of the SQL translation profile'
/

comment on column DBA_ERROR_TRANSLATIONS.ERROR_CODE is 'The error code'
/

comment on column DBA_ERROR_TRANSLATIONS.TRANSLATED_CODE is 'The translated error code'
/

comment on column DBA_ERROR_TRANSLATIONS.TRANSLATED_SQLSTATE is 'The translated SQLSTATE'
/

comment on column DBA_ERROR_TRANSLATIONS.ENABLED is 'Is the translation enabled?'
/

comment on column DBA_ERROR_TRANSLATIONS.REGISTRATION_TIME is 'Time the translation was registered'
/

comment on column DBA_ERROR_TRANSLATIONS.COMMENTS is 'Comment on the translation'
/

