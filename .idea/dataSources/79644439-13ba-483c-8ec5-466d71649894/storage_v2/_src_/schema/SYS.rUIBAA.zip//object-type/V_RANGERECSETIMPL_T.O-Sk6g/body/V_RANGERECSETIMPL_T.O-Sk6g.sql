create type body v_RangeRecSetImpl_t is

  static function ODCITableStart(sctx   IN OUT v_RangeRecSetImpl_t,
                                 opCode IN varchar2)
    return number is
  begin
    -- instantiate the object and initialise curval.
    sctx:=v_RangeRecSetImpl_t(0, 0, opCode);
    return SYS.ODCIConst.Success;
  end ODCITableStart;

  member function ODCITableFetch(self   IN OUT v_RangeRecSetImpl_t,
                                 nrows  IN     number,
                                 objSet OUT    v_RangeRecSet_t)
    return number is

    n                number := 0;
    i                number;
    indx             number := 0;
    dbcount          number;
    ret              boolean;
    restoreRangeTab  sys.dbms_rcvman.restoreRangeTab_t;

    CURSOR getAllDb_c IS SELECT  dbid FROM v$database;
    dbDetail getAllDb_c%rowtype;

  begin
    open getAllDb_c;
    objSet := v_RangeRecSet_t();

    select count(*) into dbcount from v$database;

    while n < dbcount and self.done = 0 loop
      n := n + 1;

      sys.dbms_rcvman.resetAll;
      sys.dbms_rcvman.resetDeviceType;
      sys.dbms_rcvman.setAllIncarnations(TRUE);

      if (opCode = 'V$ANY') then
        sys.dbms_rcvman.setDeviceTypeAny;
      elsif (opCode = 'V$DISK') then
        sys.dbms_rcvman.setDeviceType('DISK');
      elsif (opCode = 'V$SBT') then
        sys.dbms_rcvman.setDeviceType('SBT_TAPE');
      end if;

      fetch getAllDb_c into dbDetail;
      sys.dbms_rcvman.setdatabase(NULL, NULL, NULL, dbDetail.dbid);

      ret := sys.dbms_rcvman.getRestoreRangeSet(restoreRangeTab,
                                                opCode,
                                                dbDetail.dbid);
      i := to_number(null);
      LOOP
        IF (i is null) THEN
           i := restoreRangeTab.first;
        ELSE
           i := restoreRangeTab.next(i);
        END IF;
        EXIT WHEN i IS NULL;

        if (restoreRangeTab(i).isValidRange = TRUE) then
          objSet.extend;
          indx := indx + 1;
          objSet(indx) := v_RangeRec_t(
                                    to_number(null),
                                    to_date(null),
                                    to_date(null),
                                    to_number(null),
                                    to_number(null),
                                    to_number(null),
                                    to_number(null),
                                    to_date(null),
                                    to_date(null),
                                    to_number(null));
          if (ret = TRUE) then
            objSet(indx).db_id            := dbDetail.dbid;
            objSet(indx).low_time         := restoreRangeTab(i).lowTime;
            objSet(indx).high_time        := restoreRangeTab(i).highTime;
            objSet(indx).low_change#      := restoreRangeTab(i).lowScn;
            objSet(indx).high_change#     := restoreRangeTab(i).highScn;
            objSet(indx).low_resetlogs_change# := restoreRangeTab(i).lowRlgScn;
            objSet(indx).high_resetlogs_change# :=
                                                restoreRangeTab(i).highRlgScn;
            objSet(indx).low_resetlogs_time  := restoreRangeTab(i).lowRlgTime;
            objSet(indx).high_resetlogs_time := restoreRangeTab(i).highRlgTime;
            objSet(indx).con_id              := restoreRangeTab(i).con_id;
          end if;
        end if;
      END LOOP;
      self.curval := self.curval + 1;
      if (self.curval = dbcount) then
        self.done := 1;
        close getAllDb_c;
      end if;
    end loop;

    return SYS.ODCIConst.Success;
  end ODCITableFetch;

  member function ODCITableClose(self IN v_RangeRecSetImpl_t)
    return number is
  begin
    return SYS.ODCIConst.Success;
  end ODCITableClose;
end;
/

