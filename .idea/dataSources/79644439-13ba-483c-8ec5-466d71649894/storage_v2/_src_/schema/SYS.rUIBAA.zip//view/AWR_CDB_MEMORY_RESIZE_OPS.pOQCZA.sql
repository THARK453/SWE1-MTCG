create view AWR_CDB_MEMORY_RESIZE_OPS
            (SNAP_ID, DBID, INSTANCE_NUMBER, COMPONENT, OPER_TYPE, START_TIME, END_TIME, TARGET_SIZE, OPER_MODE,
             PARAMETER, INITIAL_SIZE, FINAL_SIZE, STATUS, CON_DBID, CON_ID)
as
select mro.snap_id, mro.dbid, mro.instance_number,
       component, oper_type, start_time, end_time,
       target_size, oper_mode, parameter, initial_size,
       final_size, mro.status,
       decode(mro.con_dbid, 0, mro.dbid, mro.con_dbid),
       decode(mro.per_pdb, 0, 0,
         con_dbid_to_id(decode(mro.con_dbid, 0, mro.dbid, mro.con_dbid))) con_id
  from AWR_CDB_SNAPSHOT sn, WRH$_MEMORY_RESIZE_OPS mro
  where     sn.snap_id         = mro.snap_id
        and sn.dbid            = mro.dbid
        and sn.instance_number = mro.instance_number
/

comment on table AWR_CDB_MEMORY_RESIZE_OPS is 'Memory Resize Operations History'
/

