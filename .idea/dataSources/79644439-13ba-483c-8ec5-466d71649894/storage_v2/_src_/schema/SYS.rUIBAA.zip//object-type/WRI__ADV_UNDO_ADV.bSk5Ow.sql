create type wri$_adv_undo_adv UNDER wri$_adv_abstract_t
  (
    OVERRIDING MEMBER PROCEDURE sub_execute(task_id IN NUMBER,
                                            err_num OUT NUMBER)
  );
/

