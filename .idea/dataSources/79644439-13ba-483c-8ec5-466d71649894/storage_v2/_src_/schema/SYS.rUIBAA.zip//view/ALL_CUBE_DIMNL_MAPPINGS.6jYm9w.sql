create view ALL_CUBE_DIMNL_MAPPINGS
            (OWNER, CUBE_NAME, CUBE_MAP_NAME, MAP_NAME, MAP_ID, MAPPED_DIMENSION_NAME, MAPPED_HIERARCHY_NAME,
             MAPPED_LEVEL_NAME, MAPPED_DIMENSION_TYPE, JOIN_CONDITION, LEVEL_ID_EXPRESSION, DIMENSIONALITY_EXPRESSION)
as
SELECT
  u.name OWNER,
  o.name CUBE_NAME,
  owner_map.map_name CUBE_MAP_NAME,
  m.map_name MAP_NAME,
  m.map_id MAP_ID,
  o2.name  MAPPED_DIMENSION_NAME,
  CASE m.mapped_dim_type
  WHEN 14 -- hier_level
  THEN (SELECT h.hierarchy_name
        FROM olap_hier_levels$ hl, olap_hierarchies$ h
        WHERE m.mapped_dim_id = hl.hierarchy_level_id
              AND hl.hierarchy_id = h.hierarchy_id
        )
  WHEN 13 -- hierarchy
  THEN (SELECT h.hierarchy_name
        FROM olap_hierarchies$ h
        WHERE m.mapped_dim_id = h.hierarchy_id
       )
  ELSE null END AS MAPPED_HIERARCHY_NAME,
  CASE m.mapped_dim_type
  WHEN 12 -- dim_level
  THEN (SELECT dl.level_name
        FROM olap_dim_levels$ dl
        WHERE m.mapped_dim_id = dl.level_id
        )
  WHEN 14 -- hier_level
  THEN (SELECT dl.level_name
        FROM olap_dim_levels$ dl, olap_hier_levels$ hl, olap_hierarchies$ h
        WHERE m.mapped_dim_id = hl.hierarchy_level_id
              AND hl.hierarchy_id = h.hierarchy_id
              AND hl.dim_level_id = dl.level_id
        )
  ELSE null END AS MAPPED_LEVEL_NAME,
  decode(m.mapped_dim_type, '12', 'DIMENSION LEVEL',
                            '11', 'PRIMARY DIMENSION',
                            '14', 'HIERARCHY LEVEL',
                            '13', 'HIERARCHY') MAPPED_DIMENSION_TYPE,
  s1.syntax_clob JOIN_CONDITION,
  s2.syntax_clob LEVEL_ID_EXPRESSION,
  s3.syntax_clob DIMENSIONALITY_EXPRESSION
FROM
  olap_mappings$ m,
  olap_mappings$ owner_map,
  user$ u,
  olap_dimensionality$ diml,
  obj$ o,
  obj$ o2,
  olap_syntax$ s1,
  olap_syntax$ s2,
  olap_syntax$ s3,
 (SELECT
    obj#,
    MIN(have_dim_access) have_all_dim_access
  FROM
    (SELECT
      c.obj# obj#,
      (CASE
        WHEN
        (do.owner# in (userenv('SCHEMAID'), 1)   -- public objects
         or do.obj# in
              ( select obj#  -- directly granted privileges
                from sys.objauth$
                where grantee# in ( select kzsrorol from x$kzsro )
              )
         or   -- user has system privileges
                ora_check_SYS_privilege (do.owner#, do.type#) = 1
        )
        THEN 1
        ELSE 0
       END) have_dim_access
    FROM
      olap_cubes$ c,
      dependency$ d,
      obj$ do
    WHERE
      do.obj# = d.p_obj#
      AND do.type# = 92 -- CUBE DIMENSION
      AND c.obj# = d.d_obj#
    )
    GROUP BY obj# ) da
WHERE
  m.map_type = 23
  AND m.mapped_object_id = diml.dimensionality_id
  AND m.mapping_owner_id = owner_map.map_id
  AND diml.dimensioned_object_id = o.obj#
  AND o.obj# = da.obj#(+)
  AND o.owner# = u.user#
  AND diml.dimension_id = o2.obj#(+)
  AND m.map_id = s1.owner_id(+)
  AND m.map_type = s1.owner_type(+)
  AND s1.ref_role(+) = 7
  AND m.map_id = s2.owner_id(+)
  AND m.map_type = s2.owner_type(+)
  AND s2.ref_role(+) = 8
  AND m.map_id = s3.owner_id(+)
  AND m.map_type = s3.owner_type(+)
  AND s3.ref_role(+) = 15
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
  AND ((have_all_dim_access = 1) OR (have_all_dim_access is NULL))
/

comment on table ALL_CUBE_DIMNL_MAPPINGS is 'OLAP Cube Dimenisonality Mappings in the database that are accessible to the user'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.OWNER is 'Owner of the OLAP Cube that contains the dimensionality'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.CUBE_NAME is 'Name of the OLAP Cube that contains the dimensionality'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.CUBE_MAP_NAME is 'Name of the OLAP Cube Map that contains the dimensionality mapping'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.MAP_NAME is 'Name of the OLAP Cube Dimensionality Mapping'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.MAP_ID is 'Dictionary Id of the OLAP Cube Dimensionality Mapping'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.MAPPED_DIMENSION_NAME is 'Name of the mapped dimension of the OLAP Cube Dimensionality'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.MAPPED_HIERARCHY_NAME is 'Name of the mapped hierarchy of the OLAP Cube Dimensionality'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.MAPPED_LEVEL_NAME is 'Name of the mapped dimension level of the OLAP Cube Dimensionality'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.MAPPED_DIMENSION_TYPE is 'Text value indicating the type of the mapped dimension object'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.JOIN_CONDITION is 'Join condition of the OLAP Cube Dimensionality'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.LEVEL_ID_EXPRESSION is 'Level ID expression of the OLAP Cube Dimensionality'
/

comment on column ALL_CUBE_DIMNL_MAPPINGS.DIMENSIONALITY_EXPRESSION is 'Dimensionality expression of the OLAP Cube Dimensionality'
/

