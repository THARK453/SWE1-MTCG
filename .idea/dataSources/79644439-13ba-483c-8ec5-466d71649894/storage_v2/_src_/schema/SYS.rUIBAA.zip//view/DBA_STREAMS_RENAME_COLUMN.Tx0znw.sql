create view DBA_STREAMS_RENAME_COLUMN
            (RULE_OWNER, RULE_NAME, SCHEMA_NAME, TABLE_NAME, FROM_COLUMN_NAME, TO_COLUMN_NAME, VALUE_TYPE, PRECEDENCE,
             STEP_NUMBER) as
select rule_owner, rule_name, schema_name, table_name, from_column_name,
       to_column_name, value_type, precedence, step_number
  from DBA_STREAMS_TRANSFORMATIONS
  where declarative_type = 'RENAME COLUMN'
/

comment on table DBA_STREAMS_RENAME_COLUMN is 'Rename column transformations'
/

comment on column DBA_STREAMS_RENAME_COLUMN.RULE_OWNER is 'Owner of the rule which has an associated transformation'
/

comment on column DBA_STREAMS_RENAME_COLUMN.RULE_NAME is 'Name of the rule which has an associated transformation'
/

comment on column DBA_STREAMS_RENAME_COLUMN.SCHEMA_NAME is 'The schema of the column to be modified'
/

comment on column DBA_STREAMS_RENAME_COLUMN.TABLE_NAME is 'The table of the column to be modified'
/

comment on column DBA_STREAMS_RENAME_COLUMN.FROM_COLUMN_NAME is 'The column to rename'
/

comment on column DBA_STREAMS_RENAME_COLUMN.TO_COLUMN_NAME is 'The new column name'
/

comment on column DBA_STREAMS_RENAME_COLUMN.VALUE_TYPE is 'Whether to rename to the old column value of the lcr, the new value, or both'
/

comment on column DBA_STREAMS_RENAME_COLUMN.PRECEDENCE is 'Execution order relative to other declarative transformations on the same step_number'
/

comment on column DBA_STREAMS_RENAME_COLUMN.STEP_NUMBER is 'The order that this transformation should be executed'
/

