create view DBA_DMT_FREE_SPACE (TABLESPACE_ID, FILE_ID, BLOCK_ID, BLOCKS) as
select  ts#, file#, block#, length
from    fet$
/

comment on table DBA_DMT_FREE_SPACE is 'Free extents in all dictionary managed tablespaces'
/

comment on column DBA_DMT_FREE_SPACE.TABLESPACE_ID is 'ID of the tablespace containing the extent'
/

comment on column DBA_DMT_FREE_SPACE.FILE_ID is 'ID number of the file containing the extent'
/

comment on column DBA_DMT_FREE_SPACE.BLOCK_ID is 'Starting block number of the extent'
/

comment on column DBA_DMT_FREE_SPACE.BLOCKS is 'Size of the extent in blocks'
/

