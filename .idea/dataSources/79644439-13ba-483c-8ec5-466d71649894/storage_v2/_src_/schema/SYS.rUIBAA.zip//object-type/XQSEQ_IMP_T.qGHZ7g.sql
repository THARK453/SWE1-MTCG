create type XQSeq_Imp_t                                       
authid current_user as object
(
  key RAW(8),
  static function ODCITableStart(sctx OUT XQSeq_Imp_t,
                                 rws_ptr IN RAW,
                                 doc in XMLType)
                  return PLS_INTEGER
    is
    language C
    library XMLtype_lib
    name "XQSeqStartStub"
    with context
    parameters (
      context,
      sctx,
      sctx INDICATOR STRUCT,
      rws_ptr OCIRAW,
      doc,
      doc INDICATOR sb4,
      return INT
    ),

  member function ODCITableFetch(self IN OUT XQSeq_Imp_t, nrows IN Number,
                               xmlseq OUT XMLSequenceType) return PLS_INTEGER
    as language C
    library XMLtype_lib
    name "XQSeqFetchStub"
    with context
    parameters (
      context,
      self,
      self INDICATOR STRUCT,
      nrows,
      xmlseq OCIColl,
      xmlseq INDICATOR sb2,
      xmlseq DURATION OCIDuration,
      return INT
    ),

  member function ODCITableClose(self IN XQSeq_Imp_t) return PLS_INTEGER
    as language C
    library XMLtype_lib
    name "XQSeqCloseStub"
    with context
    parameters (
      context,
      self,
      self INDICATOR STRUCT,
      return INT
    )
);
/

