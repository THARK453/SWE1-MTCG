create view V_$DNFS_FILES (FILENAME, FILESIZE, PNUM, SVR_ID, CON_ID) as
select "FILENAME","FILESIZE","PNUM","SVR_ID","CON_ID" from v$dnfs_files
/

