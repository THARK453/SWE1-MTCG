create view AWR_PDB_MVPARAMETER
            (SNAP_ID, DBID, INSTANCE_NUMBER, PARAMETER_HASH, PARAMETER_NAME, ORDINAL, VALUE, ISDEFAULT, ISMODIFIED,
             CON_DBID, CON_ID)
as
select mp.snap_id, mp.dbid, mp.instance_number,
       mp.parameter_hash, pn.parameter_name,
       mp.ordinal,
       case when SYS_CONTEXT('USERENV','SYSTEM_DATA_VISIBLE')='YES' or mp.per_pdb<>0 then mp.value else null end value, -- Use macro to mask sensitive column
       mp.isdefault, mp.ismodified,
       decode(mp.con_dbid, 0, mp.dbid, mp.con_dbid),
       decode(mp.per_pdb, 0, 0,
         con_dbid_to_id(decode(mp.con_dbid, 0, mp.dbid, mp.con_dbid))) con_id
from AWR_PDB_SNAPSHOT sn, WRH$_MVPARAMETER mp, WRH$_PARAMETER_NAME pn
where     mp.parameter_hash   = pn.parameter_hash
      and mp.dbid             = pn.dbid
      and mp.snap_id          = sn.snap_id
      and mp.dbid             = sn.dbid
      and mp.instance_number  = sn.instance_number
/

comment on table AWR_PDB_MVPARAMETER is 'Multi-valued Parameter Historical Statistics Information'
/

