create view CDB_SQLTUNE_BINDS (TASK_ID, OBJECT_ID, POSITION, CON_ID) as
SELECT k."TASK_ID",k."OBJECT_ID",k."POSITION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SQLTUNE_BINDS") k
/

comment on table CDB_SQLTUNE_BINDS is ' in all containers'
/

comment on column CDB_SQLTUNE_BINDS.CON_ID is 'container id'
/

