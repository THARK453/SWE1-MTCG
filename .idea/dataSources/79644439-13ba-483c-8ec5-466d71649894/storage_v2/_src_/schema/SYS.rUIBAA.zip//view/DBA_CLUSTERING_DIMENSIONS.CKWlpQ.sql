create view DBA_CLUSTERING_DIMENSIONS (OWNER, TABLE_NAME, DIMENSION_OWNER, DIMENSION_NAME) as
select u.NAME, o.NAME, u2.NAME, o2.NAME
from   USER$ u, OBJ$ o, USER$ u2, OBJ$ o2, CLSTDIMENSION$ d
where  u.USER#    = o.OWNER#
and    d.CLSTOBJ# = o.OBJ#
and    u2.USER#   = o2.OWNER#
and    d.TABOBJ#  = o2.OBJ#
and    bitand(o.FLAGS,  128) = 0
and    bitand(o2.FLAGS, 128) = 0
/

comment on table DBA_CLUSTERING_DIMENSIONS is 'All dimension details about clustering tables in the database'
/

comment on column DBA_CLUSTERING_DIMENSIONS.OWNER is 'Owner of the clustering table'
/

comment on column DBA_CLUSTERING_DIMENSIONS.TABLE_NAME is 'Name of the clustering table'
/

comment on column DBA_CLUSTERING_DIMENSIONS.DIMENSION_OWNER is 'Owner of the dimension table'
/

comment on column DBA_CLUSTERING_DIMENSIONS.DIMENSION_NAME is 'Name of the dimension table'
/

