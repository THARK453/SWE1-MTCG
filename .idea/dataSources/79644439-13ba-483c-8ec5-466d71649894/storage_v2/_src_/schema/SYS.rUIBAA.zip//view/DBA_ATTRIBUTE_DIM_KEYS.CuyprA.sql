create view DBA_ATTRIBUTE_DIM_KEYS
            (OWNER, DIMENSION_NAME, LEVEL_NAME, IS_ALTERNATE, ATTRIBUTE_NAME, ATTR_ORDER_NUM, KEY_ORDER_NUM,
             ORIGIN_CON_ID) as
select OWNER, DIMENSION_NAME, LEVEL_NAME, IS_ALTERNATE, ATTRIBUTE_NAME,
    ATTR_ORDER_NUM, KEY_ORDER_NUM, ORIGIN_CON_ID
from INT$DBA_ATTR_DIM_KEYS
/

comment on column DBA_ATTRIBUTE_DIM_KEYS.OWNER is 'Owner of attribute dimension'
/

comment on column DBA_ATTRIBUTE_DIM_KEYS.DIMENSION_NAME is 'Name of the owning attribute dimension'
/

comment on column DBA_ATTRIBUTE_DIM_KEYS.LEVEL_NAME is 'Level name of the key, NULL if PARENT CHILD dimension'
/

comment on column DBA_ATTRIBUTE_DIM_KEYS.IS_ALTERNATE is 'Indication of whether or not the dimension key is an alternate key'
/

comment on column DBA_ATTRIBUTE_DIM_KEYS.ATTRIBUTE_NAME is 'Name of the key attribute'
/

comment on column DBA_ATTRIBUTE_DIM_KEYS.ATTR_ORDER_NUM is 'Order of the attribute in the list of attributes comprising the key'
/

comment on column DBA_ATTRIBUTE_DIM_KEYS.KEY_ORDER_NUM is 'Order of the key in the list of keys (if alternate keys specified)'
/

comment on column DBA_ATTRIBUTE_DIM_KEYS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

