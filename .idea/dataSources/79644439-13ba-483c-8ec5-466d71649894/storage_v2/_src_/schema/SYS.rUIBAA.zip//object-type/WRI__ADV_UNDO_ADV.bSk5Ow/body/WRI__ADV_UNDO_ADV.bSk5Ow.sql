create TYPE BODY     wri$_adv_undo_adv wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
13a f7
fxSwEm2xoV1FLpVTxa4/uTClEQwwg/Dc7Z4VfC+f/15oj3A12zEGUCGAvSUUccCV3GtQlek1
aQ+aoN9tXiA6uUq7ltLLNaM9asFCBdQ4z8axEM9ZbVCHZ6sFqPcrgyFQ4NX33fc7zH+oMKfz
ZFTHZ7QClw9RKw6yBEHj+JOdIwlZWeZLdm/W4N9UI1p+oPpK9rPMH2bq5dpWKsfZUY61aG6q
e2otR64V3ZE/SatEod9qi5lbWzVf
/

