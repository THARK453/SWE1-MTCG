create type wri$_adv_stats under wri$_adv_abstract_t
(
  OVERRIDING MEMBER PROCEDURE sub_execute(task_id IN NUMBER,
                                          err_num OUT NUMBER),
  OVERRIDING MEMBER PROCEDURE sub_reset(task_id IN NUMBER),
  OVERRIDING MEMBER PROCEDURE sub_resume(task_id IN NUMBER,
                                         err_num OUT NUMBER)
) NOT FINAL
/

