create view DBA_PDB_HISTORY
            (PDB_NAME, PDB_ID, PDB_DBID, PDB_GUID, OP_SCNBAS, OP_SCNWRP, OP_TIMESTAMP, OPERATION, DB_VERSION,
             CLONED_FROM_PDB_NAME, CLONED_FROM_PDB_DBID, CLONED_FROM_PDB_GUID, DB_NAME, DB_UNIQUE_NAME, DB_DBID,
             CLONETAG, DB_VERSION_STRING)
as
select p.name, p.con_id#, p.dbid, p.guid, p.scnbas, p.scnwrp, p.time,
       p.operation, p.db_version, p.c_pdb_name, p.c_pdb_dbid, p.c_pdb_guid,
       p.c_db_name, p.c_db_uname, p.c_db_dbid, p.clonetag,
       bitand(p.db_version / power(2,24), 255)||'.'||
       bitand(p.db_version / power(2,20),  15)||'.'||
       bitand(p.db_version / power(2,12), 255)||'.'||
       bitand(p.db_version / power(2, 8),  15)||'.'||
       bitand(p.db_version / power(2, 0), 255) db_version_string
  from sys.pdb_history$ p
/

comment on table DBA_PDB_HISTORY is 'Describes lineage of the pluggable database to which it belongs'
/

comment on column DBA_PDB_HISTORY.PDB_NAME is 'Name of this pluggable database in one of its incarnations'
/

comment on column DBA_PDB_HISTORY.PDB_ID is 'Id of this pluggable database in one of its incarnations'
/

comment on column DBA_PDB_HISTORY.PDB_DBID is 'Database id of this pluggable database in one of its incarnations'
/

comment on column DBA_PDB_HISTORY.PDB_GUID is 'Globally unique id of this pluggable database in one of its incarnations'
/

comment on column DBA_PDB_HISTORY.OP_SCNBAS is 'SCN base when an operation was performed on one of incarnations of this pluggable database'
/

comment on column DBA_PDB_HISTORY.OP_SCNWRP is 'SCN wrap when an operation was performed on one of incarnations of this pluggable database'
/

comment on column DBA_PDB_HISTORY.OP_TIMESTAMP is 'Timestamp of an operation performed on one of incarnations of this pluggable database'
/

comment on column DBA_PDB_HISTORY.OPERATION is 'Operation that was performed on one of incarnations of this pluggable database'
/

comment on column DBA_PDB_HISTORY.DB_VERSION is 'Database version'
/

comment on column DBA_PDB_HISTORY.CLONED_FROM_PDB_NAME is 'Name of a pluggable database from which one of incarnations of this pluggable database was cloned'
/

comment on column DBA_PDB_HISTORY.CLONED_FROM_PDB_DBID is 'Database id of a pluggable database from which one of incarnations of this pluggable database was cloned'
/

comment on column DBA_PDB_HISTORY.CLONED_FROM_PDB_GUID is 'Globally unique id of a pluggable database from which one of incarnations of this pluggable database was cloned'
/

comment on column DBA_PDB_HISTORY.DB_NAME is 'Name of a consolidation database in which one of incarnations of this pluggable database was created'
/

comment on column DBA_PDB_HISTORY.DB_UNIQUE_NAME is 'Unique name of a consolidation database in which one of incarnations of this pluggable database was created'
/

comment on column DBA_PDB_HISTORY.DB_DBID is 'Database id of a consolidation database in which one of incarnations of this pluggable database was created'
/

comment on column DBA_PDB_HISTORY.CLONETAG is 'clone tag name for the pdb if the pdb was cloned using snapshot copy mechanism'
/

comment on column DBA_PDB_HISTORY.DB_VERSION_STRING is 'Database version string'
/

