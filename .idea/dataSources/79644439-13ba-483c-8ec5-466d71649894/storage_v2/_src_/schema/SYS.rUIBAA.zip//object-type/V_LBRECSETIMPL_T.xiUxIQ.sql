create type v_lbRecSetImpl_t as object
(
   curval                number,  -- current rownum
   done                  number,  -- done with the query
   needobsolete          number,  -- user requested obsolete column

   static function ODCITablePrepare(sctx OUT    v_lbRecSetImpl_t,
                                   ti    IN     SYS.ODCITabFuncInfo)
      return number,

   static function ODCITableStart(sctx   IN OUT v_lbRecSetImpl_t)
      return number,

   member function ODCITableFetch(self   IN OUT v_lbRecSetImpl_t,
                                  nrows  IN     number,
                                  objSet OUT    v_lbRecSet_t)
      return number,

   member function ODCITableClose(self   IN     v_lbRecSetImpl_t)
      return number
);
/

