create TYPE wri$_rept_abstract_t
AUTHID CURRENT_USER
AS OBJECT
(
  dummy_param number,

  ----------------------------------- get_report ------------------------------
  -- NAME:
  --     get_report
  --
  -- DESCRIPTION:
  --     All components should implement the get_report method to allow the
  --     framework to fetch their reports.  It should accept the report
  --     reference specifying the report they need to build,
  --     and return the report in XML.
  --
  -- PARAMETERS:
  --     report_reference (IN) - the string identifying the report to be built.
  --                             Can be parsed by a call to
  --                             parse_report_reference.
  --
  -- RETURN:
  --     Report built, in XML
  -----------------------------------------------------------------------------
  member function get_report(report_reference IN VARCHAR2) return xmltype,

  ------------------------------- get_report_with_summary ---------------------
  -- NAME:
  --     get_report_with_summary
  --
  -- DESCRIPTION:
  --     Currently the wri$_rept_sqlmonitor component implements the
  --     get_report_with_summary method to allow the framework to fetch a
  --     report along with its summary, from the repository.  It should accept
  --     the report reference specifying the report they need to build,
  --     and return the report in XML.
  --     The summary is embedded as an xml element with the name
  --     "report_repository_summary". This tag can have xmlattributes and
  --     embedded xml elements as per the requirement of the client implementing
  --     this procedure. The report_repository_summary tag should be the
  --     first-level child of the top-level report tag in the xml returned by
  --     this procedure.
  --
  -- PARAMETERS:
  --     report_reference (IN) - the string identifying the report to be built.
  --                             Can be parsed by a call to
  --                             parse_report_reference.
  --
  -- RETURN:
  --     Report built, in XML
  -----------------------------------------------------------------------------
  member function get_report_with_summary(
    report_reference IN VARCHAR2)
  return xmltype,

  ------------------------------- custom_format -------------------------------
  -- NAME:
  --     custom_format
  --
  -- DESCRIPTION:
  --     In addition to the formatting reports via XSLT or HTML-to-Text,
  --     components can have their own custom formats.  They just need to
  --     override this function.  One component can have any number of custom
  --     formats by implementing logic around the 'format_name' argument here.
  --
  -- PARAMETERS:
  --     report_name (IN) - report name corresponding to report
  --     format_name (IN) - format name to generate
  --     report      (IN) - report to transform
  --
  -- RETURN:
  --     Transformed report, as CLOB
  -----------------------------------------------------------------------------
  member function custom_format(report_name IN VARCHAR2,
                                format_name IN VARCHAR2,
                                report      IN XMLTYPE) return clob
)
not final
not instantiable
/

