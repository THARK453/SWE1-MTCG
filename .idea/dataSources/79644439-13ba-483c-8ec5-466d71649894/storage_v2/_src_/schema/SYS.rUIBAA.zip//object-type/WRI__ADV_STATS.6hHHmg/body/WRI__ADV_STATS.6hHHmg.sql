create TYPE BODY     wri$_adv_stats wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
258 144
cklTL+YgJStVDPe2PGoAj9/3i+IwgzvILUhqfHSi2h7VV/URqWYsaYzWAfM5zLplWvpNSWZn
p9gNs/k/AcRIdBrWBxEaMDS/HwfLrzl43bHGQ8yuwa6ksOsh4fT75wBlt+8PhG076UBKhALR
f6wUCs5KXBjOjgxCXsBnHM/s/kEDMLvZb+xcLwnkXCzCIwhbEcPgiLepbA+bDl3vPIXp+aBU
t3gFmZZkytZ2kHkB9/Sn4km9zxqUXBd3jf58TzW7YZOeA+94jHA0LnPGEOlOJt5h0W3AZIAn
tQpvRwDl7ccSJKBO213MCKWyvUvxxQ==
/

