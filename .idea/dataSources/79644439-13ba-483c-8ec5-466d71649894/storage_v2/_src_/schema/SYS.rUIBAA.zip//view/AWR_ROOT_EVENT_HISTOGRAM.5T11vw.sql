create view AWR_ROOT_EVENT_HISTOGRAM
            (SNAP_ID, DBID, INSTANCE_NUMBER, EVENT_ID, EVENT_NAME, WAIT_CLASS_ID, WAIT_CLASS, WAIT_TIME_MILLI,
             WAIT_COUNT, CON_DBID, CON_ID)
as
select e.snap_id, e.dbid, e.instance_number,
       e.event_id, en.event_name, en.wait_class_id, en.wait_class,
       e.wait_time_milli, e.wait_count,
       decode(e.con_dbid, 0, e.dbid, e.con_dbid),
       decode(e.per_pdb, 0, 0,
         con_dbid_to_id(decode(e.con_dbid, 0, e.dbid, e.con_dbid))) con_id
from AWR_ROOT_SNAPSHOT sn, WRH$_EVENT_HISTOGRAM e, WRH$_EVENT_NAME en
where     e.event_id         = en.event_id
      and e.dbid             = en.dbid
      and e.snap_id          = sn.snap_id
      and e.dbid             = sn.dbid
      and e.instance_number  = sn.instance_number
/

comment on table AWR_ROOT_EVENT_HISTOGRAM is 'Event Histogram Historical Statistics Information'
/

