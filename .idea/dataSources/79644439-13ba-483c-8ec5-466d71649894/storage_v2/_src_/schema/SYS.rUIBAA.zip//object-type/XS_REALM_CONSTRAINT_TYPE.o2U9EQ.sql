create TYPE XS$REALM_CONSTRAINT_TYPE FORCE AS OBJECT (
-- Member variables
realm_type    NUMBER,

-- Member evaluation rule
realm              VARCHAR2(4000),
-- acl list of instance set
acl_list              XS$NAME_LIST,
-- isStatic variable for instance set. Stored as INTEGER. No boolean datatype
-- for objects. False is stored as 0 and TRUE is stored as 1
is_static          INTEGER,

--description
description        VARCHAR2(4000),
-- Indicate if the realm is parameterized.
parameterized      INTEGER,

-- parent schema name for inherited from
parent_schema      VARCHAR2(130),
-- parent object name for inherited from
parent_object      VARCHAR2(130),
-- keys for inherited from
key_list           XS$KEY_LIST,
-- when condition for inherited from
when_condition     VARCHAR2(4000),


-- Constructor function - row_level realm
CONSTRUCTOR FUNCTION XS$REALM_CONSTRAINT_TYPE
                     (realm                  IN VARCHAR2,
                      acl_list               IN XS$NAME_LIST,
                      is_static              IN BOOLEAN := FALSE,
                      description            IN VARCHAR2 :=NULL)
                      RETURN SELF AS RESULT,

-- Constructor function - parameterized row_level realm
CONSTRUCTOR FUNCTION XS$REALM_CONSTRAINT_TYPE
                     (realm                  IN VARCHAR2,
                      is_static              IN BOOLEAN := FALSE)
                      RETURN SELF AS RESULT,

-- Constructor function - master realm
CONSTRUCTOR FUNCTION XS$REALM_CONSTRAINT_TYPE
                     (parent_schema  IN VARCHAR2,
                      parent_object  IN VARCHAR2,
                      key_list       IN XS$KEY_LIST,
                      when_condition IN VARCHAR2:= NULL)
                      RETURN SELF AS RESULT,

-- Accessor functions
-- Get the type
MEMBER FUNCTION GET_TYPE RETURN NUMBER,

-- Get the realm
MEMBER FUNCTION GET_REALM RETURN VARCHAR2,
-- Get the acls
MEMBER FUNCTION GET_ACLS RETURN XS$NAME_LIST,
-- Is static or dynamic ?
MEMBER FUNCTION IS_DYNAMIC_REALM RETURN BOOLEAN,

MEMBER FUNCTION IS_STATIC_REALM RETURN BOOLEAN,

MEMBER FUNCTION GET_DESCRIPTION RETURN VARCHAR2,

-- Is parameterized ?
MEMBER FUNCTION IS_PARAMETERIZED_REALM RETURN BOOLEAN,

-- Get the keys of inherited_from
MEMBER FUNCTION GET_KEYS RETURN XS$KEY_LIST,
-- Get the parent schema name for inherited from
MEMBER FUNCTION GET_PARENT_SCHEMA RETURN VARCHAR2,
-- Get the parent object name for inherited from
MEMBER FUNCTION GET_PARENT_OBJECT RETURN VARCHAR2,
-- Get when for inherited from
MEMBER FUNCTION GET_WHEN_CONDITION RETURN VARCHAR2,

-- Set the member realm
MEMBER PROCEDURE SET_REALM(realm IN VARCHAR2),

-- Add acls to te realm
MEMBER PROCEDURE ADD_ACLS(acl      IN VARCHAR2),
MEMBER PROCEDURE ADD_ACLS(acl_list IN XS$NAME_LIST),
-- Set the acls of the realm
MEMBER PROCEDURE SET_ACLS(acl_list IN XS$NAME_LIST),
-- Set static or dynamic
MEMBER PROCEDURE SET_DYNAMIC,
MEMBER PROCEDURE SET_STATIC,
-- Set Description
MEMBER PROCEDURE SET_DESCRIPTION(description IN VARCHAR2),
-- Add keys
MEMBER PROCEDURE ADD_KEYS(key IN XS$KEY_TYPE),
MEMBER PROCEDURE ADD_KEYS(key_list IN XS$KEY_LIST),
-- Set the keys
MEMBER PROCEDURE SET_KEYS(key_list IN XS$KEY_LIST),
-- Set the parent schema of the inherited from
MEMBER PROCEDURE SET_PARENT_SCHEMA(parent_schema IN VARCHAR2),
-- Set the parent object of the inherited from
MEMBER PROCEDURE SET_PARENT_OBJECT(parent_object IN VARCHAR2),
-- Set when value of the inherited from
MEMBER PROCEDURE SET_WHEN_CONDITION(when_condition IN VARCHAR2)
);
/

