create view CDB_XML_SCHEMA_DEPENDENCY
            (SCHEMA_URL, SCHEMA_OWNER, SCHEMA_OID, DEP_SCHEMA_URL, DEP_SCHEMA_OWNER, DEP_SCHEMA_OID, CON_ID) as
SELECT k."SCHEMA_URL",k."SCHEMA_OWNER",k."SCHEMA_OID",k."DEP_SCHEMA_URL",k."DEP_SCHEMA_OWNER",k."DEP_SCHEMA_OID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XML_SCHEMA_DEPENDENCY") k
/

comment on table CDB_XML_SCHEMA_DEPENDENCY is 'Description of all XML schema first level dependencies on imported and included XML schemas in all containers'
/

comment on column CDB_XML_SCHEMA_DEPENDENCY.SCHEMA_URL is 'Schema URL of the XML Schema'
/

comment on column CDB_XML_SCHEMA_DEPENDENCY.SCHEMA_OWNER is 'Owner of the XML Schema'
/

comment on column CDB_XML_SCHEMA_DEPENDENCY.SCHEMA_OID is 'Oid of the XML Schema'
/

comment on column CDB_XML_SCHEMA_DEPENDENCY.DEP_SCHEMA_URL is 'Schema URL of the dependent (include or imported) XML Schema'
/

comment on column CDB_XML_SCHEMA_DEPENDENCY.DEP_SCHEMA_OWNER is 'Owner of the dependent (include or imported) XML Schema'
/

comment on column CDB_XML_SCHEMA_DEPENDENCY.DEP_SCHEMA_OID is 'Oid of the dependent XML Schema'
/

comment on column CDB_XML_SCHEMA_DEPENDENCY.CON_ID is 'container id'
/

