create view DBA_ERRORS_AE
            (OWNER, NAME, TYPE, SEQUENCE, LINE, POSITION, TEXT, ATTRIBUTE, MESSAGE_NUMBER, EDITION_NAME) as
select u.name, o.name,
decode(o.type#, 4, 'VIEW', 7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
               11, 'PACKAGE BODY', 12, 'TRIGGER', 13, 'TYPE', 14, 'TYPE BODY',
               22, 'LIBRARY', 28, 'JAVA SOURCE', 29, 'JAVA CLASS',
               43, 'DIMENSION', 87, 'ASSEMBLY', 150, 'HIERARCHY',
               151, 'ATTRIBUTE DIMENSION', 152, 'ANALYTIC VIEW', 'UNDEFINED'),
  e.sequence#, e.line, e.position#, e.text,
  decode(e.property, 0,'ERROR', 1, 'WARNING', 'UNDEFINED'), e.error#
  , o.defining_edition
from sys."_ACTUAL_EDITION_OBJ" o, sys.error$ e, sys.user$ u
where o.obj# = e.obj#
  and o.owner# = u.user#
  and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43, 87, 150, 151,
                  152)
/

comment on table DBA_ERRORS_AE is 'Current errors on all stored objects in the database'
/

comment on column DBA_ERRORS_AE.NAME is 'Name of the object'
/

comment on column DBA_ERRORS_AE.TYPE is 'Type of the object'
/

comment on column DBA_ERRORS_AE.SEQUENCE is 'Sequence number used for ordering purposes'
/

comment on column DBA_ERRORS_AE.LINE is 'Line number at which this error occurs'
/

comment on column DBA_ERRORS_AE.POSITION is 'Position in the line at which this error occurs'
/

comment on column DBA_ERRORS_AE.TEXT is 'Text of the error'
/

comment on column DBA_ERRORS_AE.EDITION_NAME is 'Name of the edition in which the object is actual'
/

