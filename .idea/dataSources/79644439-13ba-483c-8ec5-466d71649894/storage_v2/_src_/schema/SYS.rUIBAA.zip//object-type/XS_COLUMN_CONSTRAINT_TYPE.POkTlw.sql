create TYPE XS$COLUMN_CONSTRAINT_TYPE FORCE AS OBJECT (

-- column list
column_list        XS$LIST,
-- privilege for column security
privilege          VARCHAR2(261),

-- Constructor function
CONSTRUCTOR FUNCTION XS$COLUMN_CONSTRAINT_TYPE
                     (column_list  IN XS$LIST,
                      privilege    IN VARCHAR2)
                      return SELF AS RESULT,

-- get column list
MEMBER FUNCTION GET_COLUMNS RETURN XS$LIST,
-- Get the privilege for column security
MEMBER FUNCTION GET_PRIVILEGE RETURN VARCHAR2,

-- Add a column to column security
MEMBER PROCEDURE ADD_COLUMNS(column IN VARCHAR2),
-- Add columns to column security
MEMBER PROCEDURE ADD_COLUMNS(column_list IN XS$LIST),
-- Set the columns  of column  security
MEMBER PROCEDURE SET_COLUMNS(column_list IN XS$LIST),
-- Set the privilege of the column security
MEMBER PROCEDURE SET_PRIVILEGE(privilege IN VARCHAR2)
);
/

