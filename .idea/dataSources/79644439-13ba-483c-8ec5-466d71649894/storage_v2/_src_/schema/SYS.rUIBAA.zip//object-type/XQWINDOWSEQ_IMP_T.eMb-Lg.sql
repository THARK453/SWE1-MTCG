create type XQWindowSeq_Imp_t authid current_user as object
(
   key RAW(8),
   static function ODCITableStart(sctx OUT XQWindowSeq_Imp_t,
                                  rws_ptr IN RAW,
                                  doc in XMLType,
                                  flag in number,
                                  startExpr in varchar2,
                                  endExpr in varchar2,
                                  curItem in XMLType,
                                  prevItem in XMLType,
                                  nextItem in XMLType,
                                  position in XMLType,
                                  ecurItem in XMLType,
                                  eprevItem in XMLType,
                                  enextItem in XMLType,
                                  eposition in XMLType
                           )
                   return PLS_INTEGER
     is
     language C
     library XMLtype_lib
     name "XQWindowSeqStartStub"
     with context
     parameters (
       context,
       sctx,
       sctx INDICATOR STRUCT,
       rws_ptr OCIRAW,
       doc, -- input source XMLType(Sequence) to window function
       doc INDICATOR sb4,
       flag, -- input flags for window parameters
       flag INDICATOR sb4,
       startExpr, -- window startExpression
       startExpr INDICATOR sb4,
       endExpr, -- window endExpression
       endExpr INDICATOR sb4,
       curItem, -- window curItem
       curItem INDICATOR sb4,
       prevItem, -- window prevItem
       prevItem INDICATOR sb4,
       nextItem, -- window nextItem
       nextItem INDICATOR sb4,
       position, -- window item position
       position INDICATOR sb4,
       ecurItem, -- window curItem
       ecurItem INDICATOR sb4,
       eprevItem, -- window prevItem
       eprevItem INDICATOR sb4,
       enextItem, -- window nextItem
       enextItem INDICATOR sb4,
       eposition, -- window item position
       eposition INDICATOR sb4,
       return INT
     ),

   member function ODCITableFetch(self IN OUT XQWindowSeq_Imp_t, nrows IN Number,
                                xmlseq OUT XMLSequenceType) return PLS_INTEGER
     as language C
     library XMLtype_lib
     name "XQWindowSeqFetchStub"
     with context
     parameters (
       context,
       self,
       self INDICATOR STRUCT,
       nrows,
       xmlseq OCIColl,
       xmlseq INDICATOR sb2,
       xmlseq DURATION OCIDuration,
       return INT
     ),

   member function ODCITableClose(self IN XQWindowSeq_Imp_t) return PLS_INTEGER
     as language C
     library XMLtype_lib
     name "XQWindowSeqCloseStub"
     with context
     parameters (
       context,
       self,
       self INDICATOR STRUCT,
       return INT
     )
)
/

