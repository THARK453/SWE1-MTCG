create TYPE WLM_CAPABILITY_OBJECT FORCE as OBJECT
(
  capability   VARCHAR2(30),
  value        VARCHAR2(30)
);
/

