create view AWR_ROOT_SQL_BIND_METADATA
            (DBID, SQL_ID, NAME, POSITION, DUP_POSITION, DATATYPE, DATATYPE_STRING, CHARACTER_SID, PRECISION, SCALE,
             MAX_LENGTH, CON_DBID, CON_ID)
as
select dbid, sql_id, name, position, dup_position,
       datatype, datatype_string,
       character_sid, precision, scale, max_length,
       decode(con_dbid, 0, dbid, con_dbid),
       decode(per_pdb, 0, 0,
         con_dbid_to_id(decode(con_dbid, 0, dbid, con_dbid))) con_id
  from WRH$_SQL_BIND_METADATA
/

comment on table AWR_ROOT_SQL_BIND_METADATA is 'SQL Bind Metadata Information'
/

