create TYPE BODY wri$_rept_tcb wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
ab d6
gmGO2ovGZTvR3ugM6R0g0SCG8zcwgy7wf5kVZ47WkLvqkbhQPQ1eu9E7W82YmzRv2pSOW3g+
RLW8KDbz4ai9zz5OZ852FzSxwT+TLGR5Mbl4Gm3HqT6uwy5/oW1B7bBRiGyJiURi2VF2wqdq
sVYqw/LK8XDlKm72AKTwUVaMnuIQ6opQnoYdQXnTTprRC7FcK2kGLO3ApwpVWy1pVg0=
/

