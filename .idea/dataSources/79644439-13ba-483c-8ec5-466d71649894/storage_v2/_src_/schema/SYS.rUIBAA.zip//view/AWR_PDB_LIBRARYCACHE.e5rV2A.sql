create view AWR_PDB_LIBRARYCACHE
            (SNAP_ID, DBID, INSTANCE_NUMBER, NAMESPACE, GETS, GETHITS, PINS, PINHITS, RELOADS, INVALIDATIONS,
             DLM_LOCK_REQUESTS, DLM_PIN_REQUESTS, DLM_PIN_RELEASES, DLM_INVALIDATION_REQUESTS, DLM_INVALIDATIONS,
             CON_DBID, CON_ID)
as
select lc.snap_id, lc.dbid, lc.instance_number, namespace, gets,
       gethits, pins, pinhits, reloads, invalidations,
       dlm_lock_requests, dlm_pin_requests, dlm_pin_releases,
       dlm_invalidation_requests, dlm_invalidations,
       decode(lc.con_dbid, 0, lc.dbid, lc.con_dbid),
       decode(lc.per_pdb, 0, 0,
         con_dbid_to_id(decode(lc.con_dbid, 0, lc.dbid, lc.con_dbid))) con_id
  from AWR_PDB_SNAPSHOT sn, WRH$_LIBRARYCACHE lc
  where     sn.snap_id         = lc.snap_id
        and sn.dbid            = lc.dbid
        and sn.instance_number = lc.instance_number
/

comment on table AWR_PDB_LIBRARYCACHE is 'Library Cache Historical Statistics Information'
/

