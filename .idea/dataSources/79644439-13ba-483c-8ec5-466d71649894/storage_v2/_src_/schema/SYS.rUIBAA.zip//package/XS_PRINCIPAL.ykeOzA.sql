create PACKAGE XS_PRINCIPAL AUTHID CURRENT_USER AS

-- Public constants
-- The following constants define the user's status.
  ACTIVE          CONSTANT PLS_INTEGER := 1;
  INACTIVE        CONSTANT PLS_INTEGER := 2;
  UNLOCK          CONSTANT PLS_INTEGER := 3;
  EXPIRED         CONSTANT PLS_INTEGER := 4;
  LOCKED          CONSTANT PLS_INTEGER := 5;

-- The following constants define dynamic role scope.
  SESSION_SCOPE   CONSTANT PLS_INTEGER := 0;
  REQUEST_SCOPE   CONSTANT PLS_INTEGER := 1;

-- The following constants define the Verifier type.
  XS_SHA512       CONSTANT PLS_INTEGER := 2 ;
  XS_SALTED_SHA1  CONSTANT PLS_INTEGER := 1 ;

-- Enable log based replication for this package
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, AUTO);

-- Principal creation APIs.
  PROCEDURE create_user (
    name            IN VARCHAR2,
    schema          IN VARCHAR2    := NULL,
    status          IN PLS_INTEGER := ACTIVE,
    start_date      IN TIMESTAMP WITH TIME ZONE := NULL,
    end_date        IN TIMESTAMP WITH TIME ZONE := NULL,
    guid            IN RAW         := NULL,
    external_source IN VARCHAR2    := NULL,
    description     IN VARCHAR2    := NULL,
    acl             IN VARCHAR2    := NULL);

  PROCEDURE create_role (
    name            IN VARCHAR2,
    enabled         IN BOOLEAN  := FALSE,
    start_date      IN TIMESTAMP WITH TIME ZONE:= NULL,
    end_date        IN TIMESTAMP WITH TIME ZONE:= NULL,
    guid            IN RAW      := NULL,
    external_source IN VARCHAR2 := NULL,
    description     IN VARCHAR2 := NULL);

  PROCEDURE create_dynamic_role (
    name            IN VARCHAR2,
    duration        IN PLS_INTEGER := NULL,
    scope           IN PLS_INTEGER := SESSION_SCOPE,
    description     IN VARCHAR2    := NULL,
    acl             IN VARCHAR2    := NULL);

-- Grant a role to a principal
  PROCEDURE grant_roles (
    grantee        IN VARCHAR2,
    role           IN VARCHAR2,
    start_date     IN TIMESTAMP WITH TIME ZONE:= NULL,
    end_date       IN TIMESTAMP WITH TIME ZONE:= NULL);

-- Grant a list of roles to a principal
  PROCEDURE grant_roles (
    grantee   IN VARCHAR2,
    role_list IN XS$ROLE_GRANT_LIST);

-- Revoke all roles from a principal.
  PROCEDURE revoke_roles (
    grantee IN VARCHAR2);

-- Revoke a role from a principal
  PROCEDURE revoke_roles (
    grantee IN VARCHAR2,
    role    IN VARCHAR2);

-- Revoke a list of roles from a principal
  PROCEDURE revoke_roles (
    grantee      IN VARCHAR2,
    role_list    IN XS$NAME_LIST);

-- Add a proxy user to a lightweight user.
-- proxy_user will proxy to and act on behalf of target_user.
-- If the target_roles is null, only xspublic and xsswitch
-- default roles will be enable for proxy user.
  PROCEDURE add_proxy_user (
    target_user  IN VARCHAR2,
    proxy_user   IN VARCHAR2,
    target_roles IN XS$NAME_LIST);

-- Add proxy user to a target user with all with all default enabled
-- roles of target user.
  PROCEDURE add_proxy_user (
    target_user  IN VARCHAR2,
    proxy_user   IN VARCHAR2);

-- Add a proxy user to db user
  PROCEDURE add_proxy_to_dbuser (
     database_user IN VARCHAR2,
     proxy_user    IN VARCHAR2,
     is_external   IN BOOLEAN := FALSE);

-- Remove a proxy user from db user
  PROCEDURE remove_proxy_from_dbuser (
    database_user IN VARCHAR2,
    proxy_user    IN VARCHAR2);

-- Remove all existing proxy users from a target user.
  PROCEDURE remove_proxy_users (
    target_user IN VARCHAR2);

-- Remove a proxy user from a target user.
  PROCEDURE remove_proxy_users (
    target_user IN VARCHAR2,
    proxy_user  IN VARCHAR2);

-- Update effective date of a user/role.
  PROCEDURE set_effective_dates (
    principal  IN VARCHAR2,
    start_date IN TIMESTAMP WITH TIME ZONE:= NULL,
    end_date   IN TIMESTAMP WITH TIME ZONE:= NULL);

-- Update the duration of a dynamic role.
  PROCEDURE set_dynamic_role_duration (
    role      IN VARCHAR2,
    duration  IN PLS_INTEGER);

-- Update the scope attribute of a dynamic role
  PROCEDURE set_dynamic_role_scope (
    role  IN VARCHAR2,
    scope IN PLS_INTEGER);

-- Enables/disables the role by default. This API only works on regular roles.
  PROCEDURE enable_by_default (
    role      IN VARCHAR2,
    enabled   IN BOOLEAN := TRUE);

-- Enables/disables all directly granted roles for a user by default.
-- This API only works on users.
 PROCEDURE enable_roles_by_default (
    user      IN VARCHAR2,
    enabled   IN BOOLEAN := TRUE);

-- Update the schema that a lightweight user owns. Only apply for LW user.
  PROCEDURE set_user_schema (
    user    IN VARCHAR2,
    schema  IN VARCHAR2);

-- Set GUID. The guid only can be set if the principal is from an external
-- source and the previous guid is null.
  PROCEDURE set_guid (
    principal IN VARCHAR2,
    guid      IN RAW);

-- Set/modify the user status that a lightweight user owns.
  PROCEDURE set_user_status (
    user   IN VARCHAR2,
    status IN PLS_INTEGER);

-- Set the description of a principal.
  PROCEDURE set_description (
    principal     IN VARCHAR2,
    description   IN VARCHAR2);

-- Set ACL
  PROCEDURE set_acl (
    principal IN VARCHAR2,
    acl       IN VARCHAR2);

-- Set profile
  PROCEDURE set_profile(
    user      IN VARCHAR2,
    profile   IN VARCHAR2);

-- Set password.
  PROCEDURE set_password (
    user       IN VARCHAR2,
    password   IN VARCHAR2,
    type       IN PLS_INTEGER := XS_SHA512,
    opassword  IN VARCHAR2 := NULL);
    PRAGMA SUPPLEMENTAL_LOG_DATA(set_password, NONE);

-- set_verifier Wrapper.
  PROCEDURE set_verifier (
    user      IN VARCHAR2,
    verifier  IN VARCHAR2,
    type      IN PLS_INTEGER := XS_SHA512);
    PRAGMA SUPPLEMENTAL_LOG_DATA(set_verifier, NONE);

-- Delete the principal.
  PROCEDURE delete_principal (
    principal     IN VARCHAR2,
    delete_option IN PLS_INTEGER:=XS_ADMIN_UTIL.DEFAULT_OPTION);

END XS_PRINCIPAL;
/

