create TYPE wri$_rept_session AUTHID CURRENT_USER UNDER wri$_rept_abstract_t
(
  overriding member function get_report(report_reference IN VARCHAR2)
    return xmltype
)
/

