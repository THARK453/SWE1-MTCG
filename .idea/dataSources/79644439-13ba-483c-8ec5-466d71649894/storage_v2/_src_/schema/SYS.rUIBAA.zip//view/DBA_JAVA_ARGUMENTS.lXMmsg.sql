create view DBA_JAVA_ARGUMENTS
            (OWNER, NAME, METHOD_INDEX, METHOD_NAME, ARGUMENT_POSITION, ARRAY_DEPTH, BASE_TYPE, ARGUMENT_CLASS) as
select /*+ no_cartesian(mmd) no_cartesian(mag)  ordered use_nl(o mmd) */ u.name, mmd.kln, mmd.mix, mmd.mnm, mag.aix,
       mag.aad,
       decode(mag.abt, 10, 'int',
                     11, 'long',
                     6, 'float',
                     7, 'double',
                     4, 'boolean',
                     8, 'byte',
                     5, 'char',
                     9, 'short',
                     2, 'class',
                     NULL),
       mag.aln
from sys.x$joxfm mmd, sys.x$joxmag mag, user$ u
where mmd.own = u.user#
  and mmd.mix != -1
  and mmd.mix = mag.mix
  and mmd.obn = mag.obn
/

comment on table DBA_JAVA_ARGUMENTS is 'argument information for all java classes'
/

comment on column DBA_JAVA_ARGUMENTS.OWNER is 'owner of the class'
/

comment on column DBA_JAVA_ARGUMENTS.NAME is 'name of the class'
/

comment on column DBA_JAVA_ARGUMENTS.METHOD_INDEX is 'the index of the method'
/

comment on column DBA_JAVA_ARGUMENTS.METHOD_NAME is 'the name of the method'
/

comment on column DBA_JAVA_ARGUMENTS.ARGUMENT_POSITION is 'the position of the argument, starting from 0'
/

comment on column DBA_JAVA_ARGUMENTS.ARRAY_DEPTH is 'array depth of the type of the arguement'
/

comment on column DBA_JAVA_ARGUMENTS.BASE_TYPE is 'base type of the type of the argument'
/

comment on column DBA_JAVA_ARGUMENTS.ARGUMENT_CLASS is 'if base_type is class, this gives the actual class name of the argument'
/

