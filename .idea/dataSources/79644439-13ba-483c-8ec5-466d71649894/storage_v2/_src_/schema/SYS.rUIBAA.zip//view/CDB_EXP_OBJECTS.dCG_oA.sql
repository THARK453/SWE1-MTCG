create view CDB_EXP_OBJECTS (OWNER, OBJECT_NAME, OBJECT_TYPE, CUMULATIVE, INCREMENTAL, EXPORT_VERSION, CON_ID) as
SELECT k."OWNER",k."OBJECT_NAME",k."OBJECT_TYPE",k."CUMULATIVE",k."INCREMENTAL",k."EXPORT_VERSION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_EXP_OBJECTS") k
/

comment on table CDB_EXP_OBJECTS is 'Objects that have been incrementally exported in all containers'
/

comment on column CDB_EXP_OBJECTS.OWNER is 'Owner of exported object'
/

comment on column CDB_EXP_OBJECTS.OBJECT_NAME is 'Name of exported object'
/

comment on column CDB_EXP_OBJECTS.OBJECT_TYPE is 'Type of exported object'
/

comment on column CDB_EXP_OBJECTS.CUMULATIVE is 'Timestamp of last cumulative export'
/

comment on column CDB_EXP_OBJECTS.INCREMENTAL is 'Timestamp of last incremental export'
/

comment on column CDB_EXP_OBJECTS.EXPORT_VERSION is 'The id of the export session'
/

comment on column CDB_EXP_OBJECTS.CON_ID is 'container id'
/

