create view CDB_AUTO_SEGADV_CTL
            (AUTO_TASKID, TABLESPACE_NAME, SEGMENT_OWNER, SEGMENT_NAME, SEGMENT_TYPE, PARTITION_NAME, STATUS, REASON,
             REASON_VALUE, CREATION_TIME, PROCESSED_TASKID, END_TIME, CON_ID)
as
SELECT k."AUTO_TASKID",k."TABLESPACE_NAME",k."SEGMENT_OWNER",k."SEGMENT_NAME",k."SEGMENT_TYPE",k."PARTITION_NAME",k."STATUS",k."REASON",k."REASON_VALUE",k."CREATION_TIME",k."PROCESSED_TASKID",k."END_TIME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_AUTO_SEGADV_CTL") k
/

comment on table CDB_AUTO_SEGADV_CTL is ' in all containers'
/

comment on column CDB_AUTO_SEGADV_CTL.AUTO_TASKID is 'Creation Task id of the auto segment advisor job'
/

comment on column CDB_AUTO_SEGADV_CTL.TABLESPACE_NAME is 'Tablespace Name of the tablespace processed by the auto segment advisor'
/

comment on column CDB_AUTO_SEGADV_CTL.SEGMENT_OWNER is 'Owner of the segment processed by the auto segment advisor'
/

comment on column CDB_AUTO_SEGADV_CTL.SEGMENT_NAME is 'Name of the segment processed by the auto segment advisor'
/

comment on column CDB_AUTO_SEGADV_CTL.SEGMENT_TYPE is 'Type of the segment processed by the auto segment advisor'
/

comment on column CDB_AUTO_SEGADV_CTL.PARTITION_NAME is 'Name of the partition processed by the advisor'
/

comment on column CDB_AUTO_SEGADV_CTL.STATUS is 'Status of the auto advisor task for this segment or tablespace'
/

comment on column CDB_AUTO_SEGADV_CTL.REASON is 'Reason why this segment or tablespace is chosen for analysis'
/

comment on column CDB_AUTO_SEGADV_CTL.REASON_VALUE is 'Reason value for the segment or tablespace'
/

comment on column CDB_AUTO_SEGADV_CTL.CREATION_TIME is 'Time at which this entry was created'
/

comment on column CDB_AUTO_SEGADV_CTL.PROCESSED_TASKID is 'The auto task id that processed this segment'
/

comment on column CDB_AUTO_SEGADV_CTL.END_TIME is 'Time at which the segment was completely processed'
/

comment on column CDB_AUTO_SEGADV_CTL.CON_ID is 'container id'
/

