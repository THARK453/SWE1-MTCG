create view V_$SQL_MONITOR_SESSTAT (CON_ID, KEY, STATISTIC#, VALUE) as
select "CON_ID","KEY","STATISTIC#","VALUE" from v$sql_monitor_sesstat
/

