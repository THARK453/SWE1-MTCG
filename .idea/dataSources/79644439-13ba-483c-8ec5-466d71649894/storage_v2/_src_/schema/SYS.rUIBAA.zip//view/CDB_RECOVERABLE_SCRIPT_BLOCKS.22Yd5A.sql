create view CDB_RECOVERABLE_SCRIPT_BLOCKS
            (SCRIPT_ID, BLOCK_NUM, FORWARD_BLOCK, FORWARD_BLOCK_DBLINK, UNDO_BLOCK, UNDO_BLOCK_DBLINK, STATUS,
             BLOCK_COMMENT, CON_ID)
as
SELECT k."SCRIPT_ID",k."BLOCK_NUM",k."FORWARD_BLOCK",k."FORWARD_BLOCK_DBLINK",k."UNDO_BLOCK",k."UNDO_BLOCK_DBLINK",k."STATUS",k."BLOCK_COMMENT",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_RECOVERABLE_SCRIPT_BLOCKS") k
/

comment on table CDB_RECOVERABLE_SCRIPT_BLOCKS is 'Details about the recoverable script blocks in all containers'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.SCRIPT_ID is 'global unique id of the recoverable script to which this block belongs'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.BLOCK_NUM is 'nth block in the recoverable script to be executed'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.FORWARD_BLOCK is 'forward block to be executed'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.FORWARD_BLOCK_DBLINK is 'database where the forward block is executed'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.UNDO_BLOCK is 'block to rollback the forward operation'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.UNDO_BLOCK_DBLINK is 'database where the undo block is executed'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.STATUS is 'status of the block execution - NOT_STARTED, EXECUTING, DONE, ERROR'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.BLOCK_COMMENT is 'comment for the block'
/

comment on column CDB_RECOVERABLE_SCRIPT_BLOCKS.CON_ID is 'container id'
/

