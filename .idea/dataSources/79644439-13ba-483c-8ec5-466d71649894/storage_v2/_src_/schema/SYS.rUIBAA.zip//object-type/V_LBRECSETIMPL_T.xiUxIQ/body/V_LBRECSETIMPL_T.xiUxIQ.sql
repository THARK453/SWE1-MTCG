create type body v_lbRecSetImpl_t is

  static function ODCITablePrepare(sctx OUT v_lbRecSetImpl_t,
                                   ti   IN  SYS.ODCITabFuncInfo)
    return number is
  begin
    -- create instance of object, initialise curval, done and needobsolete
    sctx:=v_lbRecSetImpl_t(0, 0, 0);

    -- check if user is interested in obsolete column. If this column location
    -- is changed in object definition, this should be fixed.
    for i in ti.Attrs.first .. ti.Attrs.last
    loop
      if (ti.Attrs(i) = 20) then
         sctx.needobsolete := 1;
         exit;
      end if;
    end loop;

    return SYS.ODCIConst.Success;
  end ODCITablePrepare;

  static function ODCITableStart(sctx IN OUT v_lbRecSetImpl_t)
    return number is
  begin
    return SYS.ODCIConst.Success;
  end ODCITableStart;

-- Fetch function is not called more than once. It returns all rows when
-- called first time for each query because we can not have package composite
-- types within object definition. For the same reason, the nrows parameter
-- is ignored.
  member function ODCITableFetch(self   IN OUT v_lbRecSetImpl_t,
                                 nrows  IN     number,
                                 objSet OUT    v_lbRecSet_t)
    return number is
    n               number  := 0;
    firstCall       boolean := TRUE;
    ret             boolean := TRUE;
    redundancy      number;
    recovery_window number;
    untilTime       date;
    lbRec           sys.dbms_rcvman.lbrec_t;
    lbCursor        sys.dbms_rcvman.lbCursor_t;
    lbState         sys.dbms_rcvman.lbState_t;
  begin
    objSet:=v_lbRecSet_t();

    -- reset package state
    sys.dbms_rcvman.resetAll;
    -- Set database so that user does not need to care
    sys.dbms_rcvman.setDatabase(NULL, NULL, NULL, NULL);

    redundancy := 1;
    recovery_window := 0;

    -- We need to get the retention policy, and to set untilTime if
    -- retention policy is recovery_window.
    -- Get retention policy (recovery window and redunadcy).
    sys.dbms_rcvman.getRetentionPolicy(recovery_window, redundancy);

    -- Always work with all incarnations.
    sys.dbms_rcvman.setAllIncarnations(TRUE);

    -- Set untilTime and untilSCN for recovery window (if any).
    if (recovery_window > 0)
    then
      select (sysdate-recovery_window) into untilTime from dual;
      sys.dbms_rcvman.setUntilTime(untilTime);
    end if;

    sys.dbms_rcvman.setDeviceTypeAny;

    if (recovery_window = 0 and redundancy = 0) then
       -- don't need obsolete data if there the policy is NONE
       sys.dbms_rcvman.setNeedObsoleteData(false);
    else
       if self.needobsolete = 1 then
          sys.dbms_rcvman.setNeedObsoleteData(true);
       else
          sys.dbms_rcvman.setNeedObsoleteData(false);
       end if;
    end if;

    while ret and self.done = 0 loop
      ret := sys.dbms_rcvman.listBackup(lbRec, firstCall, FALSE,
                                        redundancy,
                                        TRUE, lbCursor, lbState, null);
      if (lbRec.pkey is not null)
      then
        objSet.extend;
        n := n + 1;
        objSet(n):= v_lbRec_t(
                            to_number(null),   -- list_order1
                            to_number(null),   -- list_order2
                            to_number(null),   -- pkey
                            to_char(null),     -- backup_type
                            to_char(null),     -- file_type
                            to_char(null),     -- keep
                            to_date(null),     -- keep_until
                            to_char(null),     -- keep_options
                            to_char(null),     -- status
                            to_char(null),     -- fname
                            to_char(null),     -- tag
                            to_char(null),     -- media
                            to_number(null),   -- recid
                            to_number(null),   -- stamp
                            to_char(null),     -- device_type
                            to_number(null),   -- block_size
                            to_date(null),     -- completion_time
                            to_char(null),     -- is_rdf
                            to_char(null),     -- compressed
                            to_char(null),     -- obsolete
                            to_number(null),   -- bytes
                            to_number(null),   -- bs_key
                            to_number(null),   -- bs_count
                            to_number(null),   -- bs_stamp
                            to_char(null),     -- bs_type
                            to_char(null),     -- bs_incr_type
                            to_number(null),   -- bs_pieces
                            to_number(null),   -- bs_copies
                            to_date(null),     -- bs_completion_time
                            to_char(null),     -- bs_status
                            to_number(null),   -- bs_bytes
                            to_char(null),     -- bs_compressed
                            to_char(null),     -- bs_tag
                            to_char(null),     -- bs_device_type
                            to_number(null),   -- bp_piece#
                            to_number(null),   -- bp_copy#
                            to_number(null),   -- df_file#
                            to_number(null),   -- df_ts#
                            to_number(null),   -- df_plugin_change#
                            to_number(null),   -- df_foreign_dbid
                            to_char(null),     -- df_tablespace
                            to_number(null),   -- df_resetlogs_change#
                            to_number(null),   -- df_creation_change#
                            to_number(null),   -- df_checkpoint_change#
                            to_date(null),     -- df_ckp_mod_time
                            to_number(null),   -- df_incremental_change#
                            to_number(null),   -- rl_thread#
                            to_number(null),   -- rl_sequence#
                            to_number(null),   -- rl_resetlogs_change#
                            to_number(null),   -- rl_first_change#
                            to_date(null),     -- rl_first_time
                            to_number(null),   -- rl_next_change#
                            to_date(null),     -- rl_next_time
                            to_number(null));  -- con_id
        objSet(n).list_order1            := lbRec.list_order1;
        objSet(n).list_order2            := lbRec.list_order2;
        objSet(n).pkey                   := lbRec.pkey;
        objSet(n).backup_type            := lbRec.backup_type;
        objSet(n).file_type              := lbRec.file_type;
        objSet(n).keep                   := lbRec.keep;
        objSet(n).keep_until             := lbRec.keep_until;
        objSet(n).keep_options           := lbRec.keep_options;
        objSet(n).status                 := lbRec.status;
        objSet(n).fname                  := lbRec.fname;
        objSet(n).tag                    := lbRec.tag;
        objSet(n).media                  := lbRec.media;
        objSet(n).recid                  := lbRec.stamp;
        objSet(n).stamp                  := lbRec.stamp;
        objSet(n).device_type            := lbRec.device_type;
        objSet(n).block_size             := lbRec.block_size;
        objSet(n).completion_time        := lbRec.completion_time;
        objSet(n).is_rdf                 := lbRec.is_rdf;
        objSet(n).compressed             := lbRec.compressed;
        objSet(n).obsolete               := lbRec.obsolete;
        objSet(n).bytes                  := lbRec.bytes;
        objSet(n).bs_key                 := lbRec.bs_key;
        objSet(n).bs_count               := lbRec.bs_count;
        objSet(n).bs_stamp               := lbRec.bs_stamp;
        objSet(n).bs_type                := lbRec.bs_type;
        objSet(n).bs_incr_type           := lbRec.bs_incr_type;
        objSet(n).bs_pieces              := lbRec.bs_pieces;
        objSet(n).bs_copies              := lbRec.bs_copies;
        objSet(n).bs_completion_time     := lbRec.bs_completion_time;
        objSet(n).bs_status              := lbRec.bs_status;
        objSet(n).bs_bytes               := lbRec.bs_bytes;
        objSet(n).bs_compressed          := lbRec.bs_compressed;
        objSet(n).bs_tag                 := lbRec.bs_tag;
        objSet(n).bs_device_type         := lbRec.bs_device_type;
        objSet(n).bp_piece#              := lbRec.bp_piece#;
        objSet(n).bp_copy#               := lbRec.bp_copy#;
        objSet(n).df_file#               := lbRec.df_file#;
        objSet(n).df_ts#                 := lbRec.df_ts#;
        objSet(n).df_plugin_change#      := lbRec.df_plugin_change#;
        objSet(n).df_foreign_dbid        := lbRec.df_foreign_dbid;
        objSet(n).df_tablespace          := lbRec.df_tablespace;
        objSet(n).df_resetlogs_change#   := lbRec.df_resetlogs_change#;
        objSet(n).df_creation_change#    := lbRec.df_creation_change#;
        objSet(n).df_checkpoint_change#  := lbRec.df_checkpoint_change#;
        objSet(n).df_ckp_mod_time        := lbRec.df_ckp_mod_time;
        objSet(n).df_incremental_change# := lbRec.df_incremental_change#;
        objSet(n).rl_thread#             := lbRec.rl_thread#;
        objSet(n).rl_sequence#           := lbRec.rl_sequence#;
        objSet(n).rl_resetlogs_change#   := lbRec.rl_resetlogs_change#;
        objSet(n).rl_first_change#       := lbRec.rl_first_change#;
        objSet(n).rl_first_time          := lbRec.rl_first_time;
        objSet(n).rl_next_change#        := lbRec.rl_next_change#;
        objSet(n).rl_next_time           := lbRec.rl_next_time;
        objSet(n).con_id                 := lbRec.con_id;
      end if;
      firstCall := false;
      self.curval:=self.curval+1;
      if not ret then
        self.done := 1;
      end if;
    end loop;
    return SYS.ODCIConst.Success;
  end ODCITableFetch;

  member function ODCITableClose(self IN v_lbRecSetImpl_t)
    return number
  is
  begin
    return SYS.ODCIConst.Success;
  end ODCITableClose;
end;
/

