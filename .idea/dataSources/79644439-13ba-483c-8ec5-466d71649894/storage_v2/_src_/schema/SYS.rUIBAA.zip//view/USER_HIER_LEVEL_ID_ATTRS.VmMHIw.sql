create view USER_HIER_LEVEL_ID_ATTRS (HIER_NAME, LEVEL_NAME, ATTRIBUTE_NAME, ORDER_NUM, ORIGIN_CON_ID) as
select HIER_NAME,
       LEVEL_NAME,
       ATTRIBUTE_NAME,
       ORDER_NUM,
       ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_HIER_LEVEL_ID_ATTRS)
where owner = sys_context('USERENV','CURRENT_USER')
/

comment on table USER_HIER_LEVEL_ID_ATTRS is 'Hierarchy Level ID Attributes in the database'
/

comment on column USER_HIER_LEVEL_ID_ATTRS.HIER_NAME is 'Name of owning Heirarchy in the database'
/

comment on column USER_HIER_LEVEL_ID_ATTRS.LEVEL_NAME is 'Name of Hierarchy Level in the database'
/

comment on column USER_HIER_LEVEL_ID_ATTRS.ATTRIBUTE_NAME is 'Name of Attribute in the database'
/

comment on column USER_HIER_LEVEL_ID_ATTRS.ORDER_NUM is 'Order number of Attribute in the sequence'
/

comment on column USER_HIER_LEVEL_ID_ATTRS.ORIGIN_CON_ID is 'Original con_id of Attribute in the sequence'
/

