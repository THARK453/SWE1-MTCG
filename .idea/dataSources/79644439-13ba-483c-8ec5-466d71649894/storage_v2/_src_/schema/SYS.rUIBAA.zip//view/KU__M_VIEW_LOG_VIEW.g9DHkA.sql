create view KU$_M_VIEW_LOG_VIEW
            (VERS_MAJOR, VERS_MINOR, MOWNER, MASTER, OLDEST, OLDEST_PK, OSCN, YOUNGEST, YSCN, LOG, TRIG, FLAG, MTIME,
             TEMP_LOG, OLDEST_OID, OLDEST_NEW, OLDEST_SEQ, GLOBAL_DB_NAME, PURGE_START, PURGE_NEXT, FC_COUNT, FC_LIST,
             LM_COUNT, LM_LIST)
as
select '1',
         case when dbms_metadata.get_version >= '11.02.00.00.00' then '1'
              else '0'
         end,
         m.mowner, m.master,
         to_char(m.oldest,'YYYY-MM-DD HH24:MI:SS'),
         TO_CHAR(m.oldest_pk, 'YYYY-MM-DD HH24:MI:SS'),
         m.oscn,
         TO_CHAR(m.youngest, 'YYYY-MM-DD HH24:MI:SS'),
         m.yscn, m.log, m.trig,
         case when dbms_metadata.get_version >= '11.02.00.00.00'
           then m.flag
           else bitand(m.flag,65535)  /* pre-11.2, flag was a ub2 */
         end,
         TO_CHAR(m.mtime, 'YYYY-MM-DD HH24:MI:SS'),
         m.temp_log,
         TO_CHAR(m.oldest_oid, 'YYYY-MM-DD HH24:MI:SS'),
         TO_CHAR(m.oldest_new, 'YYYY-MM-DD HH24:MI:SS'),
         TO_CHAR(m.oldest_seq, 'YYYY-MM-DD HH24:MI:SS'),
         p.value$,
         case when dbms_metadata.get_version >= '11.02.00.00.00'
           then TO_CHAR(m.purge_start, 'YYYY-MM-DD HH24:MI:SS')
           else NULL
         end,
         case when dbms_metadata.get_version >= '11.02.00.00.00'
           then m.purge_next
           else NULL
         end,
         (select count(*)
                       from   sys.mlog_refcol$ r
                       where  m.mowner = r.mowner
                          and m.master = r.master),
         cast(multiset(select r.colname,
                              to_char(r.oldest, 'YYYY-MM-DD HH24:MI:SS'),
                              r.flag
                       from   sys.mlog_refcol$ r
                       where  m.mowner = r.mowner
                          and m.master = r.master)
                       as ku$_refcol_list_t),
         (select count(*)
                       from   sys.slog$ s
                       where  m.mowner = s.mowner
                          and m.master = s.master),
         cast(multiset(select s.snapid,
                              to_char(s.snaptime, 'YYYY-MM-DD HH24:MI:SS'),
                              case when
                                dbms_metadata.get_version >= '11.02.00.00.00'
                                then s.tscn
                                else NULL
                              end
                       from   sys.slog$ s
                       where  m.mowner = s.mowner
                          and m.master = s.master)
                       as ku$_slog_list_t)
  from   sys.mlog$ m, sys.props$ p
  where  p.name  = 'GLOBAL_DB_NAME'
  /* for < 11.2, exclude MV logs with async_purge, sched_purge, commit scn */
  and (dbms_metadata.get_version >= '11.02.00.00.00'
       or
       (dbms_metadata.get_version < '11.02.00.00.00'
        and bitand(m.flag, 16384+32768+65536)=0))
 UNION ALL
  /* Get staging log details */
  select '1',
         case when dbms_metadata.get_version >= '11.02.00.00.00' then '1'
              else '0'
         end,
         u1.name, o2.name,NULL,NULL,NULL,NULL,NULL,o1.name,NULL,NULL,
         NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
from sys.syncref$_table_info srt, sys.obj$ o1, sys.user$ u1,
     sys.obj$ o2
where dbms_metadata.get_version >= '12.02.00.02.00' and
      o1.owner# = u1.user# and
      o1.obj# = srt.staging_log_obj# and
      o2.obj# = srt.table_obj#
/

