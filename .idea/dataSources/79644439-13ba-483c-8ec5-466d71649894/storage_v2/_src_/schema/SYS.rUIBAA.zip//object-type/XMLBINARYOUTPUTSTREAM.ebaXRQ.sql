create type XMLBinaryOutputStream under utl_BinaryOutputStream
(
  constructor function XMLBinaryOutputStream (h in raw, n in raw)
  return self as result,
  overriding member function write (self   in out nocopy XMLBinaryOutputStream,
                             	    bytes  in out nocopy raw,
                                    numBytes in integer default 1)
  return integer,
  ---- this function writes the number of bytes specified by the parameter numBytes
  ----(default is 1) from parameter bytes into the stream. The actual number of
  ---- bytes written is returned.
  overriding member procedure write (self  in out nocopy XMLBinaryOutputStream,
                                     bytes in out nocopy raw,
      		                     numBytes in out integer),
   ---- this procedure writes the number of bytes specified in parameter numBytes
   ---- from parameter bytes to the stream. The actual number of bytes written is
   ---- returned in parameter numBytes.
   overriding member procedure write (self   in out nocopy XMLBinaryOutputStream,
                                      bytes  in out nocopy raw,
  	                              offset in integer,
                                      numBytes in out integer),
  ---- this procedure the number of bytes specified by numBytes to the stream,
  ---- beginning at the offset specified by parameter offset.
  ---- The actual number of bytes written is returned in parameter numBytes
  overriding member procedure flush (self in out nocopy XMLBinaryOutputStream),
  ---- this procedure insures that any buffered bytes are copied to the
  ----node destination.
  Overriding member procedure close (self in out nocopy XMLBinaryOutputStream),
  ---- this procedure frees all resources associated with the stream.
  overriding member function isnull (self in out nocopy XMLBinaryOutputStream)
                                        return boolean
);
/

