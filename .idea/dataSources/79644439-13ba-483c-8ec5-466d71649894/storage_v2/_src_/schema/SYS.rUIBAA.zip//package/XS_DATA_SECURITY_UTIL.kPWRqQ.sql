create PACKAGE XS_DATA_SECURITY_UTIL AUTHID CURRENT_USER AS

  -- schedule_static_acl_refresh
  --             - schedule automatic refresh of an ACLMV for a given table.
  --             - this function will change the refresh mode of the
  --               corresponding ACLMV to "ON DEMAND"
  --
  -- INPUT PARAMETERS
  --   schema_name   - schema owning the object, current user if NULL
  --   table_name     - name of object
  --   start_date      - time of first refresh to occur
  --   repeat_interval - schedule interval
  --   comments        - comments

  PROCEDURE schedule_static_acl_refresh(
          schema_name   IN VARCHAR2 := NULL,
          table_name     IN VARCHAR2,
          start_date      IN TIMESTAMP WITH TIME ZONE := NULL,
          repeat_interval IN VARCHAR2 := NULL,
          comments        IN VARCHAR2 := NULL);
  -- Bug 22545933: Enable log based replication for the procedure
  PRAGMA SUPPLEMENTAL_LOG_DATA(schedule_static_acl_refresh, AUTO_WITH_COMMIT);

  ----------------------------------------------------------------------------

  -- alter_static_acl_refresh
  --             - alter the refresh mode for a ACLMV for a given table
  --             - this function will remove any refresh schedule for this
  --               ACLMV (see schedule_static_acl_refresh)
  --
  -- INPUT PARAMETERS
  --   schema_name   - schema owning the object, current user if NULL
  --   table_name    - name of object
  --   refresh_mode  - refresh mode for internal ACLMV. 'ON DEMAND' or
  --                     'ON COMMIT' are the only legal values

  PROCEDURE alter_static_acl_refresh(schema_name IN VARCHAR2 := NULL,
                                     table_name   IN VARCHAR2,
                                     refresh_mode  IN VARCHAR2);
  -- Bug 22545933: Enable log based replication for the procedure
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_static_acl_refresh, AUTO_WITH_COMMIT);

  ----------------------------------------------------------------------------

  -- purge_acl_refresh_history
  --           - purge contents of XDS_ACL_REFRESH_STATUS view for this
  --             table's ACLMV
  --
  -- INPUT PARAMETERS
  --   object_schema   - schema owning the object, current user if NULL
  --   object_name     - name of object
  --   purge_date      - date of scheduled purge - immediate if omitted

  PROCEDURE purge_acl_refresh_history(object_schema IN VARCHAR2 := NULL,
                                      object_name   IN VARCHAR2,
                                      purge_date    IN DATE := NULL);
  -- Bug 22545933: Enable log based replication for the procedure
  PRAGMA SUPPLEMENTAL_LOG_DATA(purge_acl_refresh_history, AUTO_WITH_COMMIT);

  ----------------------------------------------------------------------------
  -- xs$refresh_static_acl (not documented)
  --           - scheduler callback procedure to refresh the acl-mv on a table
  --
  -- INPUT PARAMETERS
  --   schema_name     - schema owning the table
  --   table_name      - name of table
  --   mview_name      - name of miew
  --   job_name        - name of job

  procedure  xs$refresh_static_acl(
                          schema_name IN VARCHAR2,
                          table_name  IN VARCHAR2,
                          mview_name IN VARCHAR2,
                          job_name   IN VARCHAR2);

  ----------------------------------------------------------------------------

  -- set_trace_level
  --            sets the trace level (used for debugging, not documented)
  --            The tracing info of the scheduled mv refresh is logged
  --            in aclmv$_reflog table, and is useful for debugging.
  --
  -- INPUT PARAMETERS
  --   schema_name   - schema owning the object
  --   table_name    - name of object
  --   level         - the trace level

  PROCEDURE set_trace_level(schema_name  IN VARCHAR2,
                            table_name   IN VARCHAR2,
                            level        IN NUMBER);

END XS_DATA_SECURITY_UTIL;
/

