create PACKAGE XS_SECURITY_CLASS AUTHID CURRENT_USER AS

-- Enable log based replication for this package
PRAGMA SUPPLEMENTAL_LOG_DATA(default, AUTO);

-- Create a security class
PROCEDURE CREATE_SECURITY_CLASS (
          name          IN VARCHAR2,
          priv_list     IN XS$PRIVILEGE_LIST,
          parent_list   IN XS$NAME_LIST:= NULL,
          description   IN VARCHAR2:= NULL
          ) ;

-- Add a parent security class
PROCEDURE ADD_PARENTS (
          sec_class IN VARCHAR2,
          parent    IN VARCHAR2
          );

-- Add a list of parent security classes
PROCEDURE ADD_PARENTS (
          sec_class   IN VARCHAR2,
          parent_list IN XS$NAME_LIST
          );

-- Remove all parent security classes
PROCEDURE REMOVE_PARENTS (
          sec_class IN VARCHAR2
          );

-- Remove a parent security class
PROCEDURE REMOVE_PARENTS (
          sec_class IN VARCHAR2,
          parent    IN VARCHAR2
          );

-- Remove a list of parent security classes
PROCEDURE REMOVE_PARENTS (
          sec_class     IN VARCHAR2,
          parent_list   IN XS$NAME_LIST
          );

-- Add a privilege to existing list of privileges (if any) of the
-- security class
PROCEDURE ADD_PRIVILEGES (
          sec_class         IN VARCHAR2,
          priv              IN VARCHAR2,
          implied_priv_list IN XS$NAME_LIST:=NULL,
          description       IN VARCHAR2:=NULL
          );

-- Add a list of privileges to existing list of privileges (if any) of the
-- security class
PROCEDURE ADD_PRIVILEGES (
          sec_class     IN VARCHAR2,
          priv_list     IN XS$PRIVILEGE_LIST
          );

-- Set privileges for the security class
PROCEDURE REMOVE_PRIVILEGES (
          sec_class     IN VARCHAR2
          );

-- Remove a privilege from the security (if the privilege is present)
PROCEDURE REMOVE_PRIVILEGES (
          sec_class   IN VARCHAR2,
          priv        IN VARCHAR2
          );

-- Remove a list of privileges from the security (if the privileges are
-- present)
PROCEDURE REMOVE_PRIVILEGES (
          sec_class       IN VARCHAR2,
          priv_list       IN XS$NAME_LIST
          );

-- Add implied privilege (single)
PROCEDURE ADD_IMPLIED_PRIVILEGES (
          sec_class       IN VARCHAR2,
          priv            IN VARCHAR2,
          implied_priv    IN VARCHAR2
          );

-- Add implied privileges (multiple)
PROCEDURE ADD_IMPLIED_PRIVILEGES (
          sec_class         IN VARCHAR2,
          priv              IN VARCHAR2,
          implied_priv_list IN XS$NAME_LIST
          );

-- Remove implied privilege (single)
PROCEDURE REMOVE_IMPLIED_PRIVILEGES (
          sec_class         IN VARCHAR2,
          priv            IN VARCHAR2,
          implied_priv    IN VARCHAR2
          );

-- Remove implied privileges (multiple)
PROCEDURE REMOVE_IMPLIED_PRIVILEGES (
          sec_class         IN VARCHAR2,
          priv              IN VARCHAR2,
          implied_priv_list IN XS$NAME_LIST
          );

-- Remove all implied privileges
PROCEDURE REMOVE_IMPLIED_PRIVILEGES (
          sec_class       IN VARCHAR2,
          priv            IN VARCHAR2
          );

-- Set description of the security class
PROCEDURE SET_DESCRIPTION (
          sec_class      IN VARCHAR2,
          description    IN VARCHAR2
          );

-- Delete the security class
PROCEDURE DELETE_SECURITY_CLASS (
          sec_class       IN VARCHAR2,
          delete_option   IN PLS_INTEGER:= XS_ADMIN_UTIL.DEFAULT_OPTION
          );

END XS_SECURITY_CLASS;
/

