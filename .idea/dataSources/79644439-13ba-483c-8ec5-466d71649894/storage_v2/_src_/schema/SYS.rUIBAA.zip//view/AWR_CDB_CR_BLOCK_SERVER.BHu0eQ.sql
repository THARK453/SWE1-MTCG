create view AWR_CDB_CR_BLOCK_SERVER
            (SNAP_ID, DBID, INSTANCE_NUMBER, CR_REQUESTS, CURRENT_REQUESTS, DATA_REQUESTS, UNDO_REQUESTS, TX_REQUESTS,
             CURRENT_RESULTS, PRIVATE_RESULTS, ZERO_RESULTS, DISK_READ_RESULTS, FAIL_RESULTS, FAIRNESS_DOWN_CONVERTS,
             FLUSHES, BUILDS, LIGHT_WORKS, ERRORS, CON_DBID, CON_ID)
as
select crb.snap_id, crb.dbid, crb.instance_number,
       cr_requests, current_requests,
       data_requests, undo_requests, tx_requests,
       current_results, private_results, zero_results,
       disk_read_results, fail_results,
       fairness_down_converts, flushes, builds,
       light_works, errors,
       decode(crb.con_dbid, 0, crb.dbid, crb.con_dbid),
       decode(crb.per_pdb, 0, 0,
         con_dbid_to_id(decode(crb.con_dbid, 0, crb.dbid, crb.con_dbid))) con_id
  from AWR_CDB_SNAPSHOT sn, WRH$_CR_BLOCK_SERVER crb
  where     sn.snap_id         = crb.snap_id
        and sn.dbid            = crb.dbid
        and sn.instance_number = crb.instance_number
/

comment on table AWR_CDB_CR_BLOCK_SERVER is 'Consistent Read Block Server Historical Statistics'
/

