create view GV_$JAVA_SERVICES (INST_ID, NAME, CON_ID) as
select "INST_ID","NAME","CON_ID" from gv$java_services
/

