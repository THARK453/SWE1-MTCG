create view KU$_11_2_SYSGRANT_VIEW (VERS_MAJOR, VERS_MINOR, PRIVILEGE, GRANTEE, PRIVNAME, SEQUENCE, WGO, USER_SPARE1) as
select * from ku$_sysgrant_view t
  where t.privilege >  -351
/

