create procedure xmlvalidate is
  p_num NUMBER;
begin
  SELECT COUNT(*) INTO p_num
  FROM obj$
  WHERE type# = 29 AND owner# = 0 AND status <> 1
    AND ( 1=0
        OR name like 'javax/xml%'
        OR name like 'javax/xml/namespace%'
        OR name like 'javax/xml/parsers%'
        OR name like 'javax/xml/transform%'
        OR name like 'javax/xml/transform/dom%'
        OR name like 'javax/xml/transform/sax%'
        OR name like 'javax/xml/transform/stream%'
        OR name like 'oracle/xml/async%'
        OR name like 'oracle/xml/binxml%'
        OR name like 'oracle/xml/comp%'
        OR name like 'oracle/xml/common%'
        OR name like 'oracle/xml/fdom%'
        OR name like 'oracle/xml/fisupport%'
        OR name like 'oracle/xml/jaxp%'
        OR name like 'oracle/xml/jdwp%'
        OR name like 'oracle/xml/mesg%'
        OR name like 'oracle/xml/parser%'
        OR name like 'oracle/xml/sql%'
        OR name like 'oracle/xml/util%'
        OR name like 'oracle/xml/xpath%'
        OR name like 'oracle/xml/xqxp%'
        OR name like 'oracle/xml/xslt%'
        OR name like 'oracle/xml/xti%'
        OR name like 'org/w3c/dom%'
        OR name like 'org/xml/sax%'
        OR name like 'OracleXML%'
    );
  IF p_num != 0 THEN
    dbms_registry.invalid('XML');
  ELSE
    dbms_registry.valid('XML');
  END IF;
  EXCEPTION WHEN no_data_found THEN
    dbms_registry.valid('XML');
end xmlvalidate;
/

