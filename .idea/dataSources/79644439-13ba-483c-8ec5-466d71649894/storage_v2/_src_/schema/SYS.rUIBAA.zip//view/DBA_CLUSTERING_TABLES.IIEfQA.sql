create view DBA_CLUSTERING_TABLES
            (OWNER, TABLE_NAME, CLUSTERING_TYPE, ON_LOAD, ON_DATAMOVEMENT, VALID, WITH_ZONEMAP, LAST_LOAD_CLST,
             LAST_DATAMOVE_CLST) as
select u.name, o.name,
  case when c.clstfunc = 1 then 'INTERLEAVED'
       else 'LINEAR'
  end,
  decode(bitand(c.flags, 1), 0, 'NO', 'YES'),
  decode(bitand(c.flags, 2), 0, 'NO', 'YES'),
  decode(bitand(c.flags, 4), 0, 'YES', 'NO'),
  decode(bitand(c.flags, 8), 0, 'NO', 'YES'),
  clstlastload,
  clstlastdm
from sys.user$ u, sys.clst$ c, sys.obj$ o
where o.owner# = u.user#
  and o.obj# = c.clstobj#
  and bitand(o.flags, 128) = 0
/

comment on table DBA_CLUSTERING_TABLES is 'Description of the clustering clause of tables accessible to dba'
/

comment on column DBA_CLUSTERING_TABLES.OWNER is 'Owner of the table'
/

comment on column DBA_CLUSTERING_TABLES.TABLE_NAME is 'Name of the table'
/

comment on column DBA_CLUSTERING_TABLES.CLUSTERING_TYPE is 'Clustering type'
/

comment on column DBA_CLUSTERING_TABLES.ON_LOAD is 'Will Oracle cluster data on load'
/

comment on column DBA_CLUSTERING_TABLES.ON_DATAMOVEMENT is 'Will Oracle cluster data on data movement, for example partition move'
/

comment on column DBA_CLUSTERING_TABLES.VALID is 'Is clustering valid. It is invalid if dimension does not have pk/uk constraint'
/

comment on column DBA_CLUSTERING_TABLES.WITH_ZONEMAP is 'Is a zonemap also created with clustering'
/

comment on column DBA_CLUSTERING_TABLES.LAST_LOAD_CLST is 'Last time the clustering occured on load'
/

comment on column DBA_CLUSTERING_TABLES.LAST_DATAMOVE_CLST is 'Last time the clustering occured on data movement, for example partition move'
/

