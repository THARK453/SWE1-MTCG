create view "_SYS_AIM_SEG_HISTOGRAM"
            (OBJ#, DATAOBJ#, TS#, TRACK_TIME, SEGMENT_WRITE, SEGMENT_READ, FULL_SCAN, LOOKUP_SCAN, N_FTS, N_LOOKUP,
             N_WRITE) as
select s.obj#, s.dataobj#, s.ts#, s.track_time,
          decode(bitand(s.segment_access, 1), 1, 'YES', 'NO'),
          decode(bitand(s.segment_access, 2), 2, 'YES', 'NO'),
          decode(bitand(s.segment_access, 4), 4, 'YES', 'NO'),
          decode(bitand(s.segment_access, 8), 8, 'YES', 'NO'),
          s.n_fts, s.n_lookup, s.n_write
    from heat_map_stat$ s,
         tab$ t,
         seg$ se
   where t.obj# = s.obj#
     and t.dataobj# = s.dataobj#
     and se.hwmincr = t.dataobj#
/* in-memory enabled */
     and bitand(se.spare1,  4294967296) = 4294967296
     and s.OBJ# != -1
union
    select s.obj#, s.dataobj#, s.ts#, s.track_time,
          decode(bitand(s.segment_access, 1), 1, 'YES', 'NO'),
          decode(bitand(s.segment_access, 2), 2, 'YES', 'NO'),
          decode(bitand(s.segment_access, 4), 4, 'YES', 'NO'),
          decode(bitand(s.segment_access, 8), 8, 'YES', 'NO'),
          s.n_fts, s.n_lookup, s.n_write
    from heat_map_stat$ s,
         tabpart$ t,
         seg$ se
   where t.obj# = s.obj#
     and t.dataobj# = s.dataobj#
     and se.hwmincr = t.dataobj#
/* in-memory enabled */
     and bitand(se.spare1,  4294967296) = 4294967296
     and s.OBJ# != -1
union
    select s.obj#, s.dataobj#, s.ts#, s.track_time,
          decode(bitand(s.segment_access, 1), 1, 'YES', 'NO'),
          decode(bitand(s.segment_access, 2), 2, 'YES', 'NO'),
          decode(bitand(s.segment_access, 4), 4, 'YES', 'NO'),
          decode(bitand(s.segment_access, 8), 8, 'YES', 'NO'),
          s.n_fts, s.n_lookup, s.n_write
    from heat_map_stat$ s,
         tabsubpart$ t,
         seg$ se
   where t.obj# = s.obj#
     and t.dataobj# = s.dataobj#
     and se.hwmincr = t.dataobj#
/* in-memory enabled */
     and bitand(se.spare1,  4294967296) = 4294967296
     and s.OBJ# != -1
union
   select obj#, dataobj#, ts#, track_time,
          segment_write, segment_read, full_scan, lookup_scan,
          n_full_scan, n_lookup_scan, n_segment_write
     from
         GV$IMHMSEG
     where
       (segment_write = 'YES' OR lookup_scan = 'YES' OR full_scan = 'YES') AND
       con_id = SYS_CONTEXT('USERENV', 'CON_ID')
/

