create view KU$_PLUGTS_TABLESPACE_VIEW (VERS_MAJOR, VERS_MINOR, TS_NUM, BITMAPPED, FLAGS, TS_NAME) as
select  '1','0', tsv.ts_num, tsv.bitmapped, tsv.flags, tsv.name
  from ku$_tablespace_view tsv
/

