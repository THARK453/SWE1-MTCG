create view CDB_XS_APPLIED_POLICIES
            (SCHEMA, OBJECT, POLICY, POLICY_OWNER, SEL, INS, UPD, DEL, IDX, ROW_ACL, OWNER_BYPASS, STATUS, CON_ID) as
SELECT k."SCHEMA",k."OBJECT",k."POLICY",k."POLICY_OWNER",k."SEL",k."INS",k."UPD",k."DEL",k."IDX",k."ROW_ACL",k."OWNER_BYPASS",k."STATUS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XS_APPLIED_POLICIES") k
/

comment on table CDB_XS_APPLIED_POLICIES is 'All the database objects on which Real Application Security data security policies are enabled in all containers'
/

comment on column CDB_XS_APPLIED_POLICIES.SCHEMA is 'Schema of the object'
/

comment on column CDB_XS_APPLIED_POLICIES.OBJECT is 'Name of the object'
/

comment on column CDB_XS_APPLIED_POLICIES.POLICY is 'Name of the data security policy'
/

comment on column CDB_XS_APPLIED_POLICIES.POLICY_OWNER is 'Owner of the data security policy'
/

comment on column CDB_XS_APPLIED_POLICIES.SEL is 'Policy enabled for SELECT statements'
/

comment on column CDB_XS_APPLIED_POLICIES.INS is 'Policy enabled for INSERT statements'
/

comment on column CDB_XS_APPLIED_POLICIES.UPD is 'Policy enabled for UPDATE statements'
/

comment on column CDB_XS_APPLIED_POLICIES.DEL is 'Policy enabled for DELETE statements'
/

comment on column CDB_XS_APPLIED_POLICIES.IDX is 'Policy enabled for INDEX statements'
/

comment on column CDB_XS_APPLIED_POLICIES.ROW_ACL is 'Object has row ACL column'
/

comment on column CDB_XS_APPLIED_POLICIES.OWNER_BYPASS is 'Policy bypassed by object owner'
/

comment on column CDB_XS_APPLIED_POLICIES.STATUS is 'Indicates whether the data security policy is enabled or disabled'
/

comment on column CDB_XS_APPLIED_POLICIES.CON_ID is 'container id'
/

