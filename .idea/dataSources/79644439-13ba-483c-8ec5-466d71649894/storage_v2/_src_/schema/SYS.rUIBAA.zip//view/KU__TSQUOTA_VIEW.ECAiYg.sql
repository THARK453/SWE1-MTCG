create view KU$_TSQUOTA_VIEW
            (VERS_MAJOR, VERS_MINOR, USER_ID, USER_NAME, TS_NAME, TS_ID, MAXBLOCKS, BLOCKSIZE, GRANTOR_NUM, GRANTOR,
             BLOCKS, PRIV1, PRIV2, PRIV3)
as
select  '1','0',
          u.user#, u.name, t.name, q.ts#, q.maxblocks, t.blocksize, q.grantor#,
          'SYSTEM', q.blocks, q.priv1, q.priv2, q.priv3
  from    sys.user$ u, sys.tsq$ q, sys.ts$ t
  where   q.user# = u.user# AND
          q.ts# = t.ts# AND
          q.maxblocks != 0 AND
          t.online$ IN (1, 2, 4) AND
          bitand(t.flags,2048) = 0 AND
          (SYS_CONTEXT('USERENV','CURRENT_USERID') = 0
                OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
/

