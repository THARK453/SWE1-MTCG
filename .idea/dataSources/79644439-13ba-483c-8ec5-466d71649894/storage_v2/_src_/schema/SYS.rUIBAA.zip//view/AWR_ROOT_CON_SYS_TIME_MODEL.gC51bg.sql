create view AWR_ROOT_CON_SYS_TIME_MODEL (SNAP_ID, DBID, INSTANCE_NUMBER, STAT_ID, STAT_NAME, VALUE, CON_DBID, CON_ID) as
select s.snap_id, s.dbid, s.instance_number, s.stat_id,
       nm.stat_name, value,
       decode(s.con_dbid, 0, s.dbid, s.con_dbid),
       con_dbid_to_id(decode(s.con_dbid, 0, s.dbid, s.con_dbid)) con_id
from AWR_ROOT_SNAPSHOT sn, WRH$_CON_SYS_TIME_MODEL s, WRH$_STAT_NAME nm
where      s.stat_id          = nm.stat_id
      and  s.dbid             = nm.dbid
      and  s.snap_id          = sn.snap_id
      and  s.dbid             = sn.dbid
      and  s.instance_number  = sn.instance_number
/

comment on table AWR_ROOT_CON_SYS_TIME_MODEL is 'PDB System Time Model Historical Statistics Information'
/

