create PACKAGE utl_recomp IS

$if utl_ident.is_oracle_server <> TRUE and
    utl_ident.is_timesten <> TRUE $then
  $error 'utl_recomp is not supported in this environment' $end
$end

   /*
    * Option flags supported by recomp_parallel and recomp_serial
    *   RANDOM_ORDER  - Use a random order for parallel recompilation.
    *                   *Note*: This is an internal testing mode that will
    *                   be slower than the default.
    *   REVERSE_ORDER - Use reverse-dependency order for parallel
    *                   recompilation.
    *                   *Note*: This is an internal testing mode that will
    *                   be slower than the default.
    *   SPECS_ONLY    - Only recompile specifications. With this flag set
    *                   only the following objects types will get recompiled:
    *                      VIEWS, SYNONYMS, PROCEDURE, FUNCTION, PACKAGE,
    *                      TYPE, LIBRARY.
    *                   This mechanism can be used to allow lazy revalidation
    *                   to take care of validating package bodies, type bodies
    *                   triggers etc.
    *   TYPES_ONLY    - Only recompile type specifications
    *   NEW_EDITION   - Only recompile invalid objects in the current edition.
    *                   This is useful for validating new or changed objects in
    *                   a new edition that may have been left invalid by the
    *                   installation process.
    */
   COMPILE_LOG       CONSTANT PLS_INTEGER := 2;                  /* Obsolete */
   NO_REUSE_SETTINGS CONSTANT PLS_INTEGER := 4;                  /* Obsolete */
   RANDOM_ORDER      CONSTANT PLS_INTEGER := 8;
   REVERSE_ORDER     CONSTANT PLS_INTEGER := 16;
   SPECS_ONLY        CONSTANT PLS_INTEGER := 32;
   TYPES_ONLY        CONSTANT PLS_INTEGER := 64;
   NEW_EDITION       CONSTANT PLS_INTEGER := 128;

   /*
    * NAME:
    *   recomp_parallel
    *
    * PARAMETERS:
    *   threads    (IN) - Number of recompile threads to run in parallel
    *                     If NULL, 0, or negative, RECOMP_PARALLEL computes a
    *                     default degree of parallelism as the product of
    *                     Oracle parameters "cpu_count" and
    *                     "parallel_threads_per_cpu". On a Real Application
    *                     Clusters installation, the degree of parallelism
    *                     is the sum of individual settings on each node in
    *                     the cluster.
    *   schema     (IN) - Schema in which to recompile invalid objects
    *                     If NULL, all invalid objects in the database
    *                     are recompiled.
    *   flags      (IN) - Option flags supported (as described above).
    *
    * DESCRIPTION:
    *   This procedure is the main driver that recompiles invalid objects
    *   in the database (or in a given schema) in parallel in dependency
    *   order. It uses information in dependency$ to order recompilation
    *   of dependents after parents.
    *
    * NOTES:
    *   The parallel recompile exploits multiple CPUs to reduce the time
    *   taken to recompile invalid objects. However, please note that
    *   recompilation writes significant amounts of data to system tables,
    *   so the disk system may be a bottleneck and prevent significant
    *   speedups.
    */
   PROCEDURE recomp_parallel(threads PLS_INTEGER := NULL,
                             schema  VARCHAR2    := NULL,
                             flags   PLS_INTEGER := 0);

   /*
    * NAME:
    *   recomp_serial
    *
    * PARAMETERS:
    *   schema     (IN) - Schema in which to recompile invalid objects
    *                     If NULL, all invalid objects in the database
    *                     are recompiled.
    *   flags      (IN) - Option flags supported (as described above).
    *
    * DESCRIPTION:
    *   This procedure recompiles invalid objects in a given schema or
    *   all invalid objects in the database.
    */
   PROCEDURE recomp_serial(schema VARCHAR2 := NULL, flags PLS_INTEGER := 0);

   /*
    * NAME:
    *   parallel_slave
    *
    * PARAMETERS:
    *   flags      (IN) - Option flags supported (see recomp_parallel)
    *
    * DESCRIPTION:
    *   This is an internal function that runs in each parallel thread.
    *   It picks up any remaining invalid objects from utl_recomp_sorted
    *   and recompiles them.
    */
$if utl_ident.is_oracle_server $then
   PROCEDURE parallel_slave(flags PLS_INTEGER);
$else
  /* parallel_slave is not supported */
$end

   /*
    * NAME:
    * truncate_utl_recomp_skip_list
    *
    * DESCRIPTION:
    *   This procedure truncates the utl_recomp_skip_list table.
    */
PROCEDURE truncate_utl_recomp_skip_list;

   /*
    * NAME:
    *   populate_utl_recomp_skip_list
    *
    * DESCRIPTION:
    *   This procedure populates the utl_recomp_skip_list table with the list
    *   of invalid objects. This list is typically populated before a database
    *   upgrade. The utl_recomp run after upgrade then skips over objects that
    *   were invalid before upgrade.
    */
PROCEDURE  populate_utl_recomp_skip_list;

END;
/

