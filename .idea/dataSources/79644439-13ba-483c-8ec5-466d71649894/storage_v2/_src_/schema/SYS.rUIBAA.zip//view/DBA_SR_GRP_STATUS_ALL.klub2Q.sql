create view DBA_SR_GRP_STATUS_ALL
            (OWNER, GROUP_ID, OPERATION, STATUS, CURRENT_RUN, CURRENT_GROUP, NUM_TBLS, NUM_MVS, BASE_TBLS_REFR_STATUS,
             NUM_MVS_COMPLETED, NUM_MVS_ABORTED, ERROR_NUMBER, ERROR_MESSAGE, PREPARE_START_TIME, PREPARE_END_TIME,
             EXECUTE_START_TIME, EXECUTE_END_TIME)
as
select u1.name owner,
       st.group_id,
       decode(st.cur_run_opn,
              1, 'PREPARE',
              2, 'EXECUTE') operation,
       decode(st.cur_run_status,
              0, 'RUNNING',
              1, 'COMPLETE',
              2, 'ERROR_SOFT',
              3, 'ERROR_HARD',
              4, 'ABORT',
              5, 'PARTIAL') status,
       decode(st.cur_run_flag,
              0, 'N',
              1, 'Y')  current_run,
       decode(s1.current_group_flag,
              0, 'N',
              1, 'Y')  current_group,
       num_tbls,
       num_mvs,
       decode(st.base_tbls_refr_status,
              0, 'NOT PROCESSED',
              1, 'COMPLETE',
              4, 'ABORT') base_tbls_refr_status,
       num_mvs_completed,                   /* numbers of MVs completed if any */
       num_mvs_aborted,                     /* numbers of MVs aborted if any */
       error_number,                        /* error number if any */
       error_message,                       /* error message if any */
       prepare_start_time,                  /* start-time of prepare_refresh */
       prepare_end_time,                    /* end-time of prepare_refresh */
       execute_start_time,                  /* start-time of execute_refresh */
       execute_end_time                     /* end-time of execute_refresh */
from sys.syncref$_group_status st, sys.user$ u1,
  (select distinct group_id, current_group_flag from sys.syncref$_objects) s1
where st.owner# = u1.user# and st.group_id = s1.group_id
/

comment on table DBA_SR_GRP_STATUS_ALL is 'All synchronous refresh groups in the database'
/

comment on column DBA_SR_GRP_STATUS_ALL.OWNER is 'Owner of the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.GROUP_ID is 'Group ID of the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.OPERATION is 'Current operation of the synchronous refresh group: PREPARE, EXECUTE'
/

comment on column DBA_SR_GRP_STATUS_ALL.STATUS is 'Status of the synchronous refresh group: RUNNING, NOT PROCESSED,  COMPLETE, ERROR-SOFT, ERROR-HARD,-ABORT '
/

comment on column DBA_SR_GRP_STATUS_ALL.CURRENT_RUN is 'Indicates whether the synchronous refresh group is in the current run: Y - YES, N - NO '
/

comment on column DBA_SR_GRP_STATUS_ALL.NUM_TBLS is 'The number of tables in the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.NUM_MVS is 'The number of materialized views in the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.BASE_TBLS_REFR_STATUS is 'Indicate the refresh status of base tables in the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.NUM_MVS_COMPLETED is 'The number of materialized views which have completed refresh in the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.NUM_MVS_ABORTED is 'The number of materialized view which have aborted refresh in the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.ERROR_NUMBER is 'Error number if any of the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.ERROR_MESSAGE is 'Error message if any of the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.PREPARE_START_TIME is 'Start-time of prepare_refresh of the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.PREPARE_END_TIME is 'End-time of prepare_refresh of the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.EXECUTE_START_TIME is 'Start-time of execute_refresh of the synchronous refresh group'
/

comment on column DBA_SR_GRP_STATUS_ALL.EXECUTE_END_TIME is 'End-time of execute_refresh of the synchronous refresh group'
/

