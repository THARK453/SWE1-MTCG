create view "_DBA_APPLY_TABLE_COLUMNS" (OBJECT_NUMBER, COLUMN_NAME, FLAG, DBLINK, SPARE1, SPARE2) as
select
  object_number, column_name, flag, dblink, spare1, spare2
from sys.streams$_dest_obj_cols
/

