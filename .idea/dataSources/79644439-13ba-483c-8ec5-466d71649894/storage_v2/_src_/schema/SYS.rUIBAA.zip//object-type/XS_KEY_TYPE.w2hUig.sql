create TYPE XS$KEY_TYPE FORCE AS OBJECT (

primary_key      VARCHAR2(130),
foreign_key      VARCHAR2(4000),

-- Foreign key type; 1 = col name, 2 = col value
foreign_key_type NUMBER,

-- Constructor function
CONSTRUCTOR FUNCTION XS$KEY_TYPE
                     (primary_key      IN VARCHAR2,
                      foreign_key      IN VARCHAR2,
                      foreign_key_type IN NUMBER)
                      RETURN SELF AS RESULT,

-- Get the primary key of the key
MEMBER FUNCTION GET_PRIMARY_KEY RETURN VARCHAR2,
-- Get the foreign key of the key
MEMBER FUNCTION GET_FOREIGN_KEY RETURN VARCHAR2,
-- Get the foreign key type
MEMBER FUNCTION GET_FOREIGN_KEY_TYPE RETURN NUMBER,

-- Set the primary key of the key
MEMBER PROCEDURE SET_PRIMARY_KEY(primary_key IN VARCHAR2),
-- Set the foreign key of the key
MEMBER PROCEDURE SET_FOREIGN_KEY(foreign_key IN VARCHAR2),
-- Set the foreign key type
MEMBER PROCEDURE SET_FOREIGN_KEY_TYPE(foreign_key_type IN NUMBER)
);
/

