create type v_RangeRec_t as object
   (
      db_id                   NUMBER,
      high_time               DATE,
      low_time                DATE,
      low_change#             NUMBER,
      high_change#            NUMBER,
      low_resetlogs_change#   NUMBER,
      high_resetlogs_change#  NUMBER,
      low_resetlogs_time      DATE,
      high_resetlogs_time     DATE,
      con_id                  NUMBER
   );
/

