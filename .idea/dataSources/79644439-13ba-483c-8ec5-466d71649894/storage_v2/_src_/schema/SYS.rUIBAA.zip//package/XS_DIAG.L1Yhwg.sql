create PACKAGE XS_DIAG AUTHID CURRENT_USER AS

  -- Exeption when maximum number of messages allowed is set to be less than 1.
  ERR_INVALID_MSG_MAX CONSTANT NUMBER := -20028;
  EXCP_INVALID_MSG_MAX EXCEPTION;
  PRAGMA EXCEPTION_INIT(EXCP_INVALID_MSG_MAX, -20028);


/******************************************************************************
                       Validation Routines

Input:
  name               The name of object to be validated.
  error_limit        The maximum number of errors that may be stored in the
                     validation table.
  policy             The name of the policy to be validated
  table_owner        The owner of the table/view.
  table_name         The name of the table/view.

Output:
  Return TRUE if the object is valid, otherwise return FALSE.

  For each identified inconsistency, a row will be inserted into
  XS$VALIDATION_TABLE until the maximum number of inconisistencies that may be
  store has been reached.

  VALIDATE_DATA_SECURITY() provides three styles of policy validation:
  1. When policy is not null and table_name is null, the function will
     validate the policy against all the tables that the policy is applied to.
     Note, when table_name is null, table_owner will be ignored even if it is
     not null.

  2. When both policy and table_name are not null, the function will validate
     the policy against the specific table. If table_owner is not provided, the
     current schema will be used.

  3. When policy is null and table name is not null, the function will validate
     all the policies applied to the table against the table. If table_owner is
     not provided, the current schema will be used.

******************************************************************************/


  -- Validate principal.
  FUNCTION validate_principal(name         IN VARCHAR2,
                              error_limit  IN PLS_INTEGER := 1)
    RETURN BOOLEAN;

  -- Validate roleset.
  FUNCTION validate_roleset(name         IN VARCHAR2,
                            error_limit  IN PLS_INTEGER := 1)
    RETURN BOOLEAN;

  -- Validate security class.
  FUNCTION validate_security_class(name         IN VARCHAR2,
                                   error_limit  IN PLS_INTEGER := 1)
    RETURN BOOLEAN;

  -- Validate acl.
  FUNCTION validate_acl(name         IN VARCHAR2,
                        error_limit  IN PLS_INTEGER := 1)
    RETURN BOOLEAN;

  -- Validate data security policy against a specific table.
  FUNCTION validate_data_security(policy         IN VARCHAR2 := NULL,
                                  table_owner    IN VARCHAR2 := NULL,
                                  table_name     IN VARCHAR2 := NULL,
                                  error_limit    IN PLS_INTEGER := 1)
    RETURN BOOLEAN;

  -- Validate namespace template.
  FUNCTION validate_namespace_template(name         IN VARCHAR2,
                                       error_limit  IN PLS_INTEGER := 1)
    RETURN BOOLEAN;

  -- Validate an entire workspace.
  FUNCTION validate_workspace(error_limit  IN PLS_INTEGER := 1)
    RETURN BOOLEAN;

END XS_DIAG;
/

