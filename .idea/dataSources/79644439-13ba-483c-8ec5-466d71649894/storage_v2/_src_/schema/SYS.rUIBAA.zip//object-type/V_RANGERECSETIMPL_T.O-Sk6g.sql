create type v_RangeRecSetImpl_t as object
(
  curval                number,   -- current rownum
  done                  number,   -- done with the query
  opCode                varchar2(10),

  static function ODCITableStart(sctx   IN OUT v_RangeRecSetImpl_t,
                                 opCode IN varchar2)
    return number,

  member function ODCITableFetch(self   IN OUT v_RangeRecSetImpl_t,
                                 nrows  IN     number,
                                 objSet OUT    v_RangeRecSet_t)
    return number,

  member function ODCITableClose(self   IN     v_RangeRecSetImpl_t)
    return number
);
/

