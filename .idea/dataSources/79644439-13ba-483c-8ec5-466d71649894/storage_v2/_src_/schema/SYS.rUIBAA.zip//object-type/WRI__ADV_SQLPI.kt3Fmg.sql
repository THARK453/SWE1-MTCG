create type wri$_adv_sqlpi under wri$_adv_sqltune
(
) FINAL
/

