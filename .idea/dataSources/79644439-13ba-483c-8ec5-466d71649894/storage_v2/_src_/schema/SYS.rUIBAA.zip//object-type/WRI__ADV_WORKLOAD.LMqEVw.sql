create type wri$_adv_workload under wri$_adv_abstract_t
  (
    overriding member procedure sub_create(task_id in number,
                                           from_task_id in number),
    overriding member procedure sub_reset(task_id in number),
    overriding member procedure sub_delete(task_id in number),
    overriding member procedure sub_param_validate(task_id in number,
                                                   name in varchar2,
                                                   value in out varchar2),
    overriding member procedure sub_get_report (task_id IN NUMBER,
                                                type IN VARCHAR2,
                                                level IN VARCHAR2,
                                                section IN VARCHAR2,
                                                buffer IN OUT NOCOPY CLOB),
    overriding member procedure sub_user_setup(adv_id in number)
  );
/

