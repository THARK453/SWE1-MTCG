create view ALL_SCHEDULER_CREDENTIALS (OWNER, CREDENTIAL_NAME, USERNAME, DATABASE_ROLE, WINDOWS_DOMAIN, COMMENTS) as
SELECT u.name, o.name, c.username,
  DECODE(bitand(c.flags,1+2+8+16), 1,'SYSDBA', 2, 'SYSOPER',
                                   8, 'SYSBACKUP' , 16, 'SYSDG', NULL),
  c.domain, c.comments
  FROM obj$ o, user$ u, sys.scheduler$_credential c
  WHERE c.obj# = o.obj# AND u.user# = o.owner# AND
    (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         (exists (select null from v$enabledprivs
                 where priv_number in (-265 /* CREATE ANY JOB */)
                 )
          and o.owner#!=0)
      )
/

comment on table ALL_SCHEDULER_CREDENTIALS is 'All scheduler credentials visible to the user'
/

comment on column ALL_SCHEDULER_CREDENTIALS.OWNER is 'Owner of the scheduler credential'
/

comment on column ALL_SCHEDULER_CREDENTIALS.CREDENTIAL_NAME is 'Name of the scheduler credential'
/

comment on column ALL_SCHEDULER_CREDENTIALS.USERNAME is 'User to execute the job as'
/

comment on column ALL_SCHEDULER_CREDENTIALS.DATABASE_ROLE is 'Database role to use when logging in (SYSDBA, SYSOPER, SYSBACKUP, SYSDG or NULL)'
/

comment on column ALL_SCHEDULER_CREDENTIALS.WINDOWS_DOMAIN is 'Windows domain to use when logging in'
/

comment on column ALL_SCHEDULER_CREDENTIALS.COMMENTS is 'Comments on the credential'
/

