create type wri$_adv_compression_t under wri$_adv_abstract_t
(
  overriding member procedure sub_execute (task_id IN  NUMBER,
                                           err_num OUT NUMBER),
  overriding member procedure sub_get_report (task_id IN NUMBER,
                                              type IN VARCHAR2,
                                              level IN VARCHAR2,
                                              section IN VARCHAR2,
                                              buffer IN OUT NOCOPY CLOB)
);
/

