create view AWR_PDB_PGA_TARGET_ADVICE
            (SNAP_ID, DBID, INSTANCE_NUMBER, PGA_TARGET_FOR_ESTIMATE, PGA_TARGET_FACTOR, ADVICE_STATUS, BYTES_PROCESSED,
             ESTD_TIME, ESTD_EXTRA_BYTES_RW, ESTD_PGA_CACHE_HIT_PERCENTAGE, ESTD_OVERALLOC_COUNT, CON_DBID, CON_ID)
as
select pga.snap_id, pga.dbid, pga.instance_number,
       pga_target_for_estimate,
       pga_target_factor, advice_status, bytes_processed,
       estd_time, estd_extra_bytes_rw,
       estd_pga_cache_hit_percentage, estd_overalloc_count,
       decode(pga.con_dbid, 0, pga.dbid, pga.con_dbid),
       decode(pga.per_pdb, 0, 0,
         con_dbid_to_id(decode(pga.con_dbid, 0, pga.dbid, pga.con_dbid))) con_id
  from AWR_PDB_SNAPSHOT sn, WRH$_PGA_TARGET_ADVICE pga
  where     sn.snap_id         = pga.snap_id
        and sn.dbid            = pga.dbid
        and sn.instance_number = pga.instance_number
/

comment on table AWR_PDB_PGA_TARGET_ADVICE is 'PGA Target Advice History'
/

