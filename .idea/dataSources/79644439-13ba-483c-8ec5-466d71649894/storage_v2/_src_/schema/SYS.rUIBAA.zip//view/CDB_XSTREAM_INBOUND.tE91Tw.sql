create view CDB_XSTREAM_INBOUND
            (SERVER_NAME, QUEUE_OWNER, QUEUE_NAME, APPLY_USER, USER_COMMENT, CREATE_DATE, STATUS, COMMITTED_DATA_ONLY,
             CON_ID) as
SELECT k."SERVER_NAME",k."QUEUE_OWNER",k."QUEUE_NAME",k."APPLY_USER",k."USER_COMMENT",k."CREATE_DATE",k."STATUS",k."COMMITTED_DATA_ONLY",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XSTREAM_INBOUND") k
/

comment on table CDB_XSTREAM_INBOUND is 'Details about the XStream inbound server in all containers'
/

comment on column CDB_XSTREAM_INBOUND.SERVER_NAME is 'Name of the inbound server'
/

comment on column CDB_XSTREAM_INBOUND.QUEUE_OWNER is 'Owner of the queue associated with the inbound server'
/

comment on column CDB_XSTREAM_INBOUND.QUEUE_NAME is 'Name of the queue associated with the inbound server'
/

comment on column CDB_XSTREAM_INBOUND.APPLY_USER is 'Name of the user who is applying the messages'
/

comment on column CDB_XSTREAM_INBOUND.USER_COMMENT is 'User comment'
/

comment on column CDB_XSTREAM_INBOUND.CREATE_DATE is 'Date when inbound server was created'
/

comment on column CDB_XSTREAM_INBOUND.STATUS is 'Status of the apply process: DISABLED, ABORTED, DETACHED, ATTACHED'
/

comment on column CDB_XSTREAM_INBOUND.COMMITTED_DATA_ONLY is 'Is inbound server receiving committed data only?'
/

comment on column CDB_XSTREAM_INBOUND.CON_ID is 'container id'
/

