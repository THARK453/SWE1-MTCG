create view CDB_HIST_CON_SYSSTAT (SNAP_ID, DBID, INSTANCE_NUMBER, STAT_ID, STAT_NAME, VALUE, CON_DBID, CON_ID) as
SELECT k."SNAP_ID",k."DBID",k."INSTANCE_NUMBER",k."STAT_ID",k."STAT_NAME",k."VALUE",k."CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_CON_SYSSTAT") k
/

comment on table CDB_HIST_CON_SYSSTAT is 'System Historical Statistics Information Per PDB in all containers'
/

comment on column CDB_HIST_CON_SYSSTAT.CON_ID is 'container id'
/

