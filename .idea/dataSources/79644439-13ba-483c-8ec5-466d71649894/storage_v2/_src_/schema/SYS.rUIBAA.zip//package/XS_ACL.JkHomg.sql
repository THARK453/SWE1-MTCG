create PACKAGE XS_ACL AUTHID CURRENT_USER AS

-- The following constants define the parent ACL type.
  EXTENDED              CONSTANT PLS_INTEGER := 1;
  CONSTRAINED           CONSTANT PLS_INTEGER := 2;

-- The following constants define the principal's type.
  PTYPE_XS              CONSTANT PLS_INTEGER := 1;
  PTYPE_DB              CONSTANT PLS_INTEGER := 2;
  PTYPE_DN              CONSTANT PLS_INTEGER := 3;
  PTYPE_EXTERNAL        CONSTANT PLS_INTEGER := 4;

-- The following constants define the parameter value type.
  TYPE_NUMBER           CONSTANT PLS_INTEGER := 1;
  TYPE_VARCHAR          CONSTANT PLS_INTEGER := 2;

-- Enable log based replication for this package
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, AUTO);

-- Create ACL API
  PROCEDURE create_acl (
    name            IN VARCHAR2,
    ace_list        IN XS$ACE_LIST,
    sec_class       IN VARCHAR2 := NULL,
    parent          IN VARCHAR2:=NULL,
    inherit_mode    IN PLS_INTEGER:=NULL,
    description     IN VARCHAR2 := NULL);

-- Append one ACE to the ACL
  PROCEDURE append_aces (
    acl  IN VARCHAR2,
    ace  IN XS$ACE_TYPE);

-- Append ACEs to the ACL
  PROCEDURE append_aces (
    acl      IN VARCHAR2,
    ace_list IN XS$ACE_LIST);

-- Remove all ACEs from the ACL
  PROCEDURE remove_aces (
    acl      IN VARCHAR2);

-- Set the secuirty class
  PROCEDURE set_security_class (
    acl       IN VARCHAR2,
    sec_class IN VARCHAR2);

-- Set the parent acl
  PROCEDURE set_parent_acl(
    acl          IN VARCHAR2,
    parent       IN VARCHAR2,
    inherit_mode IN PLS_INTEGER);

--Add a parameter value : NUMBER
  PROCEDURE add_acl_parameter (
    acl       IN VARCHAR2,
    policy    IN VARCHAR2,
    parameter IN VARCHAR2,
    value     IN NUMBER);

--Add a parameter value : VARCHAR2
  PROCEDURE add_acl_parameter (
    acl       IN VARCHAR2,
    policy    IN VARCHAR2,
    parameter IN VARCHAR2,
    value     IN VARCHAR2);

--Remove all parameters
  PROCEDURE remove_acl_parameters (
    acl       IN VARCHAR2);

-- Remove a parameter
  PROCEDURE remove_acl_parameters (
    acl       IN VARCHAR2,
    parameter IN VARCHAR2);

-- Remove a parameter associate with a policy
  PROCEDURE remove_acl_parameters (
    acl       IN VARCHAR2,
    policy    IN VARCHAR2,
    parameter IN VARCHAR2);

-- Set description of ACL
  PROCEDURE set_description (
    acl         IN VARCHAR2,
    description IN VARCHAR2);

-- Delete the ACL
  PROCEDURE delete_acl (
    acl           IN VARCHAR2,
    delete_option IN PLS_INTEGER:=XS_ADMIN_UTIL.DEFAULT_OPTION);

END XS_ACL;
/

