create view USER_SCHEDULER_INCOMPATS (INCOMPATIBILITY_NAME, CONSTRAINT_LEVEL, ENABLED, JOBS_RUNNING_COUNT, COMMENTS) as
SELECT so.name,
      decode(bitand(r.flags, 4+8), 4, 'JOB_LEVEL',
                                   8, 'PROGRAM_LEVEL',
                                   'ERROR'),
      decode(r.status,1, 'YES', 2, 'NO', 'ERROR'),
      ru.jobs_running,
      r.comments
  FROM obj$ so, user$ su, sys.scheduler$_resources r,
      scheduler$_resource_usage ru
  WHERE r.obj# = so.obj# AND so.owner# = su.user# and
       r.obj# = ru.resoid and bitand(r.flags,2) = 2
      AND  so.owner# = USERENV('SCHEMAID')
/

comment on table USER_SCHEDULER_INCOMPATS is 'All scheduler incompatibility resource objects in the database'
/

comment on column USER_SCHEDULER_INCOMPATS.INCOMPATIBILITY_NAME is 'Name of the incompatibility resource object'
/

comment on column USER_SCHEDULER_INCOMPATS.JOBS_RUNNING_COUNT is 'Current number of running jobs using the incompatibility resource object'
/

comment on column USER_SCHEDULER_INCOMPATS.COMMENTS is 'Comments for the resource incompatibility object'
/

