create view DBA_GG_INBOUND_PROGRESS
            (SERVER_NAME, PROCESSED_LOW_POSITION, APPLIED_LOW_POSITION, APPLIED_HIGH_POSITION, SPILL_POSITION,
             OLDEST_POSITION, APPLIED_LOW_SCN, APPLIED_TIME, APPLIED_MESSAGE_CREATE_TIME, SOURCE_DATABASE,
             SOURCE_ROOT_NAME, LOGBSN)
as
select xs.server_name,
          case
          when (nvl(am.spill_lwm_position, '00') <
                                             nvl(am.lwm_external_pos, '00'))
            then utl_raw.cast_to_varchar2(am.lwm_external_pos)
          else utl_raw.cast_to_varchar2(am.spill_lwm_position)
          end,
          utl_raw.cast_to_varchar2(am.lwm_external_pos),
          utl_raw.cast_to_varchar2(am.applied_high_position),
          utl_raw.cast_to_varchar2(am.spill_lwm_position),
          utl_raw.cast_to_varchar2(am.oldest_position),
          am.commit_scn,
          am.apply_time, am.applied_message_create_time,
          am.source_db_name, am.source_root_name,
          utl_raw.cast_to_varchar2(am.spare5)
from  sys.xstream$_server xs, streams$_apply_process ap,
      "_DBA_APPLY_MILESTONE" am
 where ap.apply# = am.apply#
   and ap.apply_name = xs.server_name
   and bitand(ap.flags, 16384) = 16384                /* GoldenGate */
   and bitand(xs.flags, 2) = 2                        /* XStream In  process */
/

comment on column DBA_GG_INBOUND_PROGRESS.SERVER_NAME is 'Name of the outbound server'
/

comment on column DBA_GG_INBOUND_PROGRESS.PROCESSED_LOW_POSITION is 'Position of processed low transaction'
/

comment on column DBA_GG_INBOUND_PROGRESS.APPLIED_LOW_POSITION is 'All messages with commit position less than this value have been applied'
/

comment on column DBA_GG_INBOUND_PROGRESS.APPLIED_HIGH_POSITION is 'Highest commit position of a transaction that has been applied'
/

comment on column DBA_GG_INBOUND_PROGRESS.SPILL_POSITION is 'Position of the spill low watermark'
/

comment on column DBA_GG_INBOUND_PROGRESS.OLDEST_POSITION is 'Earliest position of the transactions currently being applied'
/

comment on column DBA_GG_INBOUND_PROGRESS.APPLIED_LOW_SCN is 'All SCN below this number have been successfully applied'
/

comment on column DBA_GG_INBOUND_PROGRESS.APPLIED_TIME is 'Time at which the APPLIED_MESSAGE_NUMBER message was applied'
/

comment on column DBA_GG_INBOUND_PROGRESS.APPLIED_MESSAGE_CREATE_TIME is 'Time at which the APPLIED_MESSAGE_NUMBER message was created'
/

comment on column DBA_GG_INBOUND_PROGRESS.SOURCE_DATABASE is 'Database where the transaction originated'
/

comment on column DBA_GG_INBOUND_PROGRESS.SOURCE_ROOT_NAME is 'Root database where all transactions originated'
/

comment on column DBA_GG_INBOUND_PROGRESS.LOGBSN is 'Log BSN value from the GoldenGate trail file'
/

