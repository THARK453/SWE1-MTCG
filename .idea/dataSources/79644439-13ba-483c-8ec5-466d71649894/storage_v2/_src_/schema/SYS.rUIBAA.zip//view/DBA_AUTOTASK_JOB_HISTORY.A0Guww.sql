create view DBA_AUTOTASK_JOB_HISTORY
            (CLIENT_NAME, WINDOW_NAME, WINDOW_START_TIME, WINDOW_DURATION, JOB_NAME, JOB_STATUS, JOB_START_TIME,
             JOB_DURATION, JOB_ERROR, JOB_INFO)
as
SELECT X.CNAME_KETCL,
            WLOG.WINDOW_NAME,
            WLOG.WINDOW_START_TIME,
            WLOG.WINDOW_END_TIME - WLOG.WINDOW_START_TIME
                AS WINDOW_DURATION,
            JD.JOB_NAME,
            JD.STATUS,
            JD.ACTUAL_START_DATE,
            JD.RUN_DURATION,
            JD.ERROR#,
            JD.ADDITIONAL_INFO
     FROM DBA_SCHEDULER_JOB_RUN_DETAILS JD,
          X$KETCL X,
          DBA_AUTOTASK_WINDOW_HISTORY WLOG
     WHERE JD.JOB_NAME LIKE 'ORA$AT_'|| X.CTAG_KETCL||'%'
       AND JD.OWNER = 'SYS'
       AND JD.ACTUAL_START_DATE BETWEEN WLOG.WINDOW_START_TIME AND WLOG.WINDOW_END_TIME
       AND (BITAND(X.ATTR_KETCL,2048) = 0
            OR 999999 < (SELECT TO_NUMBER(VALUE)
                           FROM V$SYSTEM_PARAMETER
                          WHERE NAME = '_automatic_maintenance_test'))
       AND X.CID_KETCL > 0
/

comment on table DBA_AUTOTASK_JOB_HISTORY is 'Automated Maintenance Jobs history'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.CLIENT_NAME is 'Name of the Automated Maintenance Client'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.WINDOW_NAME is 'Name of the Maintenance Window'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.WINDOW_START_TIME is 'Start time of the Maintenance Window'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.WINDOW_DURATION is 'Duration of the Maintenance Window'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.JOB_NAME is 'Name of the maintenance job'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.JOB_STATUS is 'Status of the maintenance job'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.JOB_START_TIME is 'Start time of the Maintenance Job'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.JOB_DURATION is 'Duration of the Maintenance Job'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.JOB_ERROR is 'Error code (if any) for the job'
/

comment on column DBA_AUTOTASK_JOB_HISTORY.JOB_INFO is 'Additional information about the job'
/

