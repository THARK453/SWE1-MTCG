create view CDB_CAPTURE
            (CAPTURE_NAME, QUEUE_NAME, QUEUE_OWNER, RULE_SET_NAME, RULE_SET_OWNER, CAPTURE_USER, START_SCN, STATUS,
             CAPTURED_SCN, APPLIED_SCN, USE_DATABASE_LINK, FIRST_SCN, SOURCE_DATABASE, SOURCE_DBID,
             SOURCE_RESETLOGS_SCN, SOURCE_RESETLOGS_TIME, LOGMINER_ID, NEGATIVE_RULE_SET_NAME, NEGATIVE_RULE_SET_OWNER,
             MAX_CHECKPOINT_SCN, REQUIRED_CHECKPOINT_SCN, LOGFILE_ASSIGNMENT, STATUS_CHANGE_TIME, ERROR_NUMBER,
             ERROR_MESSAGE, VERSION, CAPTURE_TYPE, LAST_ENQUEUED_SCN, CHECKPOINT_RETENTION_TIME, START_TIME, PURPOSE,
             SOURCE_ROOT_NAME, CLIENT_NAME, CLIENT_STATUS, OLDEST_SCN, FILTERED_SCN, CON_ID)
as
SELECT k."CAPTURE_NAME",k."QUEUE_NAME",k."QUEUE_OWNER",k."RULE_SET_NAME",k."RULE_SET_OWNER",k."CAPTURE_USER",k."START_SCN",k."STATUS",k."CAPTURED_SCN",k."APPLIED_SCN",k."USE_DATABASE_LINK",k."FIRST_SCN",k."SOURCE_DATABASE",k."SOURCE_DBID",k."SOURCE_RESETLOGS_SCN",k."SOURCE_RESETLOGS_TIME",k."LOGMINER_ID",k."NEGATIVE_RULE_SET_NAME",k."NEGATIVE_RULE_SET_OWNER",k."MAX_CHECKPOINT_SCN",k."REQUIRED_CHECKPOINT_SCN",k."LOGFILE_ASSIGNMENT",k."STATUS_CHANGE_TIME",k."ERROR_NUMBER",k."ERROR_MESSAGE",k."VERSION",k."CAPTURE_TYPE",k."LAST_ENQUEUED_SCN",k."CHECKPOINT_RETENTION_TIME",k."START_TIME",k."PURPOSE",k."SOURCE_ROOT_NAME",k."CLIENT_NAME",k."CLIENT_STATUS",k."OLDEST_SCN",k."FILTERED_SCN",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CAPTURE") k
/

comment on table CDB_CAPTURE is 'Details about the capture process in all containers'
/

comment on column CDB_CAPTURE.CAPTURE_NAME is 'Name of the capture process'
/

comment on column CDB_CAPTURE.QUEUE_NAME is 'Name of queue used for holding captured changes'
/

comment on column CDB_CAPTURE.QUEUE_OWNER is 'Owner of the queue used for holding captured changes'
/

comment on column CDB_CAPTURE.RULE_SET_NAME is 'Rule set used by capture process for filtering'
/

comment on column CDB_CAPTURE.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column CDB_CAPTURE.CAPTURE_USER is 'Current user who is enqueuing captured messages'
/

comment on column CDB_CAPTURE.START_SCN is 'The SCN from which capturing will be resumed'
/

comment on column CDB_CAPTURE.STATUS is 'Status of the capture process: DISABLED, ENABLED, ABORTED'
/

comment on column CDB_CAPTURE.CAPTURED_SCN is 'Everything up to this SCN has been captured'
/

comment on column CDB_CAPTURE.APPLIED_SCN is 'Everything up to this SCN has been applied'
/

comment on column CDB_CAPTURE.USE_DATABASE_LINK is 'Can use database_link from downstream to source database'
/

comment on column CDB_CAPTURE.FIRST_SCN is 'SCN from which the capture process can be restarted'
/

comment on column CDB_CAPTURE.SOURCE_DATABASE is 'Global name of the source database'
/

comment on column CDB_CAPTURE.SOURCE_DBID is 'DBID of the source database'
/

comment on column CDB_CAPTURE.SOURCE_RESETLOGS_SCN is 'Resetlogs_SCN of the source database'
/

comment on column CDB_CAPTURE.SOURCE_RESETLOGS_TIME is 'Resetlogs time of the source database'
/

comment on column CDB_CAPTURE.LOGMINER_ID is 'Session ID of LogMiner session associated with the capture process'
/

comment on column CDB_CAPTURE.NEGATIVE_RULE_SET_NAME is 'Negative rule set used by capture process for filtering'
/

comment on column CDB_CAPTURE.NEGATIVE_RULE_SET_OWNER is 'Owner of the negative rule set'
/

comment on column CDB_CAPTURE.MAX_CHECKPOINT_SCN is 'SCN at which the last check point was taken by the capture process'
/

comment on column CDB_CAPTURE.REQUIRED_CHECKPOINT_SCN is 'the safe SCN at which the meta-data for the capture process can be purged'
/

comment on column CDB_CAPTURE.LOGFILE_ASSIGNMENT is 'The logfile assignment type for the capture process'
/

comment on column CDB_CAPTURE.STATUS_CHANGE_TIME is 'The time that STATUS of the capture process was changed'
/

comment on column CDB_CAPTURE.ERROR_NUMBER is 'Error number if the capture process was aborted'
/

comment on column CDB_CAPTURE.ERROR_MESSAGE is 'Error message if the capture process was aborted'
/

comment on column CDB_CAPTURE.VERSION is 'Version number of the capture process'
/

comment on column CDB_CAPTURE.CAPTURE_TYPE is 'Type of the capture process'
/

comment on column CDB_CAPTURE.LAST_ENQUEUED_SCN is 'SCN of the last message enqueued by the capture process'
/

comment on column CDB_CAPTURE.CHECKPOINT_RETENTION_TIME is 'Number of days checkpoints will be retained by the capture process'
/

comment on column CDB_CAPTURE.START_TIME is 'The time when the capture process was started'
/

comment on column CDB_CAPTURE.PURPOSE is 'Purpose of the capture process'
/

comment on column CDB_CAPTURE.SOURCE_ROOT_NAME is 'Global name of the source root database'
/

comment on column CDB_CAPTURE.CLIENT_NAME is 'Name of the client process of the capture'
/

comment on column CDB_CAPTURE.CLIENT_STATUS is 'Status of the client process of the capture'
/

comment on column CDB_CAPTURE.OLDEST_SCN is 'Oldest SCN of the transaction currently being applied'
/

comment on column CDB_CAPTURE.FILTERED_SCN is 'SCN of the low watermark transaction processed'
/

comment on column CDB_CAPTURE.CON_ID is 'container id'
/

