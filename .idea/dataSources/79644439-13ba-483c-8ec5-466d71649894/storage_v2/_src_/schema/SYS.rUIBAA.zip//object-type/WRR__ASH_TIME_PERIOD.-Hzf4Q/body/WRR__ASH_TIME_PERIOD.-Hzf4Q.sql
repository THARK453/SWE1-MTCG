create type body WRR$_ASH_TIME_PERIOD
  AS
  FINAL INSTANTIABLE CONSTRUCTOR FUNCTION
    wrr$_ash_time_period( p_db_id INTEGER,
                        p_begin_time TIMESTAMP,
                        p_end_time   TIMESTAMP,
                        p_begin_snap_id INTEGER,
                        p_end_snap_id INTEGER,
                        p_id IN VARCHAR2 )
    RETURN SELF AS RESULT
  IS
    l_db_id INTEGER;
  BEGIN
    m_db_id         := p_db_id;
    m_begin_time    := p_begin_time;
    m_end_time      := p_end_time;
    m_begin_snap_id := p_begin_snap_id;
    m_end_snap_id   := p_end_snap_id;
    m_id            := p_id;
    m_time_period_type  := NULL;
    m_filter_condition  := NULL;
    m_desc              := NULL;
    RETURN;
  END;

END;
/

