create view DBA_RGROUP
            (REFGROUP, OWNER, NAME, IMPLICIT_DESTROY, PUSH_DEFERRED_RPC, REFRESH_AFTER_ERRORS, ROLLBACK_SEG, JOB,
             PURGE_OPTION, PARALLELISM, HEAP_SIZE, JOB_NAME)
as
select REFGROUP, OWNER, NAME,
          decode(bitand(flag,1),1,'Y',0,'N','?') IMPLICIT_DESTROY,
          decode(bitand(flag,2),2,'Y',0,'N','?') PUSH_DEFERRED_RPC,
          decode(bitand(flag,4),4,'Y',0,'N','?') REFRESH_AFTER_ERRORS,
          ROLLBACK_SEG,
          JOB,
          purge_opt#   PURGE_OPTION,
          parallelism# PARALLELISM,
          heap_size#   HEAP_SIZE,
          JOB_NAME
  from rgroup$ r
   where r.instsite = 0
/

comment on table DBA_RGROUP is 'All refresh groups.  This view is not a join.'
/

comment on column DBA_RGROUP.REFGROUP is 'Internal identifier of refresh group'
/

comment on column DBA_RGROUP.OWNER is 'Owner of the refresh group'
/

comment on column DBA_RGROUP.NAME is 'Name of the refresh group'
/

comment on column DBA_RGROUP.IMPLICIT_DESTROY is 'Y or N, if Y then destroy the refresh group when its last item is subtracted'
/

comment on column DBA_RGROUP.PUSH_DEFERRED_RPC is 'Y or N, if Y then push changes from snapshot to master before refresh'
/

comment on column DBA_RGROUP.REFRESH_AFTER_ERRORS is 'If Y, proceed with refresh despite error when pushing deferred RPCs'
/

comment on column DBA_RGROUP.ROLLBACK_SEG is 'Name of the rollback segment to use while refreshing'
/

comment on column DBA_RGROUP.JOB is 'Identifier of job used to automatically refresh the group'
/

comment on column DBA_RGROUP.PURGE_OPTION is 'The method for purging the transaction queue after each push'
/

comment on column DBA_RGROUP.PARALLELISM is 'The level of parallelism for transaction propagation'
/

comment on column DBA_RGROUP.HEAP_SIZE is 'The heap size used for transaction propagation'
/

comment on column DBA_RGROUP.JOB_NAME is 'The name of Job used to automatically refresh the group'
/

