create PACKAGE XS_ROLESET AUTHID CURRENT_USER AS

-- Enable log based replication for this package
PRAGMA SUPPLEMENTAL_LOG_DATA(default, AUTO);

-- Roleset creation API
  PROCEDURE create_roleset (
    name        IN VARCHAR2,
    role_list   IN XS$NAME_LIST:=NULL,
    description IN VARCHAR2:=NULL);

-- Add a role to the role set
  PROCEDURE add_roles (
    role_set       IN VARCHAR2,
    role           IN VARCHAR2);

-- Add a list of roles to the role set
  PROCEDURE add_roles (
    role_set  IN VARCHAR2,
    role_list IN XS$NAME_LIST);

-- Remove all roles from the role set
  PROCEDURE remove_roles (
    role_set IN VARCHAR2);

-- Remove a role from the role set
  PROCEDURE remove_roles (
    role_set IN VARCHAR2,
    role     IN VARCHAR2);

-- Remove a list of roles from the role set
  PROCEDURE remove_roles (
    role_set  IN VARCHAR2,
    role_list IN XS$NAME_LIST);

-- Set the description of a roleset
  PROCEDURE set_description (
    role_set    IN VARCHAR2,
    description IN VARCHAR2);

-- Delete the role set. A roleset is not referenced anywhere. So no delete
-- option is needed.
  PROCEDURE delete_roleset (
    role_set IN VARCHAR2);


END XS_ROLESET;
/

