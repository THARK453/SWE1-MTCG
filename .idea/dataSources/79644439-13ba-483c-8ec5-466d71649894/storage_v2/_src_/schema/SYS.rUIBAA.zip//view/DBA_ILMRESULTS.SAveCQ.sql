create view DBA_ILMRESULTS (TASK_ID, JOB_NAME, JOB_STATE, START_TIME, COMPLETION_TIME, COMMENTS, STATISTICS) as
SELECT a.execution_id, a.jobname,
       DECODE(a.job_status, 1,'JOB CREATED',
                            2, 'COMPLETED SUCCESSFULLY',
                            3, 'FAILED',
                            4, 'STOPPED',
                            5, 'JOB CREATION FAILED',
                            6, 'JOB SCHEDULED',
                            7, 'JOB DISABLED',
                            8, 'JOB RUNNING',
                           10, 'DEPENDANT OBJECTS BEING REBUILT',
                           11, 'FAILED TO REBUILD DEPENDANT OBJECTS',
                           12, 'CREATING JOB',
                           13,'JOB TO BE CREATED',
                               'NOT KNOWN'),
       a.start_time,
       a.completion_time,
       a.comments,
       a.statistics
  FROM sys.ilm_results$ a,
       sys.ilm_execution$ b
 WHERE a.execution_id = b.execution_id
/

comment on table DBA_ILMRESULTS is 'Information on ILM jobs'
/

comment on column DBA_ILMRESULTS.TASK_ID is 'Number that uniquely identifies a specific ILM task'
/

comment on column DBA_ILMRESULTS.JOB_NAME is 'Job name for executing policies'
/

comment on column DBA_ILMRESULTS.JOB_STATE is 'State of the Job'
/

comment on column DBA_ILMRESULTS.START_TIME is 'Time of start of the job'
/

comment on column DBA_ILMRESULTS.COMPLETION_TIME is 'Time of completion of the job'
/

comment on column DBA_ILMRESULTS.COMMENTS is 'More information if the job failed'
/

comment on column DBA_ILMRESULTS.STATISTICS is 'ILM job related statistics'
/

