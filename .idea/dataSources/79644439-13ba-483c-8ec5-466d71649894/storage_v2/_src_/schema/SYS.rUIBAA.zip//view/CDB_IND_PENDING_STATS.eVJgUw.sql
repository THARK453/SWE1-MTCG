create view CDB_IND_PENDING_STATS
            (OWNER, INDEX_NAME, TABLE_OWNER, TABLE_NAME, PARTITION_NAME, SUBPARTITION_NAME, BLEVEL, LEAF_BLOCKS,
             DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY, AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, NUM_ROWS, SAMPLE_SIZE,
             LAST_ANALYZED, CON_ID)
as
SELECT k."OWNER",k."INDEX_NAME",k."TABLE_OWNER",k."TABLE_NAME",k."PARTITION_NAME",k."SUBPARTITION_NAME",k."BLEVEL",k."LEAF_BLOCKS",k."DISTINCT_KEYS",k."AVG_LEAF_BLOCKS_PER_KEY",k."AVG_DATA_BLOCKS_PER_KEY",k."CLUSTERING_FACTOR",k."NUM_ROWS",k."SAMPLE_SIZE",k."LAST_ANALYZED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_IND_PENDING_STATS") k
/

comment on table CDB_IND_PENDING_STATS is 'Pending statistics of indexes, partitions, and subpartitions in all containers'
/

comment on column CDB_IND_PENDING_STATS.OWNER is 'Index owner name'
/

comment on column CDB_IND_PENDING_STATS.INDEX_NAME is 'Index name'
/

comment on column CDB_IND_PENDING_STATS.TABLE_OWNER is 'Table owner name'
/

comment on column CDB_IND_PENDING_STATS.TABLE_NAME is 'Table name'
/

comment on column CDB_IND_PENDING_STATS.PARTITION_NAME is 'Partition name'
/

comment on column CDB_IND_PENDING_STATS.SUBPARTITION_NAME is 'Subpartition name'
/

comment on column CDB_IND_PENDING_STATS.BLEVEL is 'Number of levels in the index'
/

comment on column CDB_IND_PENDING_STATS.LEAF_BLOCKS is 'Number of leaf blocks in the index'
/

comment on column CDB_IND_PENDING_STATS.DISTINCT_KEYS is 'Number of distinct keys in the index'
/

comment on column CDB_IND_PENDING_STATS.AVG_LEAF_BLOCKS_PER_KEY is 'Average number of leaf blocks per key'
/

comment on column CDB_IND_PENDING_STATS.AVG_DATA_BLOCKS_PER_KEY is 'Average number of data blocks per key'
/

comment on column CDB_IND_PENDING_STATS.CLUSTERING_FACTOR is 'Clustering factor'
/

comment on column CDB_IND_PENDING_STATS.NUM_ROWS is 'Number of rows in the index'
/

comment on column CDB_IND_PENDING_STATS.SAMPLE_SIZE is 'Sample size'
/

comment on column CDB_IND_PENDING_STATS.LAST_ANALYZED is 'Time of last analyze'
/

comment on column CDB_IND_PENDING_STATS.CON_ID is 'container id'
/

