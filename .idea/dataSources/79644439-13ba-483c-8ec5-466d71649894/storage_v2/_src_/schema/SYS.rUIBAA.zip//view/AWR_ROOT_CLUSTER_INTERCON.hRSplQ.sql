create view AWR_ROOT_CLUSTER_INTERCON
            (SNAP_ID, DBID, INSTANCE_NUMBER, NAME, IP_ADDRESS, IS_PUBLIC, SOURCE, CON_DBID, CON_ID) as
select
  sn.snap_id, sn.dbid, sn.instance_number,
  ci.name,
  case when SYS_CONTEXT('USERENV','SYSTEM_DATA_VISIBLE')='YES' then ci.ip_address else null end ip_address, -- Use macro to mask sensitive column
  ci.is_public, ci.source,
  decode(ci.con_dbid, 0, ci.dbid, ci.con_dbid),
  decode(ci.per_pdb, 0, 0,
    con_dbid_to_id(decode(ci.con_dbid, 0, ci.dbid, ci.con_dbid))) con_id
 from AWR_ROOT_SNAPSHOT sn, WRH$_CLUSTER_INTERCON ci
 where     sn.snap_id         = ci.snap_id
       and sn.dbid            = ci.dbid
       and sn.instance_number = ci.instance_number
/

comment on table AWR_ROOT_CLUSTER_INTERCON is 'Cluster Interconnect Historical Stats'
/

